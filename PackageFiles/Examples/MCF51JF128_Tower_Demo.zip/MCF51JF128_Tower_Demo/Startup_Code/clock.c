/*
 * clock.c
 *
 *  Created on: 04/03/2012
 *      Author: podonoghue
 */
#include "derivative.h" /* include peripheral declarations */
#include "clock.h"
#include "utilities.h"

const uint32_t SystemCoreClock = SYSTEM_CORE_CLOCK; // Hz
const uint32_t SystemBusClock  = SYSTEM_BUS_CLOCK;  // Hz

// Macros for single register bits
#define MCG_C1_IRCLKEN(x)     (((x)<<MCG_C1_IRCLKEN_SHIFT)&MCG_C1_IRCLKEN_MASK)
#define MCG_C1_IREFSTEN(x)    (((x)<<MCG_C1_IREFSTEN_SHIFT)&MCG_C1_IREFSTEN_MASK)
#define MCG_C2_IRCS(x)        (((x)<<MCG_C2_IRCS_SHIFT)&MCG_C2_IRCS_MASK)
#define MCG_C1_IREFS(x)       (((x)<<MCG_C1_IREFS_SHIFT)&MCG_C1_IREFS_MASK)
#define MCG_C4_DMX32(x)       (((x)<<MCG_C4_DMX32_SHIFT)&MCG_C4_DMX32_MASK)
#define MCG_C5_PLLCLKEN(x)    (((x)<<MCG_C5_PLLCLKEN_SHIFT)&MCG_C5_PLLCLKEN_MASK)
#define MCG_C6_PLLS(x)        (((x)<<MCG_C6_PLLS_SHIFT)&MCG_C6_PLLS_MASK)
#define MCG_C2_LP(x)          (((x)<<MCG_C2_LP_SHIFT)&MCG_C2_LP_MASK)
#define MCG_C2_HGO(x)         (((x)<<MCG_C2_HGO_SHIFT)&MCG_C2_HGO_MASK)
#define MCG_C2_EREFS(x)       (((x)<<MCG_C2_EREFS_SHIFT)&MCG_C2_EREFS_MASK)

#define SIM_CLKDIV1_USBFRAC(x) (((x)<<SIM_CLKDIV1_USBFRAC_SHIFT)&SIM_CLKDIV1_USBFRAC_MASK)

void showClocks(void) {

   // Put SYSTEM_MCGOUTCLK_CLOCK on PTA5
   SIM_SCGC6 |= SIM_SCGC6_PORTA_MASK;
   MXC_PTAPF2 = (MXC_PTAPF2&~MXC_PTAPF2_A5_MASK)|MXC_PTAPF2_A5(6);

   // BUSCLK
   SIM_CLKOUT = SIM_CLKOUT_CS(5)|SIM_CLKOUT_CLKOUTDIV(0);
   // CPUCLK/SYSCLK
   SIM_CLKOUT = SIM_CLKOUT_CS(4)|SIM_CLKOUT_CLKOUTDIV(0);
   // MCGOUTCLK
   SIM_CLKOUT = SIM_CLKOUT_CS(3)|SIM_CLKOUT_CLKOUTDIV(0);
}

/*! Sets up the clock for USB operation (out of RESET)
 *!
 *! MCGOUTCLK = 48MHz
 *! core/platform/system clock = PLL (48MHz),
 *! bus clock = PLL/2 (24MHz),
 *! flash clock = PLL/2 (24MHz)
 *!
 *! Assumes 8 MHz external crystal
 *!
 *! Modes: FEI [FLL engaged internal] ->
 *!        FBE [FLL bypassed external] ->
 *!        PBE [PLL bypassed external] ->
 *!        PEE [PLL engaged external]
 *!
 *! Refer 24.5.3.1 of KL25 Family reference
 */
void clock_initialise(void) {
//   showClocks();

#if (_CRYSTAL_CLOCK != 0)
   // XTAL/EXTAL Pins
   SIM_SCGC6 |= SIM_SCGC6_PORTB_MASK;
   MXC_PTBPF1 = (MXC_PTBPF1&~MXC_PTBPF1_B6_MASK)|MXC_PTBPF1_B6(0);
   MXC_PTBPF2 = (MXC_PTBPF2&~MXC_PTBPF2_B5_MASK)|MXC_PTBPF2_B5(0);

   // Configure the Crystal Oscillator
   OSC2_CR = OSC_CR_SC8P_MASK;
#endif

#if (MCG_C6_PLLS_VALUE == 0)
/*
 * Set up for internal clock (FEI)
 */
   // Use FEI - adjust to to optimal value
   MCG_C1 =  MCG_C1_CLKS(MCG_C1_CLKS_VALUE)    | // Clock source for MCGOUTCLK 0,1,2,3 -> FLL or PLL, IRC, ERC, -
             MCG_C1_FRDIV(0)                   | // FRDIV = 0    -> n/a
             MCG_C1_IRCLKEN_VALUE              | // IRCLKEN = 1  -> MCGIRCLK active
             MCG_C1_IREFSTEN_VALUE             | // IREFSTEN = 1 -> Internal reference enabled in STOP mode
             MCG_C1_IREFS_VALUE;                 // IREFS = 1    -> Slow IRC

   MCG_C2 =                         // no oscillator
            MCG_C2_EREFS(MCG_C2_EREFS_VALUE)    | // 0,1   -> external reference, crystal
            MCG_C2_RANGE(MCG_C2_RANGE_VALUE)    | // 0,1,2 -> low, high, very high range
            MCG_C2_HGO(MCG_C2_HGO_VALUE)        | // 0,1   -> low power, high gain
            MCG_C2_IRCS(MCG_C2_IRCS_VALUE);       // IRCS=0/1 -> MCGIRCLK = Slow/fast internal clock

   MCG_C6 = MCG_C6_PLLS(MCG_C6_PLLS_VALUE);  // Choose between FLL/PLL clock 0,1 -> FLL,PLL

   // MCGOUTCLK ~ 84 MHz

   // Set divider before changing frequency
   SIM_CLKDIV0 = SIM_CLKDIV0_OUTDIV(1);

   // USB Clock (not reliable!)
   SIM_CLKDIV1 = SIM_CLKDIV1_USBSRC(1)|SIM_CLKDIV1_USBFRAC(0)|SIM_CLKDIV1_USBDIV(1);

   // FLL Factors
   MCG_C4 = (MCG_C4&~(MCG_C4_DMX32_MASK|MCG_C4_DRST_DRS_MASK))|
            MCG_C4_DMX32(MCG_C4_DMX32_VALUE)|MCG_C4_DRST_DRS(MCG_C4_DRST_DRS_VALUE);
#else

   // Out of reset MCG is in FEI mode
   // =============================================================
   // 1 a) Set up crystal or external clock source
   MCG_C2 =                         // oscillator in low power mode (w/o Rf)
            MCG_C2_EREFS(MCG_C2_EREFS_VALUE)    | // 0,1   -> external reference, crystal
            MCG_C2_RANGE(MCG_C2_RANGE_VALUE)    | // 0,1,2 -> low, high, very high range
            MCG_C2_HGO(MCG_C2_HGO_VALUE)        | // 0,1   -> low power, high gain
            MCG_C2_IRCS(MCG_C2_IRCS_VALUE);       // IRCS=0/1 -> MCGIRCLK = Slow/fast internal clock

   // 1 b) Select clock mode
   MCG_C1 =  MCG_C1_CLKS(2)                    | // CLKS = 2     -> External reference clock
             MCG_C1_FRDIV(MCG_C1_FRDIV_VALUE)  | // FRDIV = 3    -> 8MHz/256 = 31.25 kHz
             MCG_C1_IRCLKEN_VALUE              | // IRCLKEN = 1  -> MCGIRCLK active
             MCG_C1_IREFSTEN_VALUE             | // IREFSTEN = 1 -> Internal reference enabled in STOP mode
             MCG_C1_IREFS_VALUE;                 // IREFS 0,1    -> External,Slow IRC

   SIM_CLKDIV0 = SIM_CLKDIV0_OUTDIV(2);
   SIM_CLKDIV1 = SIM_CLKDIV1_USBSRC(0)|SIM_CLKDIV1_USBFRAC(0)|SIM_CLKDIV1_USBDIV(1);

   // FLL Factors
   MCG_C4 = (MCG_C4&~(MCG_C4_DMX32_MASK|MCG_C4_DRST_DRS_MASK))|MCG_C4_DMX32(MCG_C4_DMX32_VALUE)|MCG_C4_DRST_DRS(MCG_C4_DRST_DRS_VALUE);

   // 1 c) Wait for crystal to start up
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_OSCINIT_MASK) == 0);

   // 1 d) Wait for mode change
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_IREFST_MASK) != 0);

   // 1 e) Wait for MCGOUT indicating that the external reference to be fed to MCGOUT
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_CLKST_MASK) != MCG_S_CLKST(2));

   // 2. Configure PLL Reference Frequency
   // =============================================================
   // 2 a) Set PRDIV for correct range
   MCG_C5 =  MCG_C5_PLLCLKEN_MASK |
             MCG_C5_PRDIV(MCG_C5_PRDIV_VALUE);    // PRDIV=1, PLL Ref Freq. = 8MHz/2 => 4 MHz

   MCG_C6 = MCG_C6_PLLS(MCG_C6_PLLS_VALUE);    // Choose between FLL/PLL clock 0,1 -> FLL,PLL

   // 3. FBE => PBE
   // =============================================================
   // 3 a) (BLPE - not done)
   // 3 b) PBE (/BLPE - not done)
   MCG_C6 = MCG_C6_PLLS(MCG_C6_PLLS_VALUE)|MCG_C6_VDIV(MCG_C6_VDIV_VALUE); // 4MHz x 24 = 96MHz
   // 3 c) PBE (BLPE only -  not done)
   // 3 d) Wait until PLLS clock source changes to the PLL
   do {
      __asm__("nop");
   } while((MCG_S & MCG_S_PLLST_MASK) == 0);

   // 3 e)  Wait for PLL to acquired lock
   do {
      __asm__("nop");
   } while((MCG_S & MCG_S_LOCK_MASK) == 0);

   // 4. PBE -> PEE mode:
   // =============================================================
   // 4 a) Select clock mode
   MCG_C1 = MCG_C1_CLKS(MCG_C1_CLKS_VALUE)   | // CLKS  = 0    -> FLL or PLL is selected
            MCG_C1_FRDIV(MCG_C1_FRDIV_VALUE) | // FRDIV = 3    -> 8MHz/256 = 31.25 kHz
            MCG_C1_IRCLKEN_MASK              | // IRCLKEN = 1  -> MCGIRCLK active
            MCG_C1_IREFSTEN_MASK             | // IREFSTEN = 1 -> Internal reference enabled in STOP mode
            MCG_C1_IREFS_VALUE;                // IREFS 0,1 -> External,Slow IRC

   // 4 b)  Wait for clock stable
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_CLKST_MASK) != (MCG_S_CLKST(3)));


   SIM_CLKDIV0 = SIM_CLKDIV0_OUTDIV(SIM_CLKDIV0_OUTDIV_VALUE);

#endif
}
