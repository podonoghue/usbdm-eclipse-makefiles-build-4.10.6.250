/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include "derivative.h"
#include "leds.h"

void delay(void) {
   volatile unsigned long i;
   for (i=400000; i>0; i--) {
	   asm("nop");
   }
}

int main(void) {
   led_initialise();
   for(;;) {
      redLedToggle();
      delay();
      redLedToggle();
      delay();
      greenLedToggle();
      delay();
      greenLedToggle();
      delay();
      blueLedToggle();
      delay();
      blueLedToggle();
      delay();
   }
}
