/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include "derivative.h"
#include "leds.h"

void port_initialise() {
   // Enable all port clocks
   SIM_SCGC5 |=   SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;
}

void delay(void) {
   volatile unsigned long i;
   for (i=400000; i>0; i--) {
	   asm("nop");
   }
}

int main(void) {
   port_initialise();
   led_initialise();
   for(;;) {
      redLedToggle();
      delay();
      redLedToggle();
      delay();
      greenLedToggle();
      delay();
      greenLedToggle();
      delay();
      blueLedToggle();
      delay();
      blueLedToggle();
      delay();
   }
}
