/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include <stdbool.h>
#include <sys/time.h>
#include <time.h>
#include "clock.h"
#include "clock_private.h"
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "Freedom.h"
#include "pit.h"
#include "lptmr.h"
#include "ftm0.h"
#include "rtc.h"
#include "adc0.h"
#include "i2c.h"
#include "MMA845x.h"

// Miscellaneous ==============================================================

/*
 * Toggles the BLUE LED between enabled and disabled
 */
void blueLedToggleEnable(void) {
   static bool oddEven = true;

   if (oddEven) {
      blueLedEnable();
   }
   else {
      blueLedDisable();
   }
   oddEven = !oddEven;
}

/*
 * Configures the CLOCKOUT pin
 */
void configureClockOutPin(void) {
   // PTC3(Fn5) = CLKOUT
   SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   PORTC_PCR3 = PORT_PCR_MUX(5);

   // CLKOUT = CLKOUTSEL(4) = MCGIRCLK
   SIM_SOPT2 = (SIM_SOPT2&~SIM_SOPT2_CLKOUTSEL_MASK)|SIM_SOPT2_CLKOUTSEL(4);
}

/*
 * Configures the CLOCKIN pin
 */
void configureRTCClockInPin(void) {
   // PTC1(Fn1) = RTC_CLKIN
   SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   PORTC_PCR1 = PORT_PCR_MUX(1);
}

// LPTMR ==============================================================

#define LPTMR_INTERVAL LPTMR_MILLISECOND_TO_TICKS(10)

#if (LPTMR_INTERVAL>65536)
#error "LPTMR Value is too large"
#endif

// RTC ==============================================================

/*
 * Reports the current RTC time on the terminal
 */
void clockTick(void) {
   time_t currentTime;
   struct tm *timeInfo;

   currentTime = time(NULL);
   timeInfo = localtime(&currentTime);
   printf("\'Tick\' - %s", asctime(timeInfo));
}

/*
 * Report an Alarm time on the terminal
 */
void clockAlarm(void) {
   // Set next alarm for 10 seconds from last alarm
   uint32_t theTime   = rtc_getTime() + 5;
   uint32_t alarmTime = rtc_getAlarmTime() + 10;
   if (theTime>alarmTime) {
      alarmTime = theTime;
   }
   rtc_setAlarmTime(alarmTime);
   time_t currentTime;
   struct tm *timeInfo;

   currentTime = time(NULL);
   timeInfo = localtime(&currentTime);
   printf("\'**** ALARM ****\' - %s", asctime(timeInfo));

}

static unsigned tick = 0;
/*
 * Used to flag the passing of time
 */
void rtcCallback(void) {
   tick++;
}

// PWM0/FTM0 ==============================================================

#define FTM0_CH0_PERIOD FTM0_MILLISECONDS_TO_TICKS(60)
#if FTM0_CH0_PERIOD > 65535
#error "FTM0_CH0_PERIOD is too large"
#endif
#if FTM0_CH0_PERIOD < 40
#error "FTM0_CH0_PERIOD is too small"
#endif

#define FTM0_CH1_PERIOD FTM0_MICROSECONDS_TO_TICKS(1000)
#if FTM0_CH1_PERIOD > 65535
#error "FTM1_CH1_PERIOD is too large"
#endif
#if FTM0_CH1_PERIOD < 10
#error "FTM1_CH1_PERIOD is too small"
#endif

#define PWM0_PERIOD (FTM0_MILLISECONDS_TO_TICKS(40))

#if (PWM0_PERIOD<200)
#error "PWM0_PERIOD is too small (resolution < 1%)"
#endif
#if (PWM0_PERIOD>65535)
#error "PWM0_PERIOD is too large"
#endif

// PTC1(Fn4) = FTM0_CH0 = PWM0_CH0
#define FTM0_CH0_PORT         C
#define FTM0_CH0_PIN_NUM      1
#define FTM0_CH0_FN           4
#define FTM0_CH0_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTC2(Fn4) = FTM0_CH1 = PWM0_CH1
#define FTM0_CH1_PORT         C
#define FTM0_CH1_PIN_NUM      2
#define FTM0_CH1_FN           4
#define FTM0_CH1_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTC3(Fn4) = FTM0_CH2 = PWM0_CH2
#define FTM0_CH2_PORT         C
#define FTM0_CH2_PIN_NUM      3
#define FTM0_CH2_FN           4
#define FTM0_CH2_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

/*
 * Configure used FTM pins
 */
void configureFTMPins(void) {
   SIM_SCGC5 |= FTM0_CH0_CLOCK_MASK|FTM0_CH1_CLOCK_MASK|FTM0_CH2_CLOCK_MASK;
   PCR(FTM0_CH0_PORT,FTM0_CH0_PIN_NUM) = PORT_PCR_MUX(FTM0_CH0_FN);
   PCR(FTM0_CH1_PORT,FTM0_CH1_PIN_NUM) = PORT_PCR_MUX(FTM0_CH1_FN);
   PCR(FTM0_CH2_PORT,FTM0_CH2_PIN_NUM) = PORT_PCR_MUX(FTM0_CH2_FN);
}

 /*
  * Configure the PWM (= FTM function)
  */
void configureRGB_PWMPins(void) {
   SIM_SCGC5 |= FTM0_CH0_CLOCK_MASK|FTM0_CH1_CLOCK_MASK|FTM0_CH2_CLOCK_MASK;
   PCR(FTM0_CH0_PORT,FTM0_CH0_PIN_NUM) = PORT_PCR_MUX(FTM0_CH0_FN);
   PCR(FTM0_CH1_PORT,FTM0_CH1_PIN_NUM) = PORT_PCR_MUX(FTM0_CH1_FN);
   PCR(FTM0_CH2_PORT,FTM0_CH2_PIN_NUM) = PORT_PCR_MUX(FTM0_CH2_FN);
}

// PIT ==============================================================

#define PIT_CH0_PERIOD PIT_MILLISECOND_TO_TICKS(10)
#define PIT_CH1_PERIOD PIT_MILLISECOND_TO_TICKS(200)

// ADC ==============================================================

#define ADC_PERIOD PIT_MILLISECOND_TO_TICKS(1000)

#define ADC_OUTPUT_RANGE ((1<<12)-1) // 12 bit
#define ADC_INPUT_HIGH   (3300)      // Scaled by x1000
#define ADC_INPUT_LOW    (0)

#define ADC_INTERVAL (PIT_MILLISECOND_TO_TICKS(400))

/*
 * Configures ADC pins as analogue
 */
void configureADCPins(void) {
}

/*
 * Handler for ADC - prints out the value assuming it is from light sensor
 *
 * @param value - value from ADC output register
 */
void adcHandler(int value) {
   value = ((value *(ADC_INPUT_HIGH-ADC_INPUT_LOW))/ADC_OUTPUT_RANGE)+ADC_INPUT_LOW;
   printf("Light Sensor = %d.%03d V\n", value/1000, value%1000);
}

/*
 * Triggers a conversion on the light sensor ADC channel
 */
void adcTrigger(void) {
   // Configure next conversion
   adc0_doConversion(ADC_IN_LIGHT_SENSOR, adc_interrupt);
}

// I2C ==============================================================

#define PWM_LED_PERIOD (FTM0_MILLISECONDS_TO_TICKS(10))

#if (PWM_LED_PERIOD<200)
#error "PWM0_PERIOD is too small (resolution < 1%)"
#endif
#if (PWM_LED_PERIOD>65535)
#error "PWM0_PERIOD is too large"
#endif

#define ACCELEROMETER_INTERVAL (PIT_MILLISECOND_TO_TICKS(200))

/*
 * Polls the accelerometer and sets the PWM channels accordingly
 */
void accelerometerHandler() {
   int status, x,y,z;
   MMA845x_ReadXYX(&status, &x, &y, &z);

   // Scale values to ~[0-100]
   x = (x*50)/(1<<14) + 50;
   y = (y*50)/(1<<14) + 50;
   z = (z*50)/(1<<14) + 50;

   if (x<0) x = 0;
   if (y<0) y = 0;
   if (z<0) z = 0;

   if (x>100) x = 100;
   if (y>100) y = 100;
   if (z>100) z = 100;

   ftm0_setDutyCycle(0,   x);
   ftm0_setDutyCycle(1,  y);
   ftm0_setDutyCycle(2,  z);

   // Report values - will clash with other handlers
//   printf("Status=%X, X=%3d, Y=%3d, Z=%3d\n", status, x, y, z);
}

/*
 * This demonstration uses the following:
 *    - 3 PWM channels to control the RGB LED
 *    - I2C interface to communicate with the accelerometer
 *    - RTC to display the current time
 *    - ADC to measure the light sensor
 *    - PIT to control when the various measurements are made
 */
void mainDemonstration(void) {
   /*
    * Set up FTM-PWM channels for 3 LEDs
    */
   printf("FTM Base Clock = %lu, FTM clock = %lu Hz, interval = %lu\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);

   /*
    * Set up PWM for the three LEDs
    */
   configureRGB_PWMPins();
   ftm0_initialiseAsPWM(PWM_LED_PERIOD, ftm_centreAlign);
   ftm0_initialiseChannel(0,   ftm_pwmHighTruePulses);
   ftm0_initialiseChannel(1, ftm_pwmHighTruePulses);
   ftm0_initialiseChannel(2,  ftm_pwmHighTruePulses);
   ftm0_setDutyCycle(0,   50);
   ftm0_setDutyCycle(1, 50);
   ftm0_setDutyCycle(2,  50);

   /*
    * Set up PIT callback for accelerometer
    */
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);
   i2c_initialise(0x00, 400000);
   MMA845x_Initialise(MMA45x_2Gmode);
   pit_setCallbackFunction(0, accelerometerHandler);
   pit_initialise(0, ACCELEROMETER_INTERVAL);

   /*
    * Set up ADC callback to report light sensor
    */
   adc0_initialise(adc_singleEnded12_13bitConversion);
   adc0_setCallbackFunction(adcHandler);

   /*
    * Set up ADC trigger to happen every ADC_INTERVAL using PIT
    */
   pit_setCallbackFunction(2, adcTrigger);
   pit_initialise(2, ADC_INTERVAL);

   /*
    * RTC callback
    */
   rtc_setAlarmCallback(clockAlarm, rtc_getTime()+10);
   rtc_setSecondsCallback(rtcCallback);

   printf("LPTMR clock = %lu Hz, interval = %lu\n", LPTMR_CLOCK_FREQUENCY, LPTMR_INTERVAL);

   unsigned lastTick = 0;
   for(;;) {
      __wait_for_interrupt();
      if (tick != lastTick) {
         // Executed @ 1Hz
         clockTick();
      }
      lastTick = tick;
   }
}

/*
 * Demonstrates the FTM Output Compare
 *
 * This test configures two FTM channels to toggle their respective pins in hardware.
 * In addition the call-backs are used to pulse modulate the Blue LED.
 */
void demonstrateFTM(void) {
   printf("FTM Base Clock = %lu Hz, FTM clock = %lu Hz, interval = %lu ticks\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);

   led_initialise();

   configureFTMPins();
   ftm0_initialise();
   ftm0_initialiseChannel(0,ftm_outputCompareToggle);
   ftm0_setCallbackFunction(0,blueLedToggleEnable, FTM0_CH0_PERIOD);
   ftm0_initialiseChannel(1,ftm_outputCompareToggle);
   ftm0_setCallbackFunction(1,blueLedToggle,FTM0_CH1_PERIOD);

   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the FTM acting as a PWM
 *
 * This test configures two FTM channels as PWM with fixed duty-cycle.
 * One channel is inverted.
 * Channels are centre-aligned.
 */
void demonstratePWM(void) {
   printf("FTM Base Clock = %lu Hz, FTM clock = %lu Hz, interval = %lud ticks\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);
   configureFTMPins();
   ftm0_initialiseAsPWM(PWM0_PERIOD, ftm_centreAlign);
   ftm0_initialiseChannel(0, ftm_pwmHighTruePulses);
   ftm0_setDutyCycle(0, 50);
   ftm0_initialiseChannel(1, ftm_pwmLowTruePulses);
   ftm0_setDutyCycle(1, 25);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the LPTMR with callbacks
 *
 * This test configures the Low Power Timer (LPTMR) for a fixed period.
 * A callback is used to modulate the Blue LED.
 */
void demonstrateLPTMR(void) {
   led_initialise();

   printf("LPTMR clock = %lu Hz, interval = %lu ticks\n", LPTMR_CLOCK_FREQUENCY, LPTMR_INTERVAL);
   lptmr_setCallbackFunction(blueLedToggle);
   lptmr_initialise(LPTMR_INTERVAL);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the PIT with callbacks
 *
 * This test configures two PIT channels
 * Callbacks are used to pulse modulate the Blue LED.
 */
void demonstratePIT(void) {
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);

   led_initialise();

   pit_setCallbackFunction(0, blueLedToggle);
   pit_initialise(0, PIT_CH0_PERIOD);
   pit_setCallbackFunction(1, blueLedToggleEnable);
   pit_initialise(1, PIT_CH1_PERIOD);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the ADC and PIT with callbacks
 *
 * This test configures one ADC channel with interrupt on completion
 * The PIT callback is used to schedule the conversions.
 * The ADC callback is used to report the results.
 */
void demonstrateADC_PIT(void) {
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);

   // Initialise ADC
   configureADCPins();
   adc0_initialise(adc_singleEnded12_13bitConversion);

   // Set ADC callback to ADC handler
   adc0_setCallbackFunction(adcHandler);

   // Configure PIT
   pit_setCallbackFunction(0, adcTrigger);

   // Set PIT callback to ADC trigger
   pit_initialise(0, ADC_PERIOD);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the ADC with callbacks
 *
 * This test configures the ADC channel for the light sensor.
 * It runs the ADC in polled fashion.
 */
void demonstrateADC(void) {
   configureADCPins();
   adc0_initialise(adc_singleEnded12_13bitConversion);

   for (;;) {
      adcHandler(adc0_doConversion(ADC_IN_LIGHT_SENSOR, adc_polled));
   }
}

/*
 * Demonstrate the I2C interface and Accelerometer
 *
 * This test configures the I2C interface
 * It then does basic a basic interface to the accelerometer.
 * The accelerometer values are reported using a polling loop
 */
void demonstrateAccelerometer(void) {
   #define SCALE (1000)  // 3 decimal digits in fraction
   i2c_initialise(0x00, 400000);
   MMA845x_Initialise(MMA45x_2Gmode);
   for(;;) {
      int status, x,y,z;
      // Get accelerometer values
      // The values are an integer in the range approximately +/- 2**13 representing +/- 2g
      MMA845x_ReadXYX(&status, &x, &y, &z);

      // Determine sign & make positive
      char xSign = ' ';
      char ySign = ' ';
      char zSign = ' ';
      if (x<0) {
         x = -x;
         xSign = '-';
      }
      if (y<0) {
         y = -y;
         ySign = '-';
      }
      if (z<0) {
         z = -z;
         zSign = '-';
      }
      // Scale values
      x = (x*SCALE)/(1<<14);
      y = (y*SCALE)/(1<<14);
      z = (z*SCALE)/(1<<14);
      // Report values
      printf("Status=%X, X=%c%1d.%03dg, Y=%c%1d.%03dg, Z=%c%1d.%03dg\n", status, xSign, x/SCALE, x%SCALE,  ySign, y/SCALE, y%SCALE, zSign, z/SCALE, z%SCALE);
   }
}

/*
 * Demonstrate the RTC
 *
 * This test does the following:
 *  The RTC 1 second callback is used to toggle the Blue LED.
 *
 *  The RTC functionality is integrated with the C "time" functions.
 *  The current time is reported every second.
 *
 *  An Alarm is reset for every 10 seconds.
 *  The RTC alarm callback reports the current time ~ alarm time.
 *
 *  NOTE: Since the time has not been set correctly this will be erroneous.
 *  NOTE: On KL25 it is necessary to connect PTC3 -> PTC1 to provide a suitable RTC clock
 *
 *  Commented out:
 *  Continuously report the RTC counter values.
 */
void demonstrateRTC(void) {
   printf("SYSTEM_BUS_CLOCK clock  = %lu\n", SYSTEM_BUS_CLOCK);
   printf("SYSTEM_CORE_CLOCK clock = %lu\n", SYSTEM_CORE_CLOCK);

   led_initialise();

   // For KL25 output Slow IRC on PTC3 (~ 32 Khz)
   configureClockOutPin();

   // For KL25 input RTC_CLKIN on PTC1
   configureRTCClockInPin();

   rtc_setSecondsCallback(blueLedToggle);
   rtc_setAlarmCallback(clockAlarm, rtc_getTime()+10);
   unsigned lastTick = 0;
   for(;;) {
      unsigned currentTick = RTC_TSR;
      if (currentTick != lastTick) {
         // Executed @ 1Hz
         clockTick();
         lastTick = currentTick;
      }
//      printf("RTC_TCR:RTC_TPR = %lu:%lu \n", RTC_TSR, RTC_TPR);
   }
}

/* Example use of interrupt handler
 *
 * The standard ARM libraries provide basic support for the system timer
 * This function is used for the System Timer interrupt handler.
 *
 */
void SysTick_Handler(void) {
   __asm__("nop");
   __asm__("nop");
   greenLedToggle();
}



//==================================================================
int main(void) {
   printf("\n"
         "==========================\n"
         "Starting\n"
         "==========================\n");

   __enable_interrupt();

   /*
    * Report clock settings
    */
   printf("Core Clock = %lu Hz, Bus clock = %lu Hz, Peripheral Clock = %lu Hz\n",
          SYSTEM_CORE_CLOCK, SYSTEM_BUS_CLOCK, SYSTEM_PERIPHERAL_CLOCK);

//   mainDemonstration();
   demonstrateAccelerometer();
//   demonstrateADC();
//   demonstrateADC_PIT();
//   demonstrateFTM();
//   demonstrateLPTMR();
//   demonstratePIT();
//   demonstratePWM();
//   demonstrateRTC();
   return 0;
}
