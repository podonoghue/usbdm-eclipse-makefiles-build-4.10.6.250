/*
 * lcd_fonts.h
 *
 *  Created on: May 14, 2013
 *      Author: podonoghue
 */

#ifndef LCD_FONTS_H_
#define LCD_FONTS_H_

extern const unsigned char FONT6x8[97][8];
extern const unsigned char FONT8x8[97][8];
extern const unsigned char FONT8x16[97][16];

#endif /* LCD_FONTS_H_ */
