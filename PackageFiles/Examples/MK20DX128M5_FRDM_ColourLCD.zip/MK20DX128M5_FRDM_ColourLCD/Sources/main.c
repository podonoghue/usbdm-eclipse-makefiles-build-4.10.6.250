/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include "derivative.h"
#include "leds.h"
#include "timer.h"
#include "nokia_LCD.h"


void port_initialise() {
   // Enable all port clocks
   SIM_SCGC5 |=   SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;
}

#define BACKGROUND_COLOUR (RED)
#define BALL_COLOUR       (BLUE)

#define BALL_SIZE         (10)

void bounceBlock(int x, int y, int xInc, int yInc) {
   lcd_clear(BACKGROUND_COLOUR);

   for (;;) {
      int newX;
      int newY;
      
      if (x+xInc > LCD_X_MAX-BALL_SIZE) {
         xInc = -xInc;
      }
      if (x+xInc < LCD_X_MIN) {
         xInc = -xInc;
      }
      if (y+yInc > LCD_Y_MAX-BALL_SIZE) {
         yInc = -yInc;
      }
      if (y+yInc < LCD_Y_MIN) {
         yInc = -yInc;
      }
      newX = x + xInc;
      newY = y + yInc;

      lcd_drawRect(x,    y,    x+BALL_SIZE,    y+BALL_SIZE,    1, BACKGROUND_COLOUR);
      lcd_drawRect(newX, newY, newX+BALL_SIZE, newY+BALL_SIZE, 1, BALL_COLOUR);
      
      x = newX;
      y = newY;
      
      WAIT_MS(50);
   }
}

void drawBall(int x, int y, int colour) {
   int radius;
   for(radius = 0; radius<BALL_SIZE/2; radius++) {
      lcd_drawCircle(x, y, radius, colour, FULLCIRCLE);
   }
}

void bounceBall(int x, int y, int xInc, int yInc) {
   lcd_clear(BACKGROUND_COLOUR);

   for (;;) {
      int newX;
      int newY;
      
      if (x+xInc > LCD_X_MAX-BALL_SIZE/2) {
         xInc = -xInc;
      }
      if (x+xInc < LCD_X_MIN+BALL_SIZE/2) {
         xInc = -xInc;
      }
      if (y+yInc > LCD_Y_MAX-BALL_SIZE/2) {
         yInc = -yInc;
      }
      if (y+yInc < LCD_Y_MIN+BALL_SIZE/2) {
         yInc = -yInc;
      }
      newX = x + xInc;
      newY = y + yInc;
      drawBall(x,    y,    BACKGROUND_COLOUR);
      drawBall(newX, newY, BALL_COLOUR);
//      lcd_drawCircle(x,    y,    BALL_SIZE/2, BACKGROUND_COLOUR, FULLCIRCLE);
//      lcd_drawCircle(newX, newY, BALL_SIZE/2, BALL_COLOUR,       FULLCIRCLE);
      x = newX;
      y = newY;
      
      WAIT_MS(50);
   }
}

int main(void) {
   port_initialise();
   led_initialise();
   timer_initialise();
   greenLedOn();

   lcd_initialise();

//   bounceBall(15,25,1,3);
//   bounceBlock(15,25,1,3);

   //   for(;;) {
   lcd_clear(RED);
   //lcd_drawLine(10, 10, 100, 100, GREEN);
   lcd_drawRect(10, 10, 20, 20, 1, WHITE);
   lcd_drawRect(10, 40, 20, 50, 1, BLUE);

   lcd_drawRect(8, 60, 60, 105, 1, WHITE);
   lcd_putStr("Hello", 10,   92, FontSmall,  RED, WHITE);
   lcd_putStr("There", 10,   80, FontMedium, RED, WHITE);
   lcd_putStr("Peter", 10,   60, FontLarge,  RED, WHITE);

   //	   lcd_drawLine(10,20,100,120, WHITE);

   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_0_45);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_45_90);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_90_135);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_135_180);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_180_225);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_225_270);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_270_315);
   //	   lcd_drawCircle(50, 50, 24, GREEN, SECTOR_315_360);

   //	   lcd_drawCircle(50, 50, 26, GREEN, SECTOR_0_45|SECTOR_45_90);
   //	   lcd_drawCircle(50, 50, 26, WHITE, SECTOR_90_135|SECTOR_135_180);
   //	   lcd_drawCircle(50, 50, 26, BLACK, SECTOR_180_225|SECTOR_225_270);
   //	   lcd_drawCircle(50, 50, 26, BLUE,  SECTOR_270_315|SECTOR_315_360);

   //	   lcd_drawCircle(50, 50, 28, GREEN, SECTOR_0_45|SECTOR_45_90|SECTOR_90_135|SECTOR_135_180);
   //	   lcd_drawCircle(50, 50, 28, BLACK, SECTOR_180_225|SECTOR_225_270|SECTOR_270_315|SECTOR_315_360);

   //	   lcd_drawCircle(50, 50, 30, GREEN, SECTOR_0_45|SECTOR_45_90|SECTOR_90_135|SECTOR_135_180|SECTOR_180_225|SECTOR_225_270|SECTOR_270_315|SECTOR_315_360);

   lcd_drawCircle(100, 20, 10, WHITE, SECTOR_90_135|SECTOR_135_180|SECTOR_180_225|SECTOR_225_270);
   lcd_drawCircle(100, 40, 10, WHITE, SECTOR_270_315|SECTOR_315_360|SECTOR_0_45|SECTOR_45_90);
   lcd_drawCircle(100, 60, 10, WHITE, SECTOR_90_135|SECTOR_135_180|SECTOR_180_225|SECTOR_225_270);
   lcd_drawCircle(100, 80, 10, WHITE, SECTOR_270_315|SECTOR_315_360|SECTOR_0_45|SECTOR_45_90|SECTOR_90_135|SECTOR_135_180);
   lcd_drawCircle( 80, 80, 10, WHITE, SECTOR_180_225|SECTOR_225_270|SECTOR_270_315|SECTOR_315_360);
   //   }

   //   int i;
   //   for (i=0; i<=127; i++) {
   //      char buff[10];
   //      LCDSetContrast(i);
   ////      LCDDrawRect(90, 90, 120, 120, 1, WHITE);
   //      sprintf(buff, "%3d", i);
   //      LCDPutStr(buff, 1, 1, RED, WHITE);
   //      WAIT_MS(200);
   //   }
   //   
   //   for(;;) {
   //      lcd_clear(RED);
   //      WAIT_MS(1000);
   //      lcd_clear(GREEN);
   //      WAIT_MS(1000);
   //      lcd_clear(BLUE);
   //      WAIT_MS(1000);
   //   }
   //   for(;;) {
   //    homeLCD();
   //    putsLCD("Hello world!!!");
   //    WAIT_MS(10);
   //   }
   //   for(;;) {
   //      LED_GRN_TOGGLE();
   //      WAIT_MS(1000);
   //      LED_GRN_TOGGLE();
   //      WAIT_MS(1000);
   //      LED_RED_TOGGLE();
   //      WAIT_MS(1000);
   //      LED_RED_TOGGLE();
   //      WAIT_MS(1000);
   //      LED_BLUE_TOGGLE();
   //      WAIT_MS(1000);
   //      LED_BLUE_TOGGLE();
   //      WAIT_MS(1000);
   //   }
   for(;;) {

   }
}


