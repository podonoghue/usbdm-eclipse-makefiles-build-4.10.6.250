/*
 * timer.cpp
 *
 *  Created on: 12/05/2013
 *      Author: podonoghue
 */

#include "derivative.h"
#include "timer.h"

//=========================================================================
// Timer routines
//
//=========================================================================

//! Wait for given time in timer ticks
//!
//!  @param delay Delay time in fast timer ticks
//!
//!  @note Limited to ?? ms
//!
void fastTimerWait(uint32_t delay) {
	PIT_LDVAL0 = delay;                  // Set up delay
	PIT_TFLG0  = PIT_TFLG_TIF_MASK;      // Clear timer flag
	PIT_TCTRL0 = PIT_TCTRL_TEN_MASK;     // Enable (and reset) timer
	while ((PIT_TFLG0&PIT_TFLG_TIF_MASK) == 0) { // Wait for timeout
	}
	PIT_TCTRL0 = 0;                      // Disable timer
}

//! Wait for given time in milliseconds
//!
//! @param delay Delay time in milliseconds
//!
void millisecondTimerWait(uint16_t delay) {
	PIT_LDVAL0 = TIMER_MICROSECOND(1000); // Set up delay
	PIT_TCTRL0 = PIT_TCTRL_TEN_MASK;      // Enable (and reset) timer
	while (delay-->0) {
		PIT_TFLG0  = PIT_TFLG_TIF_MASK;              // Clear timer flag
		while ((PIT_TFLG0&PIT_TFLG_TIF_MASK) == 0) { // Wait for timeout
		}
	}
	PIT_TCTRL0 = 0;                       // Disable timer
}

//! Initialises the timers, input captures and interrupts
//!
uint8_t timer_initialise(void) {

	SIM_SCGC6 |= SIM_SCGC6_PIT_MASK;
	PIT_MCR    = PIT_MCR_FRZ_MASK; // Enable timers

	return 0;
}



