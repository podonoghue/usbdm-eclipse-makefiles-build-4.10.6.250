/*
 * sysinit.c
 *
 * Generic system initialization for Coldfire V1
 *
 *  Created on: 07/12/2012
 *      Author: podonoghue
 */

#include <stdint.h>
#include "derivative.h"
#include "clock.h"

#define DEVICE_SUBFAMILY_CFV1Plus

#ifndef SIM_COPC
#define SIM_COPC (*(uint8_t*) (0xFF80C0+0x0A))
#endif


void sysInit(void) {
   // This is generic initialization code
   // It may not be correct for a specific target

#ifdef SOPT1
   // Disable watch-dog
   SOPT1 = 0x00;
#endif
#ifdef SIM_COPC
   // Disable watch-dog
   SIM_COPC = 0x00;
#endif
   clock_initialise();
}
