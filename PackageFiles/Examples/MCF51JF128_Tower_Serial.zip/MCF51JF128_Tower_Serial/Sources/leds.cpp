#include "derivative.h"
#include "Freedom.h"

#define ORANGE_LED_PTxPF        MXC_PTAPF4
#define ORANGE_LED_PTxPF_n(x)   MXC_PTAPF4_A0(x)
#define ORANGE_LED_FN           (1)
#define ORANGE_LED_DD           PTA_DD
#define ORANGE_LED_D            PTA_D
#define ORANGE_LED_MASK         (1<<0)

#define GREEN_LED_PTxPF         MXC_PTCPF2
#define GREEN_LED_PTxPF_n(x)    MXC_PTCPF2_C5(x)
#define GREEN_LED_FN            (1)
#define GREEN_LED_DD            PTC_DD
#define GREEN_LED_D             PTC_D
#define GREEN_LED_MASK          (1<<5)

void greenLedOn(void) {
   GREEN_LED_D &= ~GREEN_LED_MASK;
}
void greenLedOff(void) {
   GREEN_LED_D |= GREEN_LED_MASK;
}
void greenLedToggle(void) {
   GREEN_LED_D ^= GREEN_LED_MASK;
}
#ifdef ORANGE_LED_MASK
void orangeLedOn(void) {
   ORANGE_LED_D &= ~ORANGE_LED_MASK;
}
void orangeLedOff(void) {
   ORANGE_LED_D |= ORANGE_LED_MASK;
}
void orangeLedToggle(void) {
   ORANGE_LED_D ^= ORANGE_LED_MASK;
}
#endif

void led_initialise(void) {
   greenLedOff();
   ORANGE_LED_PTxPF = (ORANGE_LED_PTxPF & ~ORANGE_LED_PTxPF_n(0xF))|ORANGE_LED_PTxPF_n(ORANGE_LED_FN);
   ORANGE_LED_DD   |= ORANGE_LED_MASK;

   orangeLedOff();
   GREEN_LED_DD    |= GREEN_LED_MASK;
   GREEN_LED_PTxPF  = (GREEN_LED_PTxPF & ~GREEN_LED_PTxPF_n(0xF))|GREEN_LED_PTxPF_n(GREEN_LED_FN);
}
