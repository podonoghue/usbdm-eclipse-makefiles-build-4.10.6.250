/*
 * Example code for ADC on Kinetis devices
 */
#include "derivative.h" /* include peripheral declarations */
#include "adc.h"

#define ADC_CFG1_ADIV_VALUE (3)
#define ADC_CLOCK_DIVIDER_FACTOR (1<<ADC_CFG1_ADIV_VALUE)
#define ADC_CFG1_ADICLK_VALUE (1)

/*
 * Initialisation the ADC
 */
void adc_initialise(adc_mode mode) {

   // Enables clock to ADC
   SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;

   // Configure ADC for software triggered conversion
   ADC0_CFG1 = ADC_CFG1_ADIV(ADC_CFG1_ADIV_VALUE)|mode|ADC_CFG1_ADLSMP_MASK|ADC_CFG1_ADICLK(ADC_CFG1_ADICLK_VALUE);
   ADC0_SC2  = 0;
   ADC0_CFG2 = ADC_CFG2_ADLSTS(0);
}

/*
 * Initiates a conversion and waits for it to complete
 *
 * @return - the result of the conversion
 */
int adc_doConversion(unsigned channel) {

   // Trigger conversion
   ADC0_SC1A = ADC_SC1_ADCH(channel);
   while ((ADC0_SC1A&ADC_SC1_COCO_MASK) == 0) {
   }
   return (int)ADC0_RA;
}
