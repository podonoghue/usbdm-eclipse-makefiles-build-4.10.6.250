/*
 * pwm.c
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */
#include <stddef.h>
#include "derivative.h"
#include "utilities.h"
#include "clock.h"
#include "clock_private.h"
#include "tpm0.h"

#if (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK0)
#define TPM_SC_CMOD_VALUE (0)
#elif (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK1)
#define TPM_SC_CMOD_VALUE (1)
#elif (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK2)
#define TPM_SC_CMOD_VALUE (2)
#elif (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK3)
#define TPM_SC_CMOD_VALUE (3)
#else
#error "Check _TPM0_CLOCK_FREQUENCY_BASE value in pwm.h"
#endif

#define TPM0_NUM_CHANNELS (8)

/*! Initialises TPM0 for PWM
 *
 *  @param period  - PWM Period in ticks (use PWM0_MILLISECOND() macro)
 *  @param mode    - Left- or centre-align all waveforms from this PWM
 *
 * Configures:
 *   - Enables TPM0 clock
 *   - Sets TPM0 CNTIN & MOD values
 *   - Enables TPM0
 */
void tpm0_initialiseAsPWM(int period /* ticks */, Pwm_Mode mode) {

   // Enable clock to TPM0
   SIM_SCGC6  |= SIM_SCGC6_TPM0_MASK;

   // Common registers
   TPM0_SC      = TPM_SC_CMOD(0); // Disable TPM so register changes are immediate
   TPM0_CNT     = 0;
   if (mode == tpm_centreAlign) {
      TPM0_MOD     = period/2;
      // Centre aligned PWM with CPWMS not selected
      TPM0_SC      = TPM_SC_CMOD(TPM_SC_CMOD_VALUE)|TPM_SC_PS(_TPM0_PRESCALE_VALUE)|TPM_SC_CPWMS_MASK;
   }
   else {
      TPM0_MOD     = period-1;
      // Left aligned PWM without CPWMS selected
      TPM0_SC      = TPM_SC_CMOD(TPM_SC_CMOD_VALUE)|TPM_SC_PS(_TPM0_PRESCALE_VALUE);
   }
}

/*! Initialises TPM0 for Input capture/Output compare
 *
 * Configures:
 *   - Enables TPM0 clock
 *   - Sets TPM0 CNTIN & MOD values
 *   - Enables TPM0
 *
 *  Assumes Left-aligned PWM
 */
void tpm0_initialise(void) {
   tpm0_initialiseAsPWM(0xFFFF, tpm_leftAlign);
}

/*! Initialises TPM0 for Input capture/Output compare
 *
 *  @param channel   - TPM0 channel to initialise
 *  @param mode      - Mode for the channel
 */
void tpm0_initialiseChannel(int channel, Ftm_Mode mode) {
   TPM0->CONTROLS[channel].CnV  = 0;
   TPM0->CONTROLS[channel].CnSC = mode;
}

/*!
 *  Sets the duty cycle of the PWM waveform
 *
 *  @param channel   - TPM0 channel to use
 *  @param dutyCycle - duty cycle in percentage (0-100)
 *
 */
void tpm0_setDutyCycle(int channel, int dutyCycle) {
   if (TPM0_SC&TPM_SC_CPWMS_MASK) {
      TPM0->CONTROLS[channel].CnV  = (dutyCycle*TPM0_MOD)/100;
   }
   else {
      TPM0->CONTROLS[channel].CnV  = (dutyCycle*(TPM0_MOD+1))/100;
   }
}

/*!
 *  Disables a TPM channel or entire TPM
 *
 *  @param channel   - TPM0 channel to disable, -1 disable entire TPM
 *
 */
void tpm0_finaliseChannel(int channel) {
   if (channel<0) {
      TPM0_SC = TPM_SC_CMOD(0);
      NVIC_DisableIRQ(TPM0_IRQn);
   }
   else {
      // Clear channel register
      TPM0->CONTROLS[channel].CnSC = 0;
   }
}

#ifndef TPM_USES_NAKED_HANDLERS

typedef struct {
   TPMCallbackFunction callback;
   uint16_t            interval;
} FtmChannelInformation;

static FtmChannelInformation ftmChannelInformation[TPM0_NUM_CHANNELS] = {{NULL,0}};

/*! Initialises TPM0 for Input capture/Output compare
 *
 *  @param channel   - TPM0 channel to initialise
 */
TPMCallbackFunction tpm0_setCallbackFunction(int channel, TPMCallbackFunction callback, uint16_t interval) {

   TPMCallbackFunction temp = ftmChannelInformation[channel].callback;
   ftmChannelInformation[channel].callback = callback;
   ftmChannelInformation[channel].interval = interval;
   TPM0->CONTROLS[channel].CnSC |= TPM_CnSC_CHIE_MASK;
   NVIC_EnableIRQ(TPM0_IRQn);
   return temp;
}

void TPM0_IRQHandler(void) {
   // This method is better for the usual case of a single interrupt at a time
   int channel = 0;
   int status  = TPM0_STATUS;
   if (status & 0xF0) {
      channel = 4;
      status  &= 0xF0;
   }
   if (status & 0xCC) {
      channel += 2;
      status  &= 0xCC;
   }
   if (status & 0xAA) {
      channel++;
   }
   // Clear flag
   TPM0->CONTROLS[channel].CnV &= ~TPM_CnSC_CHF_MASK;
   if (ftmChannelInformation[channel].interval != 0) {
      // Set interval
      TPM0->CONTROLS[channel].CnV += ftmChannelInformation[channel].interval;
   }
   if (ftmChannelInformation[channel].callback != NULL) {
      // Do callback
      ftmChannelInformation[channel].callback();
   }
}
#endif
