/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include <stdbool.h>
#include <sys/time.h>
#include <time.h>
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "Freedom.h"
#include "pit.h"
#include "lptmr.h"
#include "tpm0.h"
#include "rtc.h"
#include "adc0.h"
#include "i2c.h"
#include "MMA845x.h"

// Miscellaneous ==============================================================

/*
 * Toggles the BLUE LED between enabled and disabled
 */
static void blueLedToggleEnable(void) {
   static bool oddEven = true;

   if (oddEven) {
      blueLedEnable();
   }
   else {
      blueLedDisable();
   }
   oddEven = !oddEven;
}

/*
 * Configures the CLOCKOUT pin
 */
static void configureClockOutPin(void) {
   // PTC3(Fn5) = CLKOUT
   SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   PORTC_PCR3 = PORT_PCR_MUX(5);

   // CLKOUT = CLKOUTSEL(4) = MCGIRCLK
   SIM_SOPT2 = (SIM_SOPT2&~SIM_SOPT2_CLKOUTSEL_MASK)|SIM_SOPT2_CLKOUTSEL(4);
}

/*
 * Configures the CLOCKIN pin
 */
static void configureRTCClockInPin(void) {
   // PTC1(Fn1) = RTC_CLKIN
   SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   PORTC_PCR1 = PORT_PCR_MUX(1);
}

// LPTMR ==============================================================

#define LPTMR_INTERVAL LPTMR_MILLISECOND_TO_TICKS(10)

#if (LPTMR_INTERVAL>65536)
#error "LPTMR Value is too large"
#endif

// RTC ==============================================================

/*
 * Reports the current RTC time on the terminal
 */
static void clockTick(void) {
   time_t currentTime;
   struct tm *timeInfo;

   currentTime = time(NULL);
   timeInfo = localtime(&currentTime);
   printf("\'Tick\' - %s", asctime(timeInfo));
}

/*
 * Report an Alarm time on the terminal
 */
static void clockAlarm(void) {
   // Set next alarm for 10 seconds from last alarm
   uint32_t theTime   = rtc_getTime() + 5;
   uint32_t alarmTime = rtc_getAlarmTime() + 10;
   if (theTime>alarmTime) {
      alarmTime = theTime;
   }
   rtc_setAlarmTime(alarmTime);
   time_t currentTime;
   struct tm *timeInfo;

   currentTime = time(NULL);
   timeInfo = localtime(&currentTime);
   printf("\'**** ALARM ****\' - %s", asctime(timeInfo));

}

static unsigned tick = 0;
/*
 * Used to flag the passing of time
 */
static void rtcCallback(void) {
   tick++;
}

// PWM0/FTM0 ==============================================================

#define TPM0_CH0_PERIOD TPM0_MILLISECONDS_TO_TICKS(1)
#if TPM0_CH0_PERIOD > 65535
#error "TPM0_CH0_PERIOD is too large"
#endif
#if TPM0_CH0_PERIOD < 10
#error "FTM0_CH0_PERIOD is too small"
#endif

#define TPM0_CH1_PERIOD TPM0_MILLISECONDS_TO_TICKS(20)
#if TPM0_CH1_PERIOD > 65535
#error "TPM0_CH1_PERIOD is too large"
#endif
#if TPM0_CH1_PERIOD < 40
#error "FTM0_CH1_PERIOD is too small"
#endif

#define TPM0_PERIOD (TPM0_MILLISECONDS_TO_TICKS(100))

#if (TPM0_PERIOD<200)
#error "TPM0_PERIOD is too small (resolution < 1%)"
#endif
#if (TPM0_PERIOD>65535)
#error "TPM0_PERIOD is too large"
#endif

// PTC1(Fn4) = TPM0_CH0 = PWM0_CH0
#define TPM0_CH0_PORT     C
#define TPM0_CH0_PIN_NUM  1
#define TPM0_CH0_FN       4
#define TPM0_CH0_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTC2(Fn4) = TPM0_CH1 = PWM0_CH1
#define TPM0_CH1_PORT     C
#define TPM0_CH1_PIN_NUM  2
#define TPM0_CH1_FN       4
#define TPM0_CH1_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTC4(Fn4) = TPM0_CH3 = PWM0_CH3
#define TPM0_CH3_PORT         C
#define TPM0_CH3_PIN_NUM      4
#define TPM0_CH3_FN           4
#define TPM0_CH3_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTE20(Fn3) = TPM1_CH0 = PWM1_CH0
#define TPM1_CH0_PORT     E
#define TPM1_CH0_PIN_NUM  20
#define TPM1_CH0_FN       3
#define TPM1_CH0_CLOCK_MASK   SIM_SCGC5_PORTE_MASK

// PTE22(Fn3) = TPM0_CH0 = PWM2_CH0
#define TPM2_CH0_PORT     E
#define TPM2_CH0_PIN_NUM  22
#define TPM2_CH0_FN       3
#define TPM2_CH0_CLOCK_MASK   SIM_SCGC5_PORTE_MASK

static void configureTPMPins(void) {
   SIM_SCGC5 |= TPM0_CH0_CLOCK_MASK|TPM0_CH1_CLOCK_MASK|TPM0_CH3_CLOCK_MASK|TPM1_CH0_CLOCK_MASK|TPM2_CH0_CLOCK_MASK;
//   PCR(TPM0_CH0_PORT,TPM0_CH0_PIN_NUM) = PORT_PCR_MUX(TPM0_CH0_FN);
   PCR(TPM0_CH1_PORT,TPM0_CH1_PIN_NUM) = PORT_PCR_MUX(TPM0_CH1_FN);
   PCR(TPM0_CH3_PORT,TPM0_CH3_PIN_NUM) = PORT_PCR_MUX(TPM0_CH3_FN);
//   PCR(TPM1_CH0_PORT,TPM1_CH0_PIN_NUM) = PORT_PCR_MUX(TPM1_CH0_FN);
//   PCR(TPM2_CH0_PORT,TPM2_CH0_PIN_NUM) = PORT_PCR_MUX(TPM2_CH0_FN);
}

 /*
  * Configure the LED pins as PWM (= FTM function)
  */
static void configureRGB_PWMPins(void) {
   SIM_SCGC5 |= PORT_CLOCK_MASK(LED_GREEN_PORT)|PORT_CLOCK_MASK(LED_BLUE_PORT)|PORT_CLOCK_MASK(LED_RED_PORT);
   PCR(LED_RED_PORT,  LED_RED_NUM)   = PORT_PCR_MUX(LED_RED_FTM_FN);
   PCR(LED_GREEN_PORT,LED_GREEN_NUM) = PORT_PCR_MUX(LED_GREEN_FTM_FN);
   PCR(LED_BLUE_PORT, LED_BLUE_NUM)  = PORT_PCR_MUX(LED_BLUE_FTM_FN);
}

// PIT ==============================================================

#define PIT_CH0_PERIOD PIT_MILLISECOND_TO_TICKS(10)
#define PIT_CH1_PERIOD PIT_MILLISECOND_TO_TICKS(200)

// ADC ==============================================================

#define ADC_PERIOD PIT_MILLISECOND_TO_TICKS(1000)

#define ADC_OUTPUT_RANGE ((1<<12)-1) // 12 bit
#define ADC_INPUT_HIGH   (3300)      // Scaled by x1000
#define ADC_INPUT_LOW    (0)

#define ADC_INTERVAL (PIT_MILLISECOND_TO_TICKS(400))

#define ADC_IN_PIN   adc_channel_se8  // A0

// PTB0(Fn0) = ADC0_SE8
#define ADC0_SE8_PORT     B
#define ADC0_SE8_PIN_NUM  0
#define ADC0_SE8_FN       0
#define ADC0_SE8_CLOCK_MASK   SIM_SCGC5_PORTB_MASK

/*
 * Configures ADC pins as analogue
 */
static void configureADCPins(void) {
   SIM_SCGC5 |= ADC0_SE8_CLOCK_MASK;
   PCR(ADC0_SE8_PORT, ADC0_SE8_PIN_NUM) = PORT_PCR_MUX(ADC0_SE8_FN);
}

/*
 * Handler for ADC - prints out the ADC Value
 *
 * @param value - value from ADC output register
 */
static void adcHandler(int value) {
   value = ((value *(ADC_INPUT_HIGH-ADC_INPUT_LOW))/ADC_OUTPUT_RANGE)+ADC_INPUT_LOW;
   printf("ADC0_SE8 Input = %d.%03d V\n", value/1000, value%1000);
}

/*
 * Triggers a conversion on the light sensor ADC channel
 */
static void adcTrigger(void) {
   // Configure next conversion
   adc0_doConversion(ADC_IN_PIN, adc_interrupt);
}

// I2C ==============================================================

#define PWM_LED_PERIOD (TPM0_MILLISECONDS_TO_TICKS(10))

#if (PWM_LED_PERIOD<200)
#error "PWM_LED_PERIOD is too small (resolution < 1%)"
#endif
#if (PWM_LED_PERIOD>65535)
#error "PWM_LED_PERIOD is too large"
#endif

#define ACCELEROMETER_INTERVAL (PIT_MILLISECOND_TO_TICKS(200))

/*
 * Polls the accelerometer and sets the PWM channels accordingly
 */
static void accelerometerHandler() {
   int status, x,y,z;
   MMA845x_ReadXYX(&status, &x, &y, &z);

   // Scale values to ~[0-100]
   x = (x*50)/(1<<14) + 50;
   y = (y*50)/(1<<14) + 50;
   z = (z*50)/(1<<14) + 50;

   if (x<0) x = 0;
   if (y<0) y = 0;
   if (z<0) z = 0;

   if (x>100) x = 100;
   if (y>100) y = 100;
   if (z>100) z = 100;

   tpm0_setDutyCycle(LED_BLUE_FTM_CHANNEL,  z);
// On wrong TPM
//   tpm0_setDutyCycle(LED_RED_FTM_CHANNEL,   x);
//   tpm0_setDutyCycle(LED_GREEN_FTM_CHANNEL, y);

   // Report values - will clash with other handlers
//   printf("Status=%X, X=%3d, Y=%3d, Z=%3d\n", status, x, y, z);
}

/*
 * This demonstration uses the following:
 *    - 3 PWM channels to control the RGB LED
 *    - I2C interface to communicate with the accelerometer
 *    - RTC to display the current time
 *    - ADC to measure the light sensor
 *    - PIT to control when the various measurements are made
 */
static void mainDemonstration(void) {
   /*
    * Set up FTM-PWM channels for 3 LEDs
    */
   printf("FTM Base Clock = %lu, FTM clock = %lu Hz, interval = %lu\n", _TPM0_CLOCK_FREQUENCY_BASE, TPM0_CLOCK_FREQUENCY, TPM0_PERIOD);

   /*
    * Set up PWM for the three LEDs
    */
   configureRGB_PWMPins();
   tpm0_initialiseAsPWM(PWM_LED_PERIOD, tpm_centreAlign);
   tpm0_initialiseChannel(LED_BLUE_FTM_CHANNEL,  tpm_pwmHighTruePulses);
//   tpm0_initialiseChannel(LED_GREEN_FTM_CHANNEL, tpm_pwmHighTruePulses);
//   tpm0_initialiseChannel(LED_RED_FTM_CHANNEL,   tpm_pwmHighTruePulses);
   tpm0_setDutyCycle(LED_BLUE_FTM_CHANNEL,  50);
//   tpm0_setDutyCycle(LED_GREEN_FTM_CHANNEL, 50);
//   tpm0_setDutyCycle(LED_RED_FTM_CHANNEL,   50);

   /*
    * Set up PIT callback for accelerometer
    */
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);
   i2c_initialise(2);
   MMA845x_Initialise(MMA45x_2Gmode);
   pit_setCallbackFunction(0, accelerometerHandler);
   pit_initialise(0, ACCELEROMETER_INTERVAL);

   /*
    * Set up ADC callback to report light sensor
    */
   adc0_initialise(adc_singleEnded12_13bitConversion, adc_muxa);
   adc0_setCallbackFunction(adcHandler);

   /*
    * Set up ADC trigger to happen every ADC_INTERVAL using PIT
    */
   pit_setCallbackFunction(1, adcTrigger);
   pit_initialise(1, ADC_INTERVAL);

   /*
    * RTC callback
    */
   rtc_setAlarmCallback(clockAlarm, rtc_getTime()+10);
   rtc_setSecondsCallback(rtcCallback);

   // For KL25 output Slow IRC on PTC3 (~ 32 Khz)
   configureClockOutPin();
   // For KL25 input RTC_CLKIN on PTC1
   configureRTCClockInPin();

   printf("LPTMR clock = %lu Hz, interval = %lu\n", LPTMR_CLOCK_FREQUENCY, LPTMR_INTERVAL);

   for(;;) {
      __wait_for_interrupt();
      unsigned lastTick = 0;
      if (tick != lastTick) {
         // Executed @ 1Hz
         clockTick();
      }
      lastTick = tick;
   }
}

/*
 * Demonstrates the FTM Output Compare
 *
 * This test configures two FTM channels to toggle their respective pins in hardware.
 * In addition the callbacks are used to pulse modulate the Blue LED.
 */
static void demonstrateTPM(void) {
   printf("FTM Base Clock = %lu Hz, FTM clock = %lu Hz, CH0 = %lu ticks, CH1 = %lu ticks\n",
          _TPM0_CLOCK_FREQUENCY_BASE, TPM0_CLOCK_FREQUENCY, TPM0_CH0_PERIOD, TPM0_CH1_PERIOD);

   led_initialise();

   configureTPMPins();
   tpm0_initialise();
   tpm0_initialiseChannel(0,tpm_outputCompareToggle);
   tpm0_setCallbackFunction(0,blueLedToggle,TPM0_CH0_PERIOD);
   tpm0_initialiseChannel(1,tpm_outputCompareToggle);
   tpm0_setCallbackFunction(1,blueLedToggleEnable,TPM0_CH1_PERIOD);

   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the FTM acting as a PWM
 *
 * This test configures three FTM channels as PWM with fixed duty-cycle.
 * Channels are centre-aligned.
 */
static void demonstratePWM(void) {
   printf("FTM Base Clock = %lu, FTM clock = %lu Hz, interval = %lu\n", _TPM0_CLOCK_FREQUENCY_BASE, TPM0_CLOCK_FREQUENCY, TPM0_PERIOD);

   configureTPMPins();
   tpm0_initialiseAsPWM(TPM0_PERIOD, tpm_centreAlign);

   tpm0_initialiseChannel(1, tpm_pwmHighTruePulses);
   tpm0_initialiseChannel(3, tpm_pwmLowTruePulses);

   tpm0_setDutyCycle(1, 50);
   tpm0_setDutyCycle(3, 25);

   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the LPTMR with callbacks
 *
 * This test configures the Low Power Timer (LPTMR) for a fixed period.
 * A callback is used to modulate the Blue LED.
 */
static void demonstrateLPTMR(void) {
   led_initialise();

   printf("LPTMR clock = %lu Hz, interval = %lu ticks\n", LPTMR_CLOCK_FREQUENCY, LPTMR_INTERVAL);
   lptmr_setCallbackFunction(blueLedToggle);
   lptmr_initialise(LPTMR_INTERVAL);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the PIT with callbacks
 *
 * This test configures two PIT channels
 * Callbacks are used to pulse modulate the Blue LED.
 */
static void demonstratePIT(void) {
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);

   led_initialise();

   pit_setCallbackFunction(0, blueLedToggle);
   pit_initialise(0, PIT_CH0_PERIOD);
   pit_setCallbackFunction(1, blueLedToggleEnable);
   pit_initialise(1, PIT_CH1_PERIOD);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the ADC and PIT with callbacks
 *
 * This test configures one ADC channel with interrupt on completion
 * The PIT callback is used to schedule the conversions.
 * The ADC callback is used to report the results.
 */
static void demonstrateADC_PIT(void) {
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);

   // Initialise ADC
   configureADCPins();
   adc0_initialise(adc_singleEnded12_13bitConversion, adc_muxa);

   // Set ADC callback to ADC handler
   adc0_setCallbackFunction(adcHandler);

   // Configure PIT
   pit_setCallbackFunction(0, adcTrigger);

   // Set PIT callback to ADC trigger
   pit_initialise(0, ADC_PERIOD);
   for(;;) {
      __wait_for_interrupt();
   }
}

/*
 * Demonstrate the ADC with callbacks
 *
 * This test configures the ADC channel for the light sensor.
 * It runs the ADC in polled fashion.
 */
static void demonstrateADC(void) {
   configureADCPins();
   adc0_initialise(adc_singleEnded12_13bitConversion, adc_muxa);

   for (;;) {
      adcHandler(adc0_doConversion(ADC_IN_PIN, adc_polled));
   }
}

/*
 * Demonstrate the I2C interface and Accelerometer
 *
 * This test configures the I2C interface
 * It then does basic a basic interface to the accelerometer.
 * The accelerometer values are reported using a polling loop
 */
static void demonstrateAccelerometer(void) {
   #define SCALE (1000)  // 3 decimal digits in fraction
   i2c_initialise(1);
   MMA845x_Initialise(MMA45x_2Gmode);
   for(;;) {
      int status, x,y,z;
      // Get accelerometer values
      // The values are an integer in the range approximately +/- 2**13 representing +/- 2g
      MMA845x_ReadXYX(&status, &x, &y, &z);

      // Determine sign & make positive
      char xSign = ' ';
      char ySign = ' ';
      char zSign = ' ';
      if (x<0) {
         x = -x;
         xSign = '-';
      }
      if (y<0) {
         y = -y;
         ySign = '-';
      }
      if (z<0) {
         z = -z;
         zSign = '-';
      }
      // Scale values
      x = (x*SCALE)/(1<<14);
      y = (y*SCALE)/(1<<14);
      z = (z*SCALE)/(1<<14);
      // Report values
      printf("Status=%X, X=%c%1d.%03dg, Y=%c%1d.%03dg, Z=%c%1d.%03dg\n", status, xSign, x/SCALE, x%SCALE,  ySign, y/SCALE, y%SCALE, zSign, z/SCALE, z%SCALE);
   }
}

/*
 * Demonstrate the RTC
 *
 * This test does the following:
 *  The RTC 1 second callback is used to toggle the Blue LED.
 *
 *  The RTC functionality is integrated with the C "time" functions.
 *  The current time is reported every second.
 *
 *  An Alarm is reset for every 10 seconds.
 *  The RTC alarm callback reports the current time ~ alarm time.
 *
 *  NOTE: Since the time has not been set correctly this will be erroneous.
 *  NOTE: On KL25 it is necessary to connect PTC3 -> PTC1 to provide a suitable RTC clock
 *
 *  Commented out:
 *  Continuously report the RTC counter values.
 */
static void demonstrateRTC(void) {
   printf("ERCLK32K clock = %lu\n", SYSTEM_ERCLK32_CLOCK);
   printf("MCGIRCLK clock = %lu\n", SYSTEM_MCGIR_CLOCK);

   led_initialise();

   // For KL25 output Slow IRC on PTC3 (~ 32 Khz)
   configureClockOutPin();

   // For KL25 input RTC_CLKIN on PTC1
   configureRTCClockInPin();

   rtc_setSecondsCallback(blueLedToggle);
   rtc_setAlarmCallback(clockAlarm, rtc_getTime()+10);
   for(;;) {
      unsigned lastTick = 0;
      unsigned currentTick = RTC_TSR;
      if (currentTick != lastTick) {
         // Executed @ 1Hz
         clockTick();
         lastTick = currentTick;
      }
//      printf("RTC_TCR:RTC_TPR = %lu:%lu \n", RTC_TSR, RTC_TPR);
   }
}
   //==================================================================
int main(void) {
   printf("\n"
         "==========================\n"
         "Starting\n"
         "==========================\n");

   __enable_interrupt();

   /*
    * Report clock settings
    */
   printf("Core Clock = %lu Hz, Bus clock = %lu Hz, ERCLK32K Clock = %lu Hz, Peripheral Clock = %lu Hz\n",
          SYSTEM_CORE_CLOCK, SYSTEM_BUS_CLOCK, SYSTEM_ERCLK32_CLOCK, SYSTEM_PERIPHERAL_CLOCK);

//   mainDemonstration();
   demonstrateAccelerometer();
//   demonstrateADC();
//   demonstrateADC_PIT();
//   demonstrateTPM();
//   demonstrateLPTMR();
//   demonstratePIT();
//   demonstratePWM();
//   demonstrateRTC();
   return 0;
}
