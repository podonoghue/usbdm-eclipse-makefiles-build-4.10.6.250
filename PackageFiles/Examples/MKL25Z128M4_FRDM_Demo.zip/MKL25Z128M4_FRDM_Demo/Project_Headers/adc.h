/*
 * adc.h
 *
 *  Created on: 17/11/2013
 *      Author: podonoghue
 */

#ifndef ADC_H_
#define ADC_H_

#include "derivative.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
   adc_singleEnded8bitConversion   = ADC_CFG1_MODE(0),
   adc_singleEnded10bitConversion  = ADC_CFG1_MODE(1),
   adc_singleEnded12bitConversion  = ADC_CFG1_MODE(2),
   adc_singleEnded16bitConversion  = ADC_CFG1_MODE(3),
} adc_mode;

int adc_doConversion(unsigned channel);
void adc_initialise(adc_mode mode);

#ifdef __cplusplus
}
#endif


#endif /* ADC_H_ */
