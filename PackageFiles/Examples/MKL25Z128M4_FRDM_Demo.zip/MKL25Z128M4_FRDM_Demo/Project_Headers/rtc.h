/*
 * rtc.h
 *
 *  Created on: 25/10/2013
 *      Author: podonoghue
 */

#ifndef RTC_H_
#define RTC_H_

#ifdef __cplusplus
extern "C" {
#endif

void     rtc_initialise(void);
uint32_t rtc_getTime(void);
uint32_t rtc_getAlarmTime(void);
void     rtc_setAlarmTime(uint timeSinceEpoch);

#ifndef RTC_USES_NAKED_HANDLERS
   typedef void (*RTCCallbackFunction)(void);
   RTCCallbackFunction rtc_setSecondsCallback(RTCCallbackFunction callback);
   RTCCallbackFunction rtc_setAlarmCallback(RTCCallbackFunction callback, uint32_t time);
#endif

#ifdef __cplusplus
}
#endif

#endif /* RTC_H_ */
