/*
 *  Include the derivative-specific header file
 */
#include "MK22FN1M0M12.h"
