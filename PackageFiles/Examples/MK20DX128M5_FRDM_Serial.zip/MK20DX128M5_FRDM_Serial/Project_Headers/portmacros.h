/*
 * portMacros.h
 *
 *  Created on: May 13, 2013
 *      Author: PODonoghue
 */

#ifndef PORTMACROS_H_
#define PORTMACROS_H_

// Used to create port register names
//--------------------------------------------------------
#define CONCAT2_(x,y) x ## y
#define CONCAT3_(x,y,z) x ## y ## z
#define CONCAT4_(w,x,y,z) w ## x ## y ## z

#define PCR(port,num)   CONCAT4_(PORT,port,_PCR,num)
#define PDOR(port)      CONCAT3_(GPIO,port,_PDOR)
#define PSOR(port)      CONCAT3_(GPIO,port,_PSOR)
#define PCOR(port)      CONCAT3_(GPIO,port,_PCOR)
#define PTOR(port)      CONCAT3_(GPIO,port,_PTOR)
#define PDIR(port)      CONCAT3_(GPIO,port,_PDIR)
#define PDDR(port)      CONCAT3_(GPIO,port,_PDDR)

static inline void enableIrq(int irqNum) {
   NVIC_ISER((irqNum-16)/32) = NVIC_ISER_SETENA(1<<((irqNum-16)%32));
}

static inline void disableIrq(int irqNum) {
   NVIC_ICER((irqNum-16)/32) = NVIC_ICER_CLRENA(1<<((irqNum-16)%32));
}


#endif /* PORTMACROS_H_ */
