/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include "derivative.h"
#include "leds.h"
#include "uart.h"

void port_initialise() {
   // Enable all port clocks
   SIM_SCGC5 |=   SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;
}

int main(void) {
   port_initialise();
   led_initialise();
   greenLedOn();

   uart_initialise(19200);

   printf("\n\r"
         "==============================\n\r"
         "       Hello World\n\r"
         "==============================\n\r");

   int i = 0;
   for(;;) {
      printf("i = %d\n\r", i++);
      greenLedToggle();
   }
   return 0;
}
