/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include "derivative.h"
#include "leds.h"



int main(void) {
   led_initialise();
   greenLedOn();

   printf("\n"
         "==============================\n"
         "       Hello World\n"
         "==============================\n");

   int i = 0;
   for(;;) {
      printf("i = %d\n", i++);
      greenLedToggle();
   }
   return 0;
}
