/*
 * clock.cpp
 *
 *  Created on: 04/03/2012
 *      Author: podonoghue
 */
#include "derivative.h" /* include peripheral declarations */
#include "clock.h"

uint32_t const SystemCoreClock = 48000000; // Hz
uint32_t const SystemBusClock  = 24000000; // Hz

void clock_initialise(void);

/*! Sets up the clock for USB operation (out of RESET)
 *!
 *! MCGOUTCLK = 48MHz
 *! core/platform/system clock = PLL (48MHz), 
 *! bus clock = PLL (48MHz),
 *! flash clock = PLL/2 (24MHz)
 *!
 *! Assumes 32.768 kHz external crystal
 *!
 *! Modes: FEI [FLL engaged internal] -> 
 *!        FEE [FLL engaged external]
 *!
 *! Refer 24.5.1 of KL05 Family reference
 */
void clock_initialise(void) {
   // Out of reset MCG is in FEI mode
   // Configure the Crystal Oscillator
   OSC0_CR = OSC_CR_ERCLKEN_MASK; //ToDo Check caps, OSC_CR_SC16P_MASK;
   
   // Clock pins are XTAL/EXTAL
//   PORTA_PCR3 = PORT_PCR_MUX(0);
//   PORTA_PCR4 = PORT_PCR_MUX(0);

   //=======================================================================
   // Switch from FEI (FLL engaged internal) to FEE (FLL external external)
   
   // Make sure reset default
   MCG_C4 &= ~(MCG_C4_DMX32_MASK|MCG_C4_DRST_DRS_MASK);
   MCG_C6  = 0;

   // 1) Set up crystal
   MCG_C2 = MCG_C2_EREFS0_MASK |    // because crystal is being used
            MCG_C2_RANGE0(0);       // 32kHz is in low freq range
 
   // 2) Select clock mode
   MCG_C1 =  MCG_C1_CLKS(0)       |   // CLKS = 0    -> FLL/PLL
             MCG_C1_FRDIV(0)      |   // FRDIV = 0   -> 32.768kHz/1 = 32.768 kHz
             MCG_C1_IRCLKEN_MASK;     // IRCLKEN = 1 -> MCGIRCLK active
   
   // 3) Wait for crystal to start up
   do {
      asm("nop");
   } while ((MCG_S & MCG_S_OSCINIT0_MASK) == 0);

   // Wait for mode change
   do {
      asm("nop");
   } while ((MCG_S & MCG_S_IREFST_MASK) != 0);

   // 4) DCO output (MCGFLLCLK) range

   MCG_C4 |= MCG_C4_DMX32_MASK|MCG_C4_DRST_DRS(1); // FLL Factor 1464 => 32.768*1464 = 48 MHz

   // Wait for MCGOUT indicating that the FLL switch has occurred
   do {
      asm("nop");
   } while ((MCG_S & MCG_S_CLKST_MASK) != MCG_S_CLKST(0));

   // Set up the SIM clock dividers.
#if defined(MCU_MK20D5)
   // core/platform/system clock = PLL/2 (48MHz), bus clock = PLL/2 (48MHz), flash clock = PLL/4 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV2(1) | SIM_CLKDIV1_OUTDIV4(3);
#elif defined(MCU_MKL25Z4)
   // core/platform/system clock = PLL/2 (48MHz), bus clock/flash clock = PLL/2/2 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV4(1);
#elif defined(MCU_MKL05Z4) || defined(MCU_MKL02Z4)
   // core/platform/system clock = PLL (48MHz), bus clock/flash clock = PLL/2/2 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(0) | SIM_CLKDIV1_OUTDIV4(1);
#else
   #error "CPU not set"
#endif

   // Basic clock selection
#if defined(MCU_MK20D5)
   // Peripheral clock choice (incl. USB), USBCLK = MCGCLK
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK | // PLL rather than FLL for peripheral clock
                SIM_SOPT2_USBSRC_MASK;     // MCGPLLCLK/2 Source as USB clock (48MHz req.)
#elif defined(MCU_MKL25Z4)
   SIM_SOPT2 = SIM_SOPT2_UART0SRC(1)     | // MCGPLLCLK/2 as UART0 clock
               SIM_SOPT2_TPMSRC(1)       | // MCGPLLCLK/2 as TPM clock
               SIM_SOPT2_PLLFLLSEL_MASK  | // PLL rather than FLL for peripheral clock 
               SIM_SOPT2_USBSRC_MASK;      // MCGPLLCLK/2 Source as USB clock (48MHz req.)
#elif defined(MCU_MKL05Z4) || defined(MCU_MKL02Z4)
   SIM_SOPT2 = SIM_SOPT2_UART0SRC(1)        | // MCGPLLCLK/2 as UART0 clock
               SIM_SOPT2_TPMSRC(1);           // MCGPLLCLK/2 as TPM clock
#else
   #error "CPU not set"
#endif
}
