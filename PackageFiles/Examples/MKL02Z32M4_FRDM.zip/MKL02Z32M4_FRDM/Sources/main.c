/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include "derivative.h"
#include "leds.h"

void delay(void) {
   volatile unsigned long i;
   for (i=400000; i>0; i--) {
	   asm("nop");
   }
}

void SysTickHandler(void) {
   __asm__("nop");
   __asm__("nop");
   __asm__("nop");
}

volatile int count = 0;

int main(void) {


   SysTick_Config(1000);

   led_initialise();
   for(;;) {
      count++;
      greenLedToggle();
      delay();
      greenLedToggle();
      delay();
      redLedToggle();
      delay();
      redLedToggle();
      delay();
      blueLedToggle();
      delay();
      blueLedToggle();
      delay();
   }
   return 0;
}
