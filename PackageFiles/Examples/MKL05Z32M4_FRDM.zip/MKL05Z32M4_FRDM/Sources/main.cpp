/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include "derivative.h"
#include "leds.h"

void port_initialise() {
   // Enable all port clocks
   SIM_SCGC5 |=  SIM_SCGC5_PORTA_MASK
             |   SIM_SCGC5_PORTB_MASK;

   // Release pin isolation
//   PMC_REGSC |= PMC_REGSC_ACKISO_MASK;
}

void delay(void) {
   volatile unsigned long i;
   for (i=400000; i>0; i--) {
	   asm("nop");
   }
}

volatile int count = 0;

int main(void) {
   port_initialise();
   led_initialise();
   for(;;) {
	   count++;
      greenLedToggle();
      delay();
      greenLedToggle();
      delay();
      redLedToggle();
      delay();
      redLedToggle();
      delay();
      blueLedToggle();
      delay();
      blueLedToggle();
      delay();
   }
   return 0;
}
