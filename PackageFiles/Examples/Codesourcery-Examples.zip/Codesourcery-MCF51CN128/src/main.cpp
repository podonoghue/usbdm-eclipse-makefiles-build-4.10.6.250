typedef unsigned char U8;
#define SOPT1 (*(volatile U8 *) 0xFFFF8101)
#define PTDDD (*(volatile U8 *) 0xFFFF8031)
#define PTDD  (*(volatile U8 *) 0xFFFF8030)

#define GREEN_LED (1<<0)
#define RED_LED   (1<<1)

void delay(void) {
int i;
   for(i=0; i<100000; i++) {
      asm("nop");
   }
}

int main(void) {
   SOPT1  = 0; // Disable COP
   PTDDD |= GREEN_LED|RED_LED;
   PTDD  |= GREEN_LED|RED_LED;
   PTDD  &= ~RED_LED;

   for(;;) {
      PTDD ^= GREEN_LED|RED_LED;
      delay();
   }
}
