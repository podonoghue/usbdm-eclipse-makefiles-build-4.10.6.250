#include <derivative.h>

typedef unsigned char U8;
//#define SOPT1 (*(volatile U8 *) 0xFFFF8101)
//#define PTDDD (*(volatile U8 *) 0xFFFF8031)
//#define PTDD  (*(volatile U8 *) 0xFFFF8030)

#define GREEN_LED (1<<0)
#define RED_LED   (1<<5)

void delay(void) {
int i;
   for(i=0; i<100000; i++) {
      asm("nop");
   }
}

int main(void) {
   SIM_COPC   = 0x00; // Disable COP
   SIM_SCGC6 |= SIM_SCGC6_PORTA_MASK|SIM_SCGC6_PORTC_MASK;
   PTA_DD |= GREEN_LED;
   PTC_DD |= RED_LED;
   PTA_D  |= GREEN_LED;
   PTC_D  &= ~RED_LED;

   for(;;) {
      PTA_D ^= GREEN_LED;
      PTC_D ^= RED_LED;
      delay();
   }
}
