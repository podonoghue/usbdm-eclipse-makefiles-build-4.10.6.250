/*
 * clock.h
 *
 *  Created on: Nov 6, 2012
 *      Author: podonoghue
 */

#ifndef CLOCK_H_
#define CLOCK_H_

#include <stdint.h>

extern uint32_t SystemCoreClock;
void initClock(void);

#endif /* CLOCK_H_ */
