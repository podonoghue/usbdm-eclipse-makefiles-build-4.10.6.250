/*
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 */

#include "derivative.h"


// Used to create port register names
//--------------------------------------------------------
#define CONCAT2_(x,y) x ## y
#define CONCAT3_(x,y,z) x ## y ## z
#define CONCAT4_(w,x,y,z) w ## x ## y ## z

#define PCR(reg,num)   CONCAT4_(PORT,reg,_PCR,num)
#define PDOR(reg)      CONCAT3_(GPIO,reg,_PDOR)
#define PSOR(reg)      CONCAT3_(GPIO,reg,_PSOR)
#define PCOR(reg)      CONCAT3_(GPIO,reg,_PCOR)
#define PTOR(reg)      CONCAT3_(GPIO,reg,_PTOR)
#define PDIR(reg)      CONCAT3_(GPIO,reg,_PDIR)
#define PDDR(reg)      CONCAT3_(GPIO,reg,_PDDR)

//=================================================================================
// LED Port bit masks
//
#define LED_0_NUM           0
#define LED_0_REG           E
#define LED_0_MASK          (1<<LED_0_NUM)
#define LED_0_PCR           PCR(LED_0_REG,LED_0_NUM)
#define LED_0_PDOR          PDOR(LED_0_REG)
#define LED_0_PSOR          PSOR(LED_0_REG)  // Data set
#define LED_0_PCOR          PCOR(LED_0_REG)  // Data clear
#define LED_0_PTOR          PTOR(LED_0_REG)  // Data toggle
#define LED_0_PDIR          PDIR(LED_0_REG)  // Data input
#define LED_0_PDDR          PDDR(LED_0_REG)  // Data direction

#define LED_0_ON()          (LED_0_PCOR = LED_0_MASK)
#define LED_0_OFF()         (LED_0_PSOR = LED_0_MASK)
#define LED_0_TOGGLE()      (LED_0_PTOR = LED_0_MASK)

#define LED_1_NUM           1
#define LED_1_REG           E
#define LED_1_MASK          (1<<LED_1_NUM)
#define LED_1_PCR           PCR(LED_1_REG,LED_1_NUM)
#define LED_1_PDOR          PDOR(LED_1_REG)
#define LED_1_PSOR          PSOR(LED_1_REG)  // Data set
#define LED_1_PCOR          PCOR(LED_1_REG)  // Data clear
#define LED_1_PTOR          PTOR(LED_1_REG)  // Data toggle
#define LED_1_PDIR          PDIR(LED_1_REG)  // Data input
#define LED_1_PDDR          PDDR(LED_1_REG)  // Data direction

#define LED_1_ON()          (LED_1_PCOR = LED_1_MASK)
#define LED_1_OFF()         (LED_1_PSOR = LED_1_MASK)
#define LED_1_TOGGLE()      (LED_1_PTOR = LED_1_MASK)

void initLEDs(void) {
   LED_0_OFF();
   LED_1_OFF();
   LED_0_PDDR |= LED_0_MASK;
   LED_0_PCR   = PORT_PCR_MUX(1)|PORT_PCR_DSE_MASK|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
   LED_1_PDDR |= LED_1_MASK;
   LED_1_PCR   = PORT_PCR_MUX(1)|PORT_PCR_DSE_MASK|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
}

void initPorts() {
   // Enable all port clocks
   SIM_SCGC5 |=   SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;

}

void delay(void) {
   volatile unsigned long i;
   for (i=200000; i>0; i--) {
   }
}

int count = 0;

int main(void) {
   initPorts();
   initLEDs();
   LED_0_ON();
   for(;;) {
      LED_0_TOGGLE();
      delay();
      LED_1_TOGGLE();
      delay();
   }
}


