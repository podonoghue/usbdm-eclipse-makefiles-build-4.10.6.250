/*
 *  Vectors for MK20DX128M5
 */
#include <stdint.h>

typedef void( *const intfunc )( void );

#define WEAK_DEFAULT_HANDLER __attribute__ ((weak, alias("Default_Handler")))

 __attribute__((__interrupt__))
void Default_Handler(void) {
   while (1) {
      asm("bkpt #0");
   }
}

void __cs3_reset(void) __attribute__((__interrupt__));
extern uint32_t __cs3_stack;

void NMI_Handler(void)              WEAK_DEFAULT_HANDLER;
void HardFault_Handler(void)        WEAK_DEFAULT_HANDLER;
void MemManage_Handler(void)        WEAK_DEFAULT_HANDLER;
void BusFault_Handler(void)         WEAK_DEFAULT_HANDLER;
void UsageFault_Handler(void)       WEAK_DEFAULT_HANDLER;
void SVC_Handler(void)              WEAK_DEFAULT_HANDLER;
void DebugMon_Handler(void)         WEAK_DEFAULT_HANDLER;
void PendSV_Handler(void)           WEAK_DEFAULT_HANDLER;
void SysTick_Handler(void)          WEAK_DEFAULT_HANDLER;

void DMA0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void DMA1_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void DMA2_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void DMA3_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void DMA_Error_IRQHandler(void)     WEAK_DEFAULT_HANDLER;
void FTFL_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void LVD_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void LLW_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void WDOG_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void I2C0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void SPI0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void I2S0Tx_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void I2S0Rx_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void UART0_LON_IRQHandler(void)     WEAK_DEFAULT_HANDLER;
void UART0_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void UART0_Error_IRQHandler(void)   WEAK_DEFAULT_HANDLER;
void UART1_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void UART1_Error_IRQHandler(void)   WEAK_DEFAULT_HANDLER;
void UART2_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void UART2_Error_IRQHandler(void)   WEAK_DEFAULT_HANDLER;
void ADC0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void CMP0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void CMP1_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void FTM0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void FTM1_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void CMT_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void RTC_Alarm_IRQHandler(void)     WEAK_DEFAULT_HANDLER;
void RTC_Seconds_IRQHandler(void)   WEAK_DEFAULT_HANDLER;
void PIT_Channel0_IRQHandler(void)  WEAK_DEFAULT_HANDLER;
void PIT_Channel1_IRQHandler(void)  WEAK_DEFAULT_HANDLER;
void PIT_Channel2_IRQHandler(void)  WEAK_DEFAULT_HANDLER;
void PIT_Channel3_IRQHandler(void)  WEAK_DEFAULT_HANDLER;
void PDB0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void USB0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void USBDCD_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void TSI0_IRQHandler(void)          WEAK_DEFAULT_HANDLER;
void MCG_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void LPTimer_IRQHandler(void)       WEAK_DEFAULT_HANDLER;
void PORTA_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void PORTB_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void PORTC_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void PORTD_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void PORTE_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void SWI_IRQHandler(void)           WEAK_DEFAULT_HANDLER;

__attribute__ ((section(".cs3.interrupt_vector")))
intfunc const __cs3_interrupt_vector_arm[] = {
    (intfunc)(&__cs3_stack),  /* The stack pointer after relocation           */
    __cs3_reset,              /* Reset Handler                                */
    NMI_Handler,              /* NMI Handler                                  */
    HardFault_Handler,        /* Hard Fault Handler                           */
    MemManage_Handler,        /* MPU Fault Handler                            */
    BusFault_Handler,         /* Bus Fault Handler                            */
    UsageFault_Handler,       /* Usage Fault Handler                          */
    0,                        /* Reserved                                     */
    0,                        /* Reserved                                     */
    0,                        /* Reserved                                     */
    0,                        /* Reserved                                     */
    SVC_Handler,              /* SVCall Handler                               */
    DebugMon_Handler,         /* Debug Monitor Handler                        */
    0,                        /* Reserved                                     */
    PendSV_Handler,           /* PendSV Handler                               */
    SysTick_Handler,          /* SysTick Handler                              */

                              /* External Interrupts                          */
    DMA0_IRQHandler,          /* DMA Channel 0 Transfer Complete and Error    */
    DMA1_IRQHandler,          /* DMA Channel 1 Transfer Complete and Error    */
    DMA2_IRQHandler,          /* DMA Channel 2 Transfer Complete and Error    */
    DMA3_IRQHandler,          /* DMA Channel 3 Transfer Complete and Error    */
    DMA_Error_IRQHandler,     /* DMA error interrupt                          */
    Default_Handler,          /* Reserved interrupt 21                        */
    FTFL_IRQHandler,          /* FTFL Interrupt                               */
    Default_Handler,          /* Read collision interrupt                     */
    LVD_IRQHandler,           /* Low Voltage Detect, Low Voltage Warning      */
    LLW_IRQHandler,           /* Low Leakage Wakeup                           */
    WDOG_IRQHandler,          /* WDOG interrupt                               */
    I2C0_IRQHandler,          /* I2C0 interrupt                               */
    SPI0_IRQHandler,          /* SPI0 Interrupt                               */
    I2S0Tx_IRQHandler,        /* I2S0 transmit interrupt                      */
    I2S0Rx_IRQHandler,        /* I2S0 receive interrupt                       */
    UART0_LON_IRQHandler,     /* UART0 LON interrupt                          */
    UART0_IRQHandler,         /* UART0 Status and Error interrupt             */
    UART0_Error_IRQHandler,   /* UART0 error interrupt                        */
    UART1_IRQHandler,         /* UART1 Status and Error interrupt             */
    UART1_Error_IRQHandler,   /* UART1 error interrupt                        */
    UART2_IRQHandler,         /* UART2 Status and Error interrupt             */
    UART2_Error_IRQHandler,   /* UART2 error interrupt                        */
    ADC0_IRQHandler,          /* ADC0 interrupt                               */
    CMP0_IRQHandler,          /* CMP0 interrupt                               */
    CMP1_IRQHandler,          /* CMP1 interrupt                               */
    FTM0_IRQHandler,          /* FTM0 fault, overflow and channels interrupt  */
    FTM1_IRQHandler,          /* FTM1 fault, overflow and channels interrupt  */
    CMT_IRQHandler,           /* CMT interrupt                                */
    RTC_Alarm_IRQHandler,     /* RTC Alarm interrupt                          */
    RTC_Seconds_IRQHandler,   /* RTC Seconds interrupt                        */
    PIT_Channel0_IRQHandler,  /* PIT timer channel 0 interrupt                */
    PIT_Channel1_IRQHandler,  /* PIT timer channel 1 interrupt                */
    PIT_Channel2_IRQHandler,  /* PIT timer channel 2 interrupt                */
    PIT_Channel3_IRQHandler,  /* PIT timer channel 3 interrupt                */
    PDB0_IRQHandler,          /* PDB0 interrupt                               */
    USB0_IRQHandler,          /* USB0 interrupt                               */
    USBDCD_IRQHandler,        /* USBDCD interrupt                             */
    TSI0_IRQHandler,          /* TSI0 interrupt                               */
    MCG_IRQHandler,           /* MCG interrupt                                */
    LPTimer_IRQHandler,       /* LPTimer interrupt                            */
    PORTA_IRQHandler,         /* Port A interrupt                             */
    PORTB_IRQHandler,         /* Port B interrupt                             */
    PORTC_IRQHandler,         /* Port C interrupt                             */
    PORTD_IRQHandler,         /* Port D interrupt                             */
    PORTE_IRQHandler,         /* Port E interrupt                             */
    SWI_IRQHandler,           /* Software interrupt                           */
};
