/*
 * clock.h
 *
 *  Created on: Nov 6, 2012
 *      Author: podonoghue
 */

#ifndef CLOCK_H_
#define CLOCK_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

static const uint32_t SystemCoreClock = 48000000UL; // Hz
static const uint32_t SystemBusClock  = 24000000UL; // Hz

// These values depend on the clock configuration
#define SYSTEM_CORE_CLOCK      (48000000UL) // Hz
#define SYSTEM_BUS_CLOCK       (24000000UL) // Hz
#define SYSTEM_FAST_IRC_CLOCK   (4000000UL) // Hz (nominal)
#define SYSTEM_SLOW_IRC_CLOCK     (32768UL) // Hz (nominal)
#define SYSTEM_MCGIRCLK_CLOCK  (SYSTEM_SLOW_IRC_CLOCK) // Hz

void clock_initialise(void);

#ifdef __cplusplus
}
#endif
#endif /* CLOCK_H_ */
