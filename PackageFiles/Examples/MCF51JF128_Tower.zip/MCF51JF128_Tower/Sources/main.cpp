#include <derivative.h>
#include <leds.h>

typedef unsigned char U8;

#define GREEN_LED (1<<5)
#define RED_LED   (1<<0)

void delay(void) {
int i;
   for(i=0; i<100000; i++) {
      asm("nop");
   }
}

void port_initialise(void) {
   SIM_SCGC6 |=
         SIM_SCGC6_PORTA_MASK|
         SIM_SCGC6_PORTB_MASK|
         SIM_SCGC6_PORTC_MASK|
         SIM_SCGC6_PORTD_MASK|
         SIM_SCGC6_PORTE_MASK|
         SIM_SCGC6_PORTF_MASK;
}

int main(void) {
   port_initialise();
   led_initialise();

   for(;;) {
      greenLedOn();
      delay();
      greenLedOff();
      delay();
      orangeLedOn();
      delay();
      orangeLedOff();
      delay();
   }
}
