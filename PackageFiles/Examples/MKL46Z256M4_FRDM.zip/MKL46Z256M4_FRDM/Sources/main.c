/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "clock.h"

#define PIT_CLOCK_FREQUENCY         SystemBusClock
#define PIT_TICKS_PER_MICROSECOND   (PIT_CLOCK_FREQUENCY/1000000)
#define PIT_TICKS_PER_MILLISECOND   (PIT_CLOCK_FREQUENCY/1000)

//=========================================================================
// Timer routines
//
//=========================================================================

/*! Initialises a PIT channel
 *
 * @param channel  - channel (0-3) to configure
 * @param interval - PIT interval (re-load value+1)
 *
 * Configures:
 *   - Enables PIT clock
 *   - Sets PIT re-load value
 *   - Enables PIT
 *   - Enables interrupts
 */
void initialisePIT(int channel, uint32_t interval) {

   // Enable clock to PIT
   SIM_SCGC6  |= SIM_SCGC6_PIT_MASK;
   // Enable PIT module
   PIT_MCR     = 0;//PIT_MCR_FRZ_MASK;
   // Set re-load value
   PIT->CS[channel].LDVAL = interval-1;
   // Enable this channel with interrupts
   PIT->CS[channel].TCTRL = PIT_TCTRL_TEN_MASK|PIT_TCTRL_TIE_MASK;
   // Enable PIT interrupts in NVIC (all channels share ISR)
   NVIC_EnableIRQ(PIT_IRQn);
   // Set arbitrary priority level
   NVIC_SetPriority(PIT_IRQn, 2);
}

/*!
 *  PIT Handler
 *  Toggles a pin
 */
void PIT_IRQHandler(void) {
   if ((PIT_TCTRL0&PIT_TFLG_TIF_MASK) != 0) {
      // clear the interrupt request from PIT
      PIT_TFLG0 = PIT_TFLG_TIF_MASK;
      // Flash the LED
      greenLedToggle();
      redLedToggle();
   }
   else  {
      // Should never happen
      __breakpoint();
   }
}

int main(void) {
   // Release pin isolation
   //PMC_REGSC |= PMC_REGSC_ACKISO_MASK;

   __enable_irq();
   led_initialise();
   greenLedOn();
   redLedOff();
   initialisePIT(0, 100*PIT_TICKS_PER_MILLISECOND);
   for(;;) {
      __wait_for_interrupt();
   }
}
