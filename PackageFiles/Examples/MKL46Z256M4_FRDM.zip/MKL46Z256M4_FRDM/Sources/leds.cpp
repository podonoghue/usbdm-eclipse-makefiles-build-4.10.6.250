#include "derivative.h"
#include "Freedom.h"

#define LED_GREEN_MASK        (1<<LED_GREEN_NUM)
#define LED_GREEN_PCR         PCR(LED_GREEN_PORT,LED_GREEN_NUM)
#define LED_GREEN_PDOR        PDOR(LED_GREEN_PORT)
#define LED_GREEN_PSOR        PSOR(LED_GREEN_PORT)  // Data set
#define LED_GREEN_PCOR        PCOR(LED_GREEN_PORT)  // Data clear
#define LED_GREEN_PTOR        PTOR(LED_GREEN_PORT)  // Data toggle
#define LED_GREEN_PDIR        PDIR(LED_GREEN_PORT)  // Data input
#define LED_GREEN_PDDR        PDDR(LED_GREEN_PORT)  // Data direction

#define LED_RED_MASK          (1<<LED_RED_NUM)
#define LED_RED_PCR           PCR(LED_RED_PORT,LED_RED_NUM)
#define LED_RED_PDOR          PDOR(LED_RED_PORT)
#define LED_RED_PSOR          PSOR(LED_RED_PORT)  // Data set
#define LED_RED_PCOR          PCOR(LED_RED_PORT)  // Data clear
#define LED_RED_PTOR          PTOR(LED_RED_PORT)  // Data toggle
#define LED_RED_PDIR          PDIR(LED_RED_PORT)  // Data input
#define LED_RED_PDDR          PDDR(LED_RED_PORT)  // Data direction

void greenLedOn(void) {
   LED_GREEN_PCOR = LED_GREEN_MASK;
}
void greenLedOff(void) {
   LED_GREEN_PSOR = LED_GREEN_MASK;
}
void greenLedToggle(void) {
   LED_GREEN_PTOR = LED_GREEN_MASK;
}
void redLedOn(void) {
   LED_RED_PCOR = LED_RED_MASK;
}
void redLedOff(void) {
   LED_RED_PSOR = LED_RED_MASK;
}
void redLedToggle(void) {
   LED_RED_PTOR = LED_RED_MASK;
}
void led_initialise(void) {
   greenLedOff();
   redLedOff();
   LED_GREEN_PDDR  |= LED_GREEN_MASK;
   LED_GREEN_PCR    = PORT_PCR_MUX(1)|PORT_PCR_DSE_MASK|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
   LED_RED_PDDR    |= LED_RED_MASK;
   LED_RED_PCR      = PORT_PCR_MUX(1)|PORT_PCR_DSE_MASK|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
}
