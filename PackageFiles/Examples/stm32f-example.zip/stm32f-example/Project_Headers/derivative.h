/*
 *  Include the derivative-specific header file
 */

/* Include STM Standard Peripheral Library (SPL) */

#define STM32F10X_MD /*!< STM32F10X_MD_VL: STM32 Medium density devices */
#include "stm32f10x_conf.h"
