/*
 * MMA845x.h
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */

#ifndef MMA845X_H_
#define MMA845X_H_

#include <stdint.h>
#include "I2C.h"

class MMA845x {

#define MMA45x_XYZ_DATA_CFG_FS(x)          (((x)<<0)&0x03)
#define MMA45x_XYZ_DATA_CFG_HPF_OUT_MASK   (1<<4)

private:
   I2C *i2c;
   static const uint8_t deviceAddress = 0x1D<<1;

   uint8_t readReg(uint8_t regNum);
   void    writeReg(uint8_t regNum, uint8_t value);
   void    reset(void);

public:

   enum Mode {
      MMA45x_2Gmode      = MMA45x_XYZ_DATA_CFG_FS(0),                                  // 2g Full-scale, no high-pass filter
      MMA45x_4Gmode      = MMA45x_XYZ_DATA_CFG_FS(1),                                  // 4g Full-scale, no high-pass filter
      MMA45x_8Gmode      = MMA45x_XYZ_DATA_CFG_FS(2),                                  // 8g Full-scale, no high-pass filter
      MMA45x_2G_HPF_mode = MMA45x_XYZ_DATA_CFG_FS(0)|MMA45x_XYZ_DATA_CFG_HPF_OUT_MASK, // 2g Full-scale, high-pass filter
      MMA45x_4G_HPF_mode = MMA45x_XYZ_DATA_CFG_FS(1)|MMA45x_XYZ_DATA_CFG_HPF_OUT_MASK, // 4g Full-scale, high-pass filter
      MMA45x_8G_HPF_mode = MMA45x_XYZ_DATA_CFG_FS(2)|MMA45x_XYZ_DATA_CFG_HPF_OUT_MASK, // 8g Full-scale, high-pass filter
   } ;

   MMA845x(I2C *i2c, Mode mode);
   void standby();
   void active();
   void readXYX(int *status, int16_t *x, int16_t *y, int16_t *z);
   void setMode(Mode mode);
};

#endif /* MMA845X_H_ */
