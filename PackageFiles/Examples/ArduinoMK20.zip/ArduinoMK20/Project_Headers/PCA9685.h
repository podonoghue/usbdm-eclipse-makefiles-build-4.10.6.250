/*
 * pca9685.h
 *
 *  Created on: 24/06/2014
 *      Author: podonoghue
 */

#ifndef H_
#define H_

#include <stdint.h>
#include <stddef.h>
#include "i2c.h"

// Default address of first (only) motor board
#define PCA9685_DEFAULT_SLAVE_BASE_ADDRESS   ((uint8_t)(0x60<<1)) // PCA9685 Slave address

// Mode register 1, MODE1
#define PCA9685_MODE1_RESTART_MASK    (1<<7) // 0*/1 => Shows state of RESTART logic.
#define PCA9685_MODE1_EXTCLK_MASK     (1<<6) // 0*/1 => Use internal/EXTCLK pin clock.
#define PCA9685_MODE1_AI_MASK         (1<<5) // 0*/1 => Register Auto-Increment enable/disabled.
#define PCA9685_MODE1_SLEEP_MASK      (1<<4) // 0/1* => Low power mode on/off (Oscillator on/off)
#define PCA9685_MODE1_SUB1_MASK       (1<<3) // 0/1* => PCA9685 responds to I2C-bus sub-address 1.
#define PCA9685_MODE1_SUB2_MASK       (1<<2) // 0/1* => PCA9685 responds to I2C-bus sub-address 1.
#define PCA9685_MODE1_SUB3_MASK       (1<<1) // 0/1* => PCA9685 responds to I2C-bus sub-address 1.
#define PCA9685_MODE1_ALLCALL_MASK    (1<<0) // 0/1* => Does not/does respond to LED All Call I2C-bus address.

// Mode register 2, MODE2
#define PCA9685_MODE2_INVRT_MASK      (1<<4) // 0*   => Output logic state not inverted. Value to use when external driver used.
//                                           //         Applicable when OE = 0.
//                                           // 1    => Output logic state inverted. Value to use when no external driver used.
//                                           //         Applicable when OE = 0.
#define PCA9685_MODE2_OCH_MASK        (1<<3) // 0*   => Outputs change on STOP command.
//                                           // 1    => Outputs change on ACK.
#define PCA9685_MODE2_OUTDRV_MASK     (1<<2) // 0    => The 16 LEDn outputs are configured with an open-drain structure.
//                                           // 1*   => The 16 LEDn outputs are configured with a totem pole structure.
#define PCA9685_MODE2_OUTNE_MASK      (3<<0) // 00*  => When OE = 1 (output drivers not enabled), LEDn = 0.
//                                           // 01   => When OE = 1 (output drivers not enabled):
//                                           //         LEDn = 1 when OUTDRV = 1
//                                           //         LEDn = high-impedance when OUTDRV = 0 (same as OUTNE[1:0] = 10)
//                                           // 1X   => When OE = 1 (output drivers not enabled), LEDn = high-impedance.

// LEDx_ON_L
//             7:0 LEDx_ON count for LEDx, 8 LSBs
#define PCA9685_LEDx_ON_L_COUNT_MASK  (0xFF<<0)
// LEDx_ON_H
#define PCA9685_LEDx_ON_H_FULL_MASK   (1<<4)
#define PCA9685_LEDx_ON_H_COUNT_MASK  (0xF<<0)
//               4 LEDx full ON
//             3:0 LEDx_ON count for LEDx, 4 MSBs
// LEDx_OFF_L
#define PCA9685_LEDx_OFF_L_COUNT_MASK  (0xFF<<0)
//             7:0 LEDx_OFF count for LEDx, 8 LSBs
// LEDx_OFF_H
#define PCA9685_LEDx_OFF_H_FULL_MASK   (1<<4)
#define PCA9685_LEDx_OFF_H_COUNT_MASK  (0xF<<0)
//               4 LEDx full OFF
//             3:0 LEDx_OFF count for LEDx, 4 MSBs

// Default PWM oscillator parameters
#define PCA9685_OSC_CLOCK_FREQ (25000000UL)
#define PCA9685_PWM_FREQ       (200UL)
#define PCA9685_DEFAULT_OSC_PRESCALE   (((PCA9685_OSC_CLOCK_FREQ+2048UL*PCA9685_PWM_FREQ)/(4096UL*PCA9685_PWM_FREQ))-1)
#if ((PCA9685_OSC_PRESCALE & ~0xFFU) != 0)
#error "OSC_PRESCALE is too large"
#endif

class PCA9685 {

protected:
   I2C     *i2c;
   uint8_t  slaveAddress;

public:
   enum {
      MODE1         =   (0x00),   // READ/WRITE Mode register 1
      MODE2         =   (0x01),   // READ/WRITE Mode register 2
      SUBADR1       =   (0x02),   // READ/WRITE I2C-bus sub-address 1
      SUBADR2       =   (0x03),   // READ/WRITE I2C-bus sub-address 2
      SUBADR3       =   (0x04),   // READ/WRITE I2C-bus sub-address 3
      ALLCALLADR    =   (0x05),   // READ/WRITE LED All Call I2C-bus address
      PIN0_ON_L     =   (0x06),   // READ/WRITE LED0  output and brightness control byte 0
      PIN0_ON_H     =   (0x07),   // READ/WRITE LED0  output and brightness control byte 1
      PIN0_OFF_L    =   (0x08),   // READ/WRITE LED0  output and brightness control byte 2
      PIN0_OFF_H    =   (0x09),   // READ/WRITE LED0  output and brightness control byte 3
      PIN1_ON_L     =   (0x0A),   // READ/WRITE LED1  output and brightness control byte 0
      PIN1_ON_H     =   (0x0B),   // READ/WRITE LED1  output and brightness control byte 1
      PIN1_OFF_L    =   (0x0C),   // READ/WRITE LED1  output and brightness control byte 2
      PIN1_OFF_H    =   (0x0D),   // READ/WRITE LED1  output and brightness control byte 3
      PIN2_ON_L     =   (0x0E),   // READ/WRITE LED2  output and brightness control byte 0
      PIN2_ON_H     =   (0x0F),   // READ/WRITE LED2  output and brightness control byte 1
      PIN2_OFF_L    =   (0x10),   // READ/WRITE LED2  output and brightness control byte 2
      PIN2_OFF_H    =   (0x11),   // READ/WRITE LED2  output and brightness control byte 3
      PIN3_ON_L     =   (0x12),   // READ/WRITE LED3  output and brightness control byte 0
      PIN3_ON_H     =   (0x13),   // READ/WRITE LED3  output and brightness control byte 1
      PIN3_OFF_L    =   (0x14),   // READ/WRITE LED3  output and brightness control byte 2
      PIN3_OFF_H    =   (0x15),   // READ/WRITE LED3  output and brightness control byte 3
      PIN4_ON_L     =   (0x16),   // READ/WRITE LED4  output and brightness control byte 0
      PIN4_ON_H     =   (0x17),   // READ/WRITE LED4  output and brightness control byte 1
      PIN4_OFF_L    =   (0x18),   // READ/WRITE LED4  output and brightness control byte 2
      PIN4_OFF_H    =   (0x19),   // READ/WRITE LED4  output and brightness control byte 3
      PIN5_ON_L     =   (0x1A),   // READ/WRITE LED5  output and brightness control byte 0
      PIN5_ON_H     =   (0x1B),   // READ/WRITE LED5  output and brightness control byte 1
      PIN5_OFF_L    =   (0x1C),   // READ/WRITE LED5  output and brightness control byte 2
      PIN5_OFF_H    =   (0x1D),   // READ/WRITE LED5  output and brightness control byte 3
      PIN6_ON_L     =   (0x1E),   // READ/WRITE LED6  output and brightness control byte 0
      PIN6_ON_H     =   (0x1F),   // READ/WRITE LED6  output and brightness control byte 1
      PIN6_OFF_L    =   (0x20),   // READ/WRITE LED6  output and brightness control byte 2
      PIN6_OFF_H    =   (0x21),   // READ/WRITE LED6  output and brightness control byte 3
      PIN7_ON_L     =   (0x22),   // READ/WRITE LED7  output and brightness control byte 0
      PIN7_ON_H     =   (0x23),   // READ/WRITE LED7  output and brightness control byte 1
      PIN7_OFF_L    =   (0x24),   // READ/WRITE LED7  output and brightness control byte 2
      PIN7_OFF_H    =   (0x25),   // READ/WRITE LED7  output and brightness control byte 3
      PIN8_ON_L     =   (0x26),   // READ/WRITE LED8  output and brightness control byte 0
      PIN8_ON_H     =   (0x27),   // READ/WRITE LED8  output and brightness control byte 1
      PIN8_OFF_L    =   (0x28),   // READ/WRITE LED8  output and brightness control byte 2
      PIN8_OFF_H    =   (0x29),   // READ/WRITE LED8  output and brightness control byte 3
      PIN9_ON_L     =   (0x2A),   // READ/WRITE LED9  output and brightness control byte 0
      PIN9_ON_H     =   (0x2B),   // READ/WRITE LED9  output and brightness control byte 1
      PIN9_OFF_L    =   (0x2C),   // READ/WRITE LED9  output and brightness control byte 2
      PIN9_OFF_H    =   (0x2D),   // READ/WRITE LED9  output and brightness control byte 3
      PIN10_ON_L    =   (0x2E),   // READ/WRITE LED10 output and brightness control byte 0
      PIN10_ON_H    =   (0x2F),   // READ/WRITE LED10 output and brightness control byte 1
      PIN10_OFF_L   =   (0x30),   // READ/WRITE LED10 output and brightness control byte 2
      PIN10_OFF_H   =   (0x31),   // READ/WRITE LED10 output and brightness control byte 3
      PIN11_ON_L    =   (0x32),   // READ/WRITE LED11 output and brightness control byte 0
      PIN11_ON_H    =   (0x33),   // READ/WRITE LED11 output and brightness control byte 1
      PIN11_OFF_L   =   (0x34),   // READ/WRITE LED11 output and brightness control byte 2
      PIN11_OFF_H   =   (0x35),   // READ/WRITE LED11 output and brightness control byte 3
      PIN12_ON_L    =   (0x36),   // READ/WRITE LED12 output and brightness control byte 0
      PIN12_ON_H    =   (0x37),   // READ/WRITE LED12 output and brightness control byte 1
      PIN12_OFF_L   =   (0x38),   // READ/WRITE LED12 output and brightness control byte 2
      PIN12_OFF_H   =   (0x39),   // READ/WRITE LED12 output and brightness control byte 3
      PIN13_ON_L    =   (0x3A),   // READ/WRITE LED13 output and brightness control byte 0
      PIN13_ON_H    =   (0x3B),   // READ/WRITE LED13 output and brightness control byte 1
      PIN13_OFF_L   =   (0x3C),   // READ/WRITE LED13 output and brightness control byte 2
      PIN13_OFF_H   =   (0x3D),   // READ/WRITE LED13 output and brightness control byte 3
      PIN14_ON_L    =   (0x3E),   // READ/WRITE LED14 output and brightness control byte 0
      PIN14_ON_H    =   (0x3F),   // READ/WRITE LED14 output and brightness control byte 1
      PIN14_OFF_L   =   (0x40),   // READ/WRITE LED14 output and brightness control byte 2
      PIN14_OFF_H   =   (0x41),   // READ/WRITE LED14 output and brightness control byte 3
      PIN15_ON_L    =   (0x42),   // READ/WRITE LED15 output and brightness control byte 0
      PIN15_ON_H    =   (0x43),   // READ/WRITE LED15 output and brightness control byte 1
      PIN15_OFF_L   =   (0x44),   // READ/WRITE LED15 output and brightness control byte 2
      PIN15_OFF_H   =   (0x45),   // READ/WRITE LED15 output and brightness control byte 3
   //...
      ALL_LED_ON_L  =   (0xFA),   // READ 0/WRITE load all the LEDn_ON registers, byte 0
      ALL_LED_ON_H  =   (0xFB),   // READ 0/WRITE load all the LEDn_ON registers, byte 1
      ALL_LED_OFF_L =   (0xFC),   // READ 0/WRITE load all the LEDn_ON registers, byte 2
      ALL_LED_OFF_H =   (0xFD),   // READ 0/WRITE load all the LEDn_ON registers, byte 3

      PRE_SCALE     =   (0xFE),   // READ/WRITE pre-scaler for output frequency
      TestMode      =   (0xFF),   // READ/WRITE defines the test mode to be entered
   };

   /*!
    * Constructor with default values
    *
    * @param i2c           - The I2C interface to use
    * @param deviceAddress - Slave device address (PCA9685_DEFAULT_SLAVE_BASE_ADDRESS+0,1,2,3)
    * @param prescaleValue - Clock pre-scaler
    * @param mode1Value    - Mode 1 value (use PCA9685_MODE1_x macros)
    * @param mode2Value    - Mode 2 value (use PCA9685_MODE2_x macros)
    */
   PCA9685(I2C     *i2c,
           uint8_t  deviceAddress = PCA9685_DEFAULT_SLAVE_BASE_ADDRESS,
           uint8_t  prescaleValue = PCA9685_DEFAULT_OSC_PRESCALE,
           uint8_t  mode1Value    = PCA9685_MODE1_AI_MASK,
           uint8_t  mode2Value    = PCA9685_MODE2_OUTDRV_MASK
           );

   static const int MAX_PWM = 4095;  // Maximum duty cycle value MAX_PWM = 100%

   void allLow(void);
   void allHigh(void);
   void set_pin_pwm(unsigned pinNum, unsigned dutyCycle);
   void set_pin_high(unsigned pinNum);
   void set_pin_low(unsigned pinNum);
};

#endif /* H_ */
