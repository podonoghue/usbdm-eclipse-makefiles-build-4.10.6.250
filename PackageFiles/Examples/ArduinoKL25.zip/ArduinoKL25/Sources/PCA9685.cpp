/*
 ============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : Basic C Main
 ============================================================================
 */
#include "derivative.h"
#include "utilities.h"
#include "i2c.h"
#include "PCA9685.h"

#define I2C_SWRST_ADDRESS        (0x00<<1) // General I2C Software reset address

//============== PCA9685 register addresses
#define RESET            (0x06)   // Used in conjunction with I2C_SWRST_ADDR

/*!
 * Constructor with default values
 *
 * @param deviceAddress    Device I2C address
 * @param prescaleValue    Prescale value for the internal clock
 * @param mode1Value       Mode register 1 value
 * @param mode2Value       Mode Register 2 value
 *
 */
PCA9685::PCA9685(I2C *i2c, uint8_t slaveAddress, uint8_t prescaleValue, uint8_t mode1Value, uint8_t mode2Value) {
   this->slaveAddress = slaveAddress;

   if (!i2c) {
      i2c = new I2C_0(0x00);
   }
   this->i2c = i2c;

//   uint8_t resetdata[] = {RESET};
//   i2c_transmit(I2C_SWRST_ADDRESS, resetdata, sizeof(resetdata));
   //
   uint8_t mode1data[] = {MODE1,
                          mode1Value,         // mode1
                          mode2Value,         // mode2
                          0,                  // subaddr1
                          0,                  // subaddr2
                          0,                  // subaddr3
                          0xE0                // all call address
   };
   i2c->transmit(slaveAddress, mode1data, sizeof(mode1data));
   //
   uint8_t prescaleData[] = {
      PRE_SCALE,
      prescaleValue   // Prescale value for clock
   };
   i2c->transmit(slaveAddress, prescaleData, sizeof(prescaleData));
   // All outputs off
   allHigh();
}

/*!
 * Set all outputs high
 */
void PCA9685::allHigh(void) {
   uint8_t mode1data[] = {ALL_LED_OFF_H, PCA9685_LEDx_OFF_H_FULL_MASK};
   i2c->transmit(slaveAddress, mode1data, sizeof(mode1data));
}

/*!
 * Set all outputs low
 */
void PCA9685::allLow(void) {
   uint8_t mode1data[] = {ALL_LED_ON_H, PCA9685_LEDx_ON_H_FULL_MASK};
   i2c->transmit(slaveAddress, mode1data, sizeof(mode1data));
}

/*!
 * Sets the dutyCycle of the given pin
 *
 * @param pinNum     Pin to modify
 * @param dutyCycle  Duty-cycle to set (0-4095)
 *
 */
void PCA9685::set_pin_pwm(unsigned pinNum, unsigned dutyCycle) {
   if (dutyCycle>MAX_PWM) {
      dutyCycle = MAX_PWM;
   }
   uint16_t onCount  = 0;
   uint16_t offCount = dutyCycle;
   uint8_t data[] = {
      (uint8_t)(PIN0_ON_L+4*pinNum),
      (uint8_t)onCount,
      (uint8_t)((onCount>>8)&PCA9685_LEDx_ON_H_COUNT_MASK),
      (uint8_t)offCount,
      (uint8_t)((offCount>>8)&PCA9685_LEDx_OFF_H_COUNT_MASK),
   };
   i2c->transmit(slaveAddress, data, sizeof(data));
}

/*!
 * Set given pin low
 *
 * @param pinNum Pin to change
 */
void PCA9685::set_pin_low(unsigned pinNum) {
   uint8_t data[] = {(uint8_t)(PIN0_ON_L+4*pinNum), 0, PCA9685_LEDx_ON_H_FULL_MASK, 0, 0, };
   i2c->transmit(slaveAddress, data, sizeof(data));
}

/*!
 * Set given pin high
 *
 * @param pinNum Pin to change
 */
void PCA9685::set_pin_high(unsigned pinNum) {
   uint8_t data[] = {(uint8_t)(PIN0_ON_L+4*pinNum), 0, 0, 0, PCA9685_LEDx_OFF_H_FULL_MASK, };
   i2c->transmit(slaveAddress, data, sizeof(data));
}
