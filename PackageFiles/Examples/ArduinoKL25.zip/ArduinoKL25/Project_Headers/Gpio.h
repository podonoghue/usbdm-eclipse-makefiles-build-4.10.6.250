/*
 * Gpio.h
 *
 *  Created on: 09/07/2014
 *      Author: podonoghue
 */

#ifndef GPIO_H_
#define GPIO_H_

#include <stdint.h>
#include "derivative.h"

namespace Arduino {

/*
 * Class representing a pin with Digital I/O capability
 */
class DigitalIO {
public:
   struct DigitalIOData {
      uint32_t             clockMask;
      volatile uint32_t   *pcr;
      uint32_t             pcrValue;
      volatile GPIOA_Type *gpio;
      uint32_t             bitMask;
   };

   enum {
      LOW = false,
      HIGH = true,
   };
protected:
   const    DigitalIOData* const data;
   volatile GPIOA_Type*    const gpio;
   const    uint32_t             bitMask;

   static const uint32_t    GPIO_ANALOGUE_FN = PORT_PCR_MUX(0);
   static const uint32_t    GPIO_PORT_FN     = PORT_PCR_MUX(1);

public:

   DigitalIO(const DigitalIOData *data) : data(data), gpio(data->gpio), bitMask(data->bitMask) {
      SIM_SCGC5 |= data->clockMask;
   }

   void toggle() const {
      gpio->PTOR = bitMask;
   }
   void set() const  {
      gpio->PSOR = bitMask;
   }
   void clear() const  {
      gpio->PCOR = bitMask;
   }
   void setDigitalOutput() const  {
      *data->pcr = data->pcrValue|GPIO_PORT_FN;
      gpio->PDDR |= bitMask;
   }
   void setDigitalInput() const  {
      *data->pcr = data->pcrValue|GPIO_PORT_FN;
      gpio->PDDR &= ~bitMask;
   }
   void write(bool value) const  {
      if (value) {
         set();
      }
      else {
         clear();
      }
   }
   bool read() const  {
      return (gpio->PDIR & bitMask);
   }
};

/*
 * Class representing a pin with Digital & Analogue I/O capability
 */
class AnalogueIO : public DigitalIO {
public:
   struct AnalogueIOData {
      const    DigitalIOData  digitalData;
      volatile ADC0_Type     *adc;
      const    uint8_t        adcChannel;
   };
protected:
   void  initialiseADC(void) const;
   int   doADCConversion() const;

   const AnalogueIOData* const analogueData;

public:
   AnalogueIO(const AnalogueIOData *analogueData) : DigitalIO(&analogueData->digitalData), analogueData(analogueData) {
   }
   void setAnalogueInput() const {
      *data->pcr = data->pcrValue|GPIO_ANALOGUE_FN;
      initialiseADC();
   }
   int readAnalogue() const {
      return doADCConversion();
   }
};

class PwmIO : public DigitalIO {
public:
   typedef enum  {
      ftm_inputCaptureRisingEdge  = TPM_CnSC_ELSA_MASK,
      ftm_inputCaptureFallingEdge = TPM_CnSC_ELSB_MASK,
      ftm_inputCaptureEitherEdge  = TPM_CnSC_ELSB_MASK|TPM_CnSC_ELSA_MASK,
      ftm_outputCompare           = TPM_CnSC_MSA_MASK,
      ftm_outputCompareToggle     = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSA_MASK,
      ftm_outputCompareClear      = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSB_MASK,
      ftm_outputCompareSet        = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSB_MASK|TPM_CnSC_ELSA_MASK,
      ftm_pwmHighTruePulses       = TPM_CnSC_MSB_MASK|TPM_CnSC_ELSB_MASK,
      ftm_pwmLowTruePulses        = TPM_CnSC_MSB_MASK|TPM_CnSC_ELSA_MASK,
   } Ftm_Mode;

   typedef enum {
      ftm_leftAlign   = 0,
      ftm_centreAlign = TPM_SC_CPWMS_MASK,
   } Pwm_Mode;

public:
   struct PwmIOData {
      const    DigitalIOData  digitalData;
      volatile TPM0_Type     *ftm;
      const    uint8_t        ftmChannel;
      const    uint32_t       portMux;
   };

protected:
   const PwmIOData* const pwmData;

public:
   PwmIO(const PwmIOData *pwmData) : DigitalIO(&pwmData->digitalData), pwmData(pwmData) {
   }
   void setPwmOutput(int period /* ticks */, Pwm_Mode mode) const;
   void setDutyCycle(int dutyCycle) const;
   void setPeriod(int period) const;
};

/*
 * Standard 'Arduino' I/Os
 */
extern const AnalogueIO     gpioA0;
extern const AnalogueIO     gpioA1;
extern const AnalogueIO     gpioA2;
extern const AnalogueIO     gpioA3;
extern const AnalogueIO     gpioA4;
extern const AnalogueIO     gpioA5;

extern const DigitalIO      gpioD0;
extern const DigitalIO      gpioD1;
extern const DigitalIO      gpioD2;
extern const DigitalIO      gpioD3;
extern const DigitalIO      gpioD4;
extern const DigitalIO      gpioD5;
extern const DigitalIO      gpioD6;
extern const DigitalIO      gpioD7;

extern const DigitalIO      gpioD8;
extern const DigitalIO      gpioD9;
extern const DigitalIO      gpioD10;
extern const DigitalIO      gpioD11;
extern const DigitalIO      gpioD12;
extern const DigitalIO      gpioD13;
extern const DigitalIO      gpioD14;
extern const DigitalIO      gpioD15;

}

#endif /* GPIO_H_ */
