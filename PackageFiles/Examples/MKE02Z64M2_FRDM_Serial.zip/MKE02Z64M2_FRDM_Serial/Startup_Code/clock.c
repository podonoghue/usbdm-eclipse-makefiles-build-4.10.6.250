/*
 * clock.c
 *
 *  Created on: 19/08/2013
 *      Author: Peter
 */

#include "clock.h"

/**
 * Use default startup clock using internal oscillator (16MHz)
 *
 */

uint32_t const SystemCoreClock = 16000000; // hZ
uint32_t const SystemBusClock  = 16000000; // Hz

