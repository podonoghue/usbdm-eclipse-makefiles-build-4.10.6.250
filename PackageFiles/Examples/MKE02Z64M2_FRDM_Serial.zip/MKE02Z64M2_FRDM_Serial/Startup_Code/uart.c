/*
 * uart.c
 *
 *  Created on: 14/04/2013
 *      Author: pgo
 */

#include <derivative.h>
#include "clock.h"
#include "uart.h"
#include "Freedom.h"

void uart_initialise(int baudrate) {
   uint16_t ubd;

   // Enable clock to UART
   SIM_SCGC |= SIM_SCGC_UART1_MASK;

   // Set Tx & Rx Pin function
   SIM_PINSEL |= SIM_PINSEL_UART0PS_MASK;
//   UART1_TX_PIN_PCR = PORT_PCR_MUX(UART1_TX_PIN_FN) | PORT_PCR_DSE_MASK;
//   UART1_RX_PIN_PCR = PORT_PCR_MUX(UART1_RX_PIN_FN);

   // Set Tx & Rx pins in use
//   SIM_SOPT5 &= ~(SIM_SOPT5_UART1RXSRC_MASK|SIM_SOPT5_UART1TXSRC_MASK);

   // Disable UART before changing registers
   UART1_C2 &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK);

   // Calculate baud settings
   ubd = (uint16_t)(SystemCoreClock/(baudrate * 16));

   // Set Baud rate register
   UART1_BDH = (UART1_BDH&~UART_BDH_SBR_MASK) | UART_BDH_SBR((ubd>>8));
   UART1_BDL = UART_BDL_SBR(ubd);

#ifdef UART_C4_BRFA_MASK
   // Determine fractional divider to get closer to the baud rate
   uint16_t brfa;
   brfa     = (uint8_t)(((SystemCoreClock*32000)/(baudrate * 16)) - (ubd * 32));
   UART1_C4 = (UART1_C4&~UART_C4_BRFA_MASK) | UART_C4_BRFA(brfa);

#endif
   UART1_C1 = 0;

   // Enable UART Tx & Rx
   UART1_C2 = UART_C2_TE_MASK|UART_C2_RE_MASK;
}

void uart_txChar(int ch) {
   while ((UART1_S1 & UART_S1_TDRE_MASK) == 0) {
      // Wait for Tx buffer empty
   }
   UART1_D = ch;
}

int uart_rxChar(void) {
   while ((UART1_S1 & UART_S1_RDRF_MASK) == 0) {
      // Wait for Rx buffer full
   }
   return UART1_D;
};

