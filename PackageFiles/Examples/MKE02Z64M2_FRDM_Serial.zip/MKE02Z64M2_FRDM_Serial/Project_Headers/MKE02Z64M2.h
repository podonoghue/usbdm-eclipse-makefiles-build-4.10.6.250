/****************************************************************************************************//**
 * @file     MKE02Z2.h
 *
 * @brief    CMSIS Cortex-M Peripheral Access Layer Header File for MKE02Z2.
 *           Equivalent: MKE02Z32M2, MKE02Z16M2, MKE02Z64M2
 *
 * @version  V0.0
 * @date     December 2013
 *
 *******************************************************************************************************/

#ifndef MCU_MKE02Z2
#define MCU_MKE02Z2

#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

/* -------------------------  Interrupt Number Definition  ------------------------ */

typedef enum {
/* --------------------  Cortex-M Processor Exceptions Numbers  ------------------- */
  Reset_IRQn                    = -15,   /*!<   1 Reset Vector, invoked on Power up and warm reset                                 */
  NonMaskableInt_IRQn           = -14,   /*!<   2 Non maskable Interrupt, cannot be stopped or preempted                           */
  HardFault_IRQn                = -13,   /*!<   3 Hard Fault, all classes of Fault                                                 */
  SVCall_IRQn                   =  -5,   /*!<  11 System Service Call via SVC instruction                                          */
  PendSV_IRQn                   =  -2,   /*!<  14 Pendable request for system service                                              */
  SysTick_IRQn                  =  -1,   /*!<  15 System Tick Timer                                                                */
/* ----------------------   MKE02Z2 VectorTable                      ---------------------- */
  FTMRH_IRQn                    =   5,   /*!<  21 FTMRH Command complete or error                                                  */
  PMC_IRQn                      =   6,   /*!<  22 PMC Low-voltage detect, low-voltage warning                                      */
  IRQ_IRQn                      =   7,   /*!<  23 External Interrupt                                                               */
  I2C0_IRQn                     =   8,   /*!<  24 I2C Interface 0                                                                  */
  SPI0_IRQn                     =  10,   /*!<  26 Serial Peripheral Interface 0                                                    */
  SPI1_IRQn                     =  11,   /*!<  27 Serial Peripheral Interface 1                                                    */
  UART0_IRQn                    =  12,   /*!<  28 UART0 Status and error                                                           */
  UART1_IRQn                    =  13,   /*!<  29 UART1 Status and error                                                           */
  UART2_IRQn                    =  14,   /*!<  30 UART2 Status and error                                                           */
  ADC0_IRQn                     =  15,   /*!<  31 Analogue to Digital Converter 0                                                  */
  ACMP0_IRQn                    =  16,   /*!<  32 Analogue comparator 0                                                            */
  FTM0_IRQn                     =  17,   /*!<  33 Flexible Timer Module 0                                                          */
  FTM1_IRQn                     =  18,   /*!<  34 Flexible Timer Module 1                                                          */
  FTM2_IRQn                     =  19,   /*!<  35 Flexible Timer Module 2                                                          */
  RTC_IRQn                      =  20,   /*!<  36 Real Time Clock overflow                                                         */
  ACMP1_IRQn                    =  21,   /*!<  37 Analogue comparator 0                                                            */
  PIT_Ch0_IRQn                  =  22,   /*!<  38 Programmable Interrupt Timer Channel 0                                           */
  PIT_Ch1_IRQn                  =  23,   /*!<  39 Programmable Interrupt Timer Channel 1                                           */
  KBI0_IRQn                     =  24,   /*!<  40 Keyboard Interrupt 0                                                             */
  KBI1_IRQn                     =  25,   /*!<  41 Keyboard Interrupt 1                                                             */
  ICS_IRQn                      =  27,   /*!<  43 ICS                                                                              */
  WDOG_IRQn                     =  28,   /*!<  44 Watch dog                                                                        */
} IRQn_Type;

/* -------------------------  Exception Handlers  ------------------------ */
extern void NonMaskableIntHandler(void);
extern void HardFaultHandler(void);
extern void SVCallHandler(void);
extern void PendSVHandler(void);
extern void SysTickHandler(void);
extern void FTMRH_IRQHandler(void);
extern void PMC_IRQHandler(void);
extern void IRQ_IRQHandler(void);
extern void I2C0_IRQHandler(void);
extern void SPI0_IRQHandler(void);
extern void SPI1_IRQHandler(void);
extern void UART0_IRQHandler(void);
extern void UART1_IRQHandler(void);
extern void UART2_IRQHandler(void);
extern void ADC0_IRQHandler(void);
extern void ACMP0_IRQHandler(void);
extern void FTM0_IRQHandler(void);
extern void FTM1_IRQHandler(void);
extern void FTM2_IRQHandler(void);
extern void RTC_IRQHandler(void);
extern void ACMP1_IRQHandler(void);
extern void PIT_Ch0_IRQHandler(void);
extern void PIT_Ch1_IRQHandler(void);
extern void KBI0_IRQHandler(void);
extern void KBI1_IRQHandler(void);
extern void ICS_IRQHandler(void);
extern void WDOG_IRQHandler(void);

/* ================================================================================ */
/* ================      Processor and Core Peripheral Section     ================ */
/* ================================================================================ */

/* ----------------Configuration of the cm4 Processor and Core Peripherals---------------- */
#define __CM0_REV              0x0100
#define __MPU_PRESENT            0
#define __NVIC_PRIO_BITS         2
#define __Vendor_SysTickConfig   0
#define __FPU_PRESENT            0

#include <core_cm0.h>   /*!< Cortex-M4 processor and core peripherals                              */

#ifndef __IO
#define __IO volatile 
#endif

#ifndef __I
#define __I volatile const
#endif

#ifndef __O
#define __O volatile
#endif


/* ================================================================================ */
/* ================       Device Specific Peripheral Section       ================ */
/* ================================================================================ */



/* -------------------  Start of section using anonymous unions  ------------------ */
#if defined(__CC_ARM)
  #pragma push
  #pragma anon_unions
#elif defined(__ICCARM__)
  #pragma language=extended
#elif defined(__GNUC__)
  /* anonymous unions are enabled by default */
#elif defined(__TMS470__)
/* anonymous unions are enabled by default */
#elif defined(__TASKING__)
  #pragma warning 586
#else
  #warning Not supported compiler type
#endif

/* ================================================================================ */
/* ================           ACMP0 (file:ACMP0_MKE)               ================ */
/* ================================================================================ */

/**
 * @brief Analog comparator (ACMP0)
 */
typedef struct {                                /*!<       ACMP0 Structure                                              */
   __IO uint8_t   CS;                           /*!< 0000: ACMP Control and Status Register                             */
   __IO uint8_t   C0;                           /*!< 0001: ACMP Control Register 0                                      */
   __IO uint8_t   C1;                           /*!< 0002: ACMP Control Register 1                                      */
   __IO uint8_t   C2;                           /*!< 0003: ACMP Control Register 2                                      */
} ACMP0_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'ACMP0' Position & Mask macros                       ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- ACMP0_CS                                 ------ */
#define ACMP0_CS_ACMOD_MASK                      (0x03UL << ACMP0_CS_ACMOD_SHIFT)                    /*!< ACMP0_CS: ACMOD Mask                    */
#define ACMP0_CS_ACMOD_SHIFT                     0                                                   /*!< ACMP0_CS: ACMOD Position                */
#define ACMP0_CS_ACMOD(x)                        (((x)<<ACMP0_CS_ACMOD_SHIFT)&ACMP0_CS_ACMOD_MASK)   /*!< ACMP0_CS                                */
#define ACMP0_CS_ACOPE_MASK                      (0x01UL << ACMP0_CS_ACOPE_SHIFT)                    /*!< ACMP0_CS: ACOPE Mask                    */
#define ACMP0_CS_ACOPE_SHIFT                     2                                                   /*!< ACMP0_CS: ACOPE Position                */
#define ACMP0_CS_ACO_MASK                        (0x01UL << ACMP0_CS_ACO_SHIFT)                      /*!< ACMP0_CS: ACO Mask                      */
#define ACMP0_CS_ACO_SHIFT                       3                                                   /*!< ACMP0_CS: ACO Position                  */
#define ACMP0_CS_ACIE_MASK                       (0x01UL << ACMP0_CS_ACIE_SHIFT)                     /*!< ACMP0_CS: ACIE Mask                     */
#define ACMP0_CS_ACIE_SHIFT                      4                                                   /*!< ACMP0_CS: ACIE Position                 */
#define ACMP0_CS_ACF_MASK                        (0x01UL << ACMP0_CS_ACF_SHIFT)                      /*!< ACMP0_CS: ACF Mask                      */
#define ACMP0_CS_ACF_SHIFT                       5                                                   /*!< ACMP0_CS: ACF Position                  */
#define ACMP0_CS_HYST_MASK                       (0x01UL << ACMP0_CS_HYST_SHIFT)                     /*!< ACMP0_CS: HYST Mask                     */
#define ACMP0_CS_HYST_SHIFT                      6                                                   /*!< ACMP0_CS: HYST Position                 */
#define ACMP0_CS_ACE_MASK                        (0x01UL << ACMP0_CS_ACE_SHIFT)                      /*!< ACMP0_CS: ACE Mask                      */
#define ACMP0_CS_ACE_SHIFT                       7                                                   /*!< ACMP0_CS: ACE Position                  */

/* ------- ACMP0_C0                                 ------ */
#define ACMP0_C0_ACNSEL_MASK                     (0x03UL << ACMP0_C0_ACNSEL_SHIFT)                   /*!< ACMP0_C0: ACNSEL Mask                   */
#define ACMP0_C0_ACNSEL_SHIFT                    0                                                   /*!< ACMP0_C0: ACNSEL Position               */
#define ACMP0_C0_ACNSEL(x)                       (((x)<<ACMP0_C0_ACNSEL_SHIFT)&ACMP0_C0_ACNSEL_MASK) /*!< ACMP0_C0                                */
#define ACMP0_C0_ACPSEL_MASK                     (0x03UL << ACMP0_C0_ACPSEL_SHIFT)                   /*!< ACMP0_C0: ACPSEL Mask                   */
#define ACMP0_C0_ACPSEL_SHIFT                    4                                                   /*!< ACMP0_C0: ACPSEL Position               */
#define ACMP0_C0_ACPSEL(x)                       (((x)<<ACMP0_C0_ACPSEL_SHIFT)&ACMP0_C0_ACPSEL_MASK) /*!< ACMP0_C0                                */

/* ------- ACMP0_C1                                 ------ */
#define ACMP0_C1_DACVAL_MASK                     (0x3FUL << ACMP0_C1_DACVAL_SHIFT)                   /*!< ACMP0_C1: DACVAL Mask                   */
#define ACMP0_C1_DACVAL_SHIFT                    0                                                   /*!< ACMP0_C1: DACVAL Position               */
#define ACMP0_C1_DACVAL(x)                       (((x)<<ACMP0_C1_DACVAL_SHIFT)&ACMP0_C1_DACVAL_MASK) /*!< ACMP0_C1                                */
#define ACMP0_C1_DACREF_MASK                     (0x01UL << ACMP0_C1_DACREF_SHIFT)                   /*!< ACMP0_C1: DACREF Mask                   */
#define ACMP0_C1_DACREF_SHIFT                    6                                                   /*!< ACMP0_C1: DACREF Position               */
#define ACMP0_C1_DACEN_MASK                      (0x01UL << ACMP0_C1_DACEN_SHIFT)                    /*!< ACMP0_C1: DACEN Mask                    */
#define ACMP0_C1_DACEN_SHIFT                     7                                                   /*!< ACMP0_C1: DACEN Position                */

/* ------- ACMP0_C2                                 ------ */
#define ACMP0_C2_ACIPE_MASK                      (0x01UL << ACMP0_C2_ACIPE_SHIFT)                    /*!< ACMP0_C2: ACIPE Mask                    */
#define ACMP0_C2_ACIPE_SHIFT                     0                                                   /*!< ACMP0_C2: ACIPE Position                */

/* -------------------------------------------------------------------------------- */
/* -----------     'ACMP0' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define ACMP0_CS                       (ACMP0->CS)
#define ACMP0_C0                       (ACMP0->C0)
#define ACMP0_C1                       (ACMP0->C1)
#define ACMP0_C2                       (ACMP0->C2)

/* ================================================================================ */
/* ================           ACMP1 (derived from ACMP0)           ================ */
/* ================================================================================ */

/**
 * @brief Analog comparator (ACMP1)
 */
typedef ACMP0_Type ACMP1_Type;  /*!< ACMP1 Structure                                             */


/* -------------------------------------------------------------------------------- */
/* -----------     'ACMP1' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define ACMP1_CS                       (ACMP1->CS)
#define ACMP1_C0                       (ACMP1->C0)
#define ACMP1_C1                       (ACMP1->C1)
#define ACMP1_C2                       (ACMP1->C2)

/* ================================================================================ */
/* ================           ADC (file:ADC_0_MKE)                 ================ */
/* ================================================================================ */

/**
 * @brief Analog-to-digital converter (ADC)
 */
typedef struct {                                /*!<       ADC Structure                                                */
   __IO uint32_t  SC1;                          /*!< 0000: Status and Control Register 1                                */
   __IO uint32_t  SC2;                          /*!< 0004: Status and Control Register 2                                */
   __IO uint32_t  SC3;                          /*!< 0008: Status and Control Register 3                                */
   __IO uint32_t  SC4;                          /*!< 000C: Status and Control Register 4                                */
   __I  uint32_t  R;                            /*!< 0010: Conversion Result Register                                   */
   __IO uint32_t  CV;                           /*!< 0014: Compare Value Register                                       */
   __IO uint32_t  APCTL1;                       /*!< 0018: Pin Control 1 Register                                       */
} ADC_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'ADC' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- ADC_SC1                                  ------ */
#define ADC_SC1_ADCH_MASK                        (0x1FUL << ADC_SC1_ADCH_SHIFT)                      /*!< ADC_SC1: ADCH Mask                      */
#define ADC_SC1_ADCH_SHIFT                       0                                                   /*!< ADC_SC1: ADCH Position                  */
#define ADC_SC1_ADCH(x)                          (((x)<<ADC_SC1_ADCH_SHIFT)&ADC_SC1_ADCH_MASK)       /*!< ADC_SC1                                 */
#define ADC_SC1_ADCO_MASK                        (0x01UL << ADC_SC1_ADCO_SHIFT)                      /*!< ADC_SC1: ADCO Mask                      */
#define ADC_SC1_ADCO_SHIFT                       5                                                   /*!< ADC_SC1: ADCO Position                  */
#define ADC_SC1_AIEN_MASK                        (0x01UL << ADC_SC1_AIEN_SHIFT)                      /*!< ADC_SC1: AIEN Mask                      */
#define ADC_SC1_AIEN_SHIFT                       6                                                   /*!< ADC_SC1: AIEN Position                  */
#define ADC_SC1_COCO_MASK                        (0x01UL << ADC_SC1_COCO_SHIFT)                      /*!< ADC_SC1: COCO Mask                      */
#define ADC_SC1_COCO_SHIFT                       7                                                   /*!< ADC_SC1: COCO Position                  */

/* ------- ADC_SC2                                  ------ */
#define ADC_SC2_REFSEL_MASK                      (0x03UL << ADC_SC2_REFSEL_SHIFT)                    /*!< ADC_SC2: REFSEL Mask                    */
#define ADC_SC2_REFSEL_SHIFT                     0                                                   /*!< ADC_SC2: REFSEL Position                */
#define ADC_SC2_REFSEL(x)                        (((x)<<ADC_SC2_REFSEL_SHIFT)&ADC_SC2_REFSEL_MASK)   /*!< ADC_SC2                                 */
#define ADC_SC2_FFULL_MASK                       (0x01UL << ADC_SC2_FFULL_SHIFT)                     /*!< ADC_SC2: FFULL Mask                     */
#define ADC_SC2_FFULL_SHIFT                      2                                                   /*!< ADC_SC2: FFULL Position                 */
#define ADC_SC2_FEMPTY_MASK                      (0x01UL << ADC_SC2_FEMPTY_SHIFT)                    /*!< ADC_SC2: FEMPTY Mask                    */
#define ADC_SC2_FEMPTY_SHIFT                     3                                                   /*!< ADC_SC2: FEMPTY Position                */
#define ADC_SC2_ACFGT_MASK                       (0x01UL << ADC_SC2_ACFGT_SHIFT)                     /*!< ADC_SC2: ACFGT Mask                     */
#define ADC_SC2_ACFGT_SHIFT                      4                                                   /*!< ADC_SC2: ACFGT Position                 */
#define ADC_SC2_ACFE_MASK                        (0x01UL << ADC_SC2_ACFE_SHIFT)                      /*!< ADC_SC2: ACFE Mask                      */
#define ADC_SC2_ACFE_SHIFT                       5                                                   /*!< ADC_SC2: ACFE Position                  */
#define ADC_SC2_ADTRG_MASK                       (0x01UL << ADC_SC2_ADTRG_SHIFT)                     /*!< ADC_SC2: ADTRG Mask                     */
#define ADC_SC2_ADTRG_SHIFT                      6                                                   /*!< ADC_SC2: ADTRG Position                 */
#define ADC_SC2_ADACT_MASK                       (0x01UL << ADC_SC2_ADACT_SHIFT)                     /*!< ADC_SC2: ADACT Mask                     */
#define ADC_SC2_ADACT_SHIFT                      7                                                   /*!< ADC_SC2: ADACT Position                 */

/* ------- ADC_SC3                                  ------ */
#define ADC_SC3_ADICLK_MASK                      (0x01UL << ADC_SC3_ADICLK_SHIFT)                    /*!< ADC_SC3: ADICLK Mask                    */
#define ADC_SC3_ADICLK_SHIFT                     0                                                   /*!< ADC_SC3: ADICLK Position                */
#define ADC_SC3_MODE_MASK                        (0x03UL << ADC_SC3_MODE_SHIFT)                      /*!< ADC_SC3: MODE Mask                      */
#define ADC_SC3_MODE_SHIFT                       2                                                   /*!< ADC_SC3: MODE Position                  */
#define ADC_SC3_MODE(x)                          (((x)<<ADC_SC3_MODE_SHIFT)&ADC_SC3_MODE_MASK)       /*!< ADC_SC3                                 */
#define ADC_SC3_ADLSMP_MASK                      (0x01UL << ADC_SC3_ADLSMP_SHIFT)                    /*!< ADC_SC3: ADLSMP Mask                    */
#define ADC_SC3_ADLSMP_SHIFT                     4                                                   /*!< ADC_SC3: ADLSMP Position                */
#define ADC_SC3_ADIV_MASK                        (0x03UL << ADC_SC3_ADIV_SHIFT)                      /*!< ADC_SC3: ADIV Mask                      */
#define ADC_SC3_ADIV_SHIFT                       5                                                   /*!< ADC_SC3: ADIV Position                  */
#define ADC_SC3_ADIV(x)                          (((x)<<ADC_SC3_ADIV_SHIFT)&ADC_SC3_ADIV_MASK)       /*!< ADC_SC3                                 */
#define ADC_SC3_ADLPC_MASK                       (0x01UL << ADC_SC3_ADLPC_SHIFT)                     /*!< ADC_SC3: ADLPC Mask                     */
#define ADC_SC3_ADLPC_SHIFT                      7                                                   /*!< ADC_SC3: ADLPC Position                 */

/* ------- ADC_SC4                                  ------ */
#define ADC_SC4_AFDEP_MASK                       (0x07UL << ADC_SC4_AFDEP_SHIFT)                     /*!< ADC_SC4: AFDEP Mask                     */
#define ADC_SC4_AFDEP_SHIFT                      0                                                   /*!< ADC_SC4: AFDEP Position                 */
#define ADC_SC4_AFDEP(x)                         (((x)<<ADC_SC4_AFDEP_SHIFT)&ADC_SC4_AFDEP_MASK)     /*!< ADC_SC4                                 */
#define ADC_SC4_ACFSEL_MASK                      (0x01UL << ADC_SC4_ACFSEL_SHIFT)                    /*!< ADC_SC4: ACFSEL Mask                    */
#define ADC_SC4_ACFSEL_SHIFT                     5                                                   /*!< ADC_SC4: ACFSEL Position                */
#define ADC_SC4_ASCANE_MASK                      (0x01UL << ADC_SC4_ASCANE_SHIFT)                    /*!< ADC_SC4: ASCANE Mask                    */
#define ADC_SC4_ASCANE_SHIFT                     6                                                   /*!< ADC_SC4: ASCANE Position                */

/* ------- ADC_R                                    ------ */
#define ADC_R_ADR_MASK                           (0xFFFUL << ADC_R_ADR_SHIFT)                        /*!< ADC_R: ADR Mask                         */
#define ADC_R_ADR_SHIFT                          0                                                   /*!< ADC_R: ADR Position                     */
#define ADC_R_ADR(x)                             (((x)<<ADC_R_ADR_SHIFT)&ADC_R_ADR_MASK)             /*!< ADC_R                                   */

/* ------- ADC_CV                                   ------ */
#define ADC_CV_ADR_MASK                          (0xFFFUL << ADC_CV_ADR_SHIFT)                       /*!< ADC_CV: ADR Mask                        */
#define ADC_CV_ADR_SHIFT                         0                                                   /*!< ADC_CV: ADR Position                    */
#define ADC_CV_ADR(x)                            (((x)<<ADC_CV_ADR_SHIFT)&ADC_CV_ADR_MASK)           /*!< ADC_CV                                  */

/* ------- ADC_APCTL1                               ------ */
#define ADC_APCTL1_ADPC_MASK                     (0xFFFFUL << ADC_APCTL1_ADPC_SHIFT)                 /*!< ADC_APCTL1: ADPC Mask                   */
#define ADC_APCTL1_ADPC_SHIFT                    0                                                   /*!< ADC_APCTL1: ADPC Position               */
#define ADC_APCTL1_ADPC(x)                       (((x)<<ADC_APCTL1_ADPC_SHIFT)&ADC_APCTL1_ADPC_MASK) /*!< ADC_APCTL1                              */

/* -------------------------------------------------------------------------------- */
/* -----------     'ADC' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define ADC_SC1                        (ADC->SC1)
#define ADC_SC2                        (ADC->SC2)
#define ADC_SC3                        (ADC->SC3)
#define ADC_SC4                        (ADC->SC4)
#define ADC_R                          (ADC->R)
#define ADC_CV                         (ADC->CV)
#define ADC_APCTL1                     (ADC->APCTL1)

/* ================================================================================ */
/* ================           BP (file:BP_1_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Breakpoint Unit
 */
typedef struct {                                /*!<       BP Structure                                                 */
   __IO uint32_t  CTRL;                         /*!< 0000:                                                              */
   __I  uint32_t  RESERVED0;                    /*!< 0004:                                                              */
   __IO uint32_t  COMP[2];                      /*!< 0008:                                                              */
   __I  uint32_t  RESERVED1[1008];              /*!< 0010:                                                              */
   __IO uint32_t  PID4;                         /*!< 0FD0:                                                              */
   __IO uint32_t  PID5;                         /*!< 0FD4:                                                              */
   __IO uint32_t  PID6;                         /*!< 0FD8:                                                              */
   __IO uint32_t  PID7;                         /*!< 0FDC:                                                              */
   __IO uint32_t  PID0;                         /*!< 0FE0:                                                              */
   __IO uint32_t  PID1;                         /*!< 0FE4:                                                              */
   __IO uint32_t  PID2;                         /*!< 0FE8:                                                              */
   __IO uint32_t  PID3;                         /*!< 0FEC:                                                              */
   __IO uint32_t  CID[4];                       /*!< 0FF0:                                                              */
} BP_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'BP' Position & Mask macros                          ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- BP_CTRL                                  ------ */

/* ------- BP_COMP                                  ------ */

/* ------- BP_PID                                   ------ */

/* ------- BP_CID                                   ------ */

/* -------------------------------------------------------------------------------- */
/* -----------     'BP' Register Access macros                          ----------- */
/* -------------------------------------------------------------------------------- */

#define BP_CTRL                        (BP->CTRL)
#define BP_COMP0                       (BP->COMP[0])
#define BP_COMP1                       (BP->COMP[1])
#define BP_PID4                        (BP->PID4)
#define BP_PID5                        (BP->PID5)
#define BP_PID6                        (BP->PID6)
#define BP_PID7                        (BP->PID7)
#define BP_PID0                        (BP->PID0)
#define BP_PID1                        (BP->PID1)
#define BP_PID2                        (BP->PID2)
#define BP_PID3                        (BP->PID3)
#define BP_CID0                        (BP->CID[0])
#define BP_CID1                        (BP->CID[1])
#define BP_CID2                        (BP->CID[2])
#define BP_CID3                        (BP->CID[3])

/* ================================================================================ */
/* ================           CRC (file:CRC_0)                     ================ */
/* ================================================================================ */

/**
 * @brief Cyclic Redundancy Check (CRC)
 */
typedef struct {                                /*!<       CRC Structure                                                */
   __IO uint32_t  DATA;                         /*!< 0000: CRC Data register                                            */
   __IO uint32_t  GPOLY;                        /*!< 0004: CRC Polynomial register                                      */
   __IO uint32_t  CTRL;                         /*!< 0008: CRC Control register                                         */
} CRC_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'CRC' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- CRC_DATA                                 ------ */
#define CRC_DATA_LL_MASK                         (0xFFUL << CRC_DATA_LL_SHIFT)                       /*!< CRC_DATA: LL Mask                       */
#define CRC_DATA_LL_SHIFT                        0                                                   /*!< CRC_DATA: LL Position                   */
#define CRC_DATA_LL(x)                           (((x)<<CRC_DATA_LL_SHIFT)&CRC_DATA_LL_MASK)         /*!< CRC_DATA                                */
#define CRC_DATA_LU_MASK                         (0xFFUL << CRC_DATA_LU_SHIFT)                       /*!< CRC_DATA: LU Mask                       */
#define CRC_DATA_LU_SHIFT                        8                                                   /*!< CRC_DATA: LU Position                   */
#define CRC_DATA_LU(x)                           (((x)<<CRC_DATA_LU_SHIFT)&CRC_DATA_LU_MASK)         /*!< CRC_DATA                                */
#define CRC_DATA_HL_MASK                         (0xFFUL << CRC_DATA_HL_SHIFT)                       /*!< CRC_DATA: HL Mask                       */
#define CRC_DATA_HL_SHIFT                        16                                                  /*!< CRC_DATA: HL Position                   */
#define CRC_DATA_HL(x)                           (((x)<<CRC_DATA_HL_SHIFT)&CRC_DATA_HL_MASK)         /*!< CRC_DATA                                */
#define CRC_DATA_HU_MASK                         (0xFFUL << CRC_DATA_HU_SHIFT)                       /*!< CRC_DATA: HU Mask                       */
#define CRC_DATA_HU_SHIFT                        24                                                  /*!< CRC_DATA: HU Position                   */
#define CRC_DATA_HU(x)                           (((x)<<CRC_DATA_HU_SHIFT)&CRC_DATA_HU_MASK)         /*!< CRC_DATA                                */

/* ------- CRC_GPOLY                                ------ */
#define CRC_GPOLY_LOW_MASK                       (0xFFFFUL << CRC_GPOLY_LOW_SHIFT)                   /*!< CRC_GPOLY: LOW Mask                     */
#define CRC_GPOLY_LOW_SHIFT                      0                                                   /*!< CRC_GPOLY: LOW Position                 */
#define CRC_GPOLY_LOW(x)                         (((x)<<CRC_GPOLY_LOW_SHIFT)&CRC_GPOLY_LOW_MASK)     /*!< CRC_GPOLY                               */
#define CRC_GPOLY_HIGH_MASK                      (0xFFFFUL << CRC_GPOLY_HIGH_SHIFT)                  /*!< CRC_GPOLY: HIGH Mask                    */
#define CRC_GPOLY_HIGH_SHIFT                     16                                                  /*!< CRC_GPOLY: HIGH Position                */
#define CRC_GPOLY_HIGH(x)                        (((x)<<CRC_GPOLY_HIGH_SHIFT)&CRC_GPOLY_HIGH_MASK)   /*!< CRC_GPOLY                               */

/* ------- CRC_CTRL                                 ------ */
#define CRC_CTRL_TCRC_MASK                       (0x01UL << CRC_CTRL_TCRC_SHIFT)                     /*!< CRC_CTRL: TCRC Mask                     */
#define CRC_CTRL_TCRC_SHIFT                      24                                                  /*!< CRC_CTRL: TCRC Position                 */
#define CRC_CTRL_WAS_MASK                        (0x01UL << CRC_CTRL_WAS_SHIFT)                      /*!< CRC_CTRL: WAS Mask                      */
#define CRC_CTRL_WAS_SHIFT                       25                                                  /*!< CRC_CTRL: WAS Position                  */
#define CRC_CTRL_FXOR_MASK                       (0x01UL << CRC_CTRL_FXOR_SHIFT)                     /*!< CRC_CTRL: FXOR Mask                     */
#define CRC_CTRL_FXOR_SHIFT                      26                                                  /*!< CRC_CTRL: FXOR Position                 */
#define CRC_CTRL_TOTR_MASK                       (0x03UL << CRC_CTRL_TOTR_SHIFT)                     /*!< CRC_CTRL: TOTR Mask                     */
#define CRC_CTRL_TOTR_SHIFT                      28                                                  /*!< CRC_CTRL: TOTR Position                 */
#define CRC_CTRL_TOTR(x)                         (((x)<<CRC_CTRL_TOTR_SHIFT)&CRC_CTRL_TOTR_MASK)     /*!< CRC_CTRL                                */
#define CRC_CTRL_TOT_MASK                        (0x03UL << CRC_CTRL_TOT_SHIFT)                      /*!< CRC_CTRL: TOT Mask                      */
#define CRC_CTRL_TOT_SHIFT                       30                                                  /*!< CRC_CTRL: TOT Position                  */
#define CRC_CTRL_TOT(x)                          (((x)<<CRC_CTRL_TOT_SHIFT)&CRC_CTRL_TOT_MASK)       /*!< CRC_CTRL                                */

/* -------------------------------------------------------------------------------- */
/* -----------     'CRC' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define CRC_DATA                       (CRC->DATA)
#define CRC_GPOLY                      (CRC->GPOLY)
#define CRC_CTRL                       (CRC->CTRL)

/* ================================================================================ */
/* ================           FGPIOA (file:FGPIOA_MKE)             ================ */
/* ================================================================================ */

/**
 * @brief General Purpose Input/Output (PTA)
 */
typedef struct {                                /*!<       FGPIOA Structure                                             */
   __IO uint32_t  PDOR;                         /*!< 0000: Port Data Output Register                                    */
   __O  uint32_t  PSOR;                         /*!< 0004: Port Set Output Register                                     */
   __O  uint32_t  PCOR;                         /*!< 0008: Port Clear Output Register                                   */
   __O  uint32_t  PTOR;                         /*!< 000C: Port Toggle Output Register                                  */
   __IO uint32_t  PDIR;                         /*!< 0010: Port Data Input Register                                     */
   __IO uint32_t  PDDR;                         /*!< 0014: Port Data Direction Register                                 */
   __I  uint32_t  PIDR;                         /*!< 0018: Port Input Disable Register                                  */
} FGPIOA_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'FGPIOA' Position & Mask macros                      ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- FGPIOA_PDOR                              ------ */
#define GPIO_PDOR_PDO_MASK                       (0xFFFFFFFFUL << GPIO_PDOR_PDO_SHIFT)               /*!< FGPIOA_PDOR: PDO Mask                   */
#define GPIO_PDOR_PDO_SHIFT                      0                                                   /*!< FGPIOA_PDOR: PDO Position               */
#define GPIO_PDOR_PDO(x)                         (((x)<<GPIO_PDOR_PDO_SHIFT)&GPIO_PDOR_PDO_MASK)     /*!< FGPIOA_PDOR                             */

/* ------- FGPIOA_PSOR                              ------ */
#define GPIO_PSOR_PTSO_MASK                      (0xFFFFFFFFUL << GPIO_PSOR_PTSO_SHIFT)              /*!< FGPIOA_PSOR: PTSO Mask                  */
#define GPIO_PSOR_PTSO_SHIFT                     0                                                   /*!< FGPIOA_PSOR: PTSO Position              */
#define GPIO_PSOR_PTSO(x)                        (((x)<<GPIO_PSOR_PTSO_SHIFT)&GPIO_PSOR_PTSO_MASK)   /*!< FGPIOA_PSOR                             */

/* ------- FGPIOA_PCOR                              ------ */
#define GPIO_PCOR_PTCO_MASK                      (0xFFFFFFFFUL << GPIO_PCOR_PTCO_SHIFT)              /*!< FGPIOA_PCOR: PTCO Mask                  */
#define GPIO_PCOR_PTCO_SHIFT                     0                                                   /*!< FGPIOA_PCOR: PTCO Position              */
#define GPIO_PCOR_PTCO(x)                        (((x)<<GPIO_PCOR_PTCO_SHIFT)&GPIO_PCOR_PTCO_MASK)   /*!< FGPIOA_PCOR                             */

/* ------- FGPIOA_PTOR                              ------ */
#define GPIO_PTOR_PTTO_MASK                      (0xFFFFFFFFUL << GPIO_PTOR_PTTO_SHIFT)              /*!< FGPIOA_PTOR: PTTO Mask                  */
#define GPIO_PTOR_PTTO_SHIFT                     0                                                   /*!< FGPIOA_PTOR: PTTO Position              */
#define GPIO_PTOR_PTTO(x)                        (((x)<<GPIO_PTOR_PTTO_SHIFT)&GPIO_PTOR_PTTO_MASK)   /*!< FGPIOA_PTOR                             */

/* ------- FGPIOA_PDIR                              ------ */
#define GPIO_PDIR_PDI_MASK                       (0xFFFFFFFFUL << GPIO_PDIR_PDI_SHIFT)               /*!< FGPIOA_PDIR: PDI Mask                   */
#define GPIO_PDIR_PDI_SHIFT                      0                                                   /*!< FGPIOA_PDIR: PDI Position               */
#define GPIO_PDIR_PDI(x)                         (((x)<<GPIO_PDIR_PDI_SHIFT)&GPIO_PDIR_PDI_MASK)     /*!< FGPIOA_PDIR                             */

/* ------- FGPIOA_PDDR                              ------ */
#define GPIO_PDDR_PDD_MASK                       (0xFFFFFFFFUL << GPIO_PDDR_PDD_SHIFT)               /*!< FGPIOA_PDDR: PDD Mask                   */
#define GPIO_PDDR_PDD_SHIFT                      0                                                   /*!< FGPIOA_PDDR: PDD Position               */
#define GPIO_PDDR_PDD(x)                         (((x)<<GPIO_PDDR_PDD_SHIFT)&GPIO_PDDR_PDD_MASK)     /*!< FGPIOA_PDDR                             */

/* ------- FGPIOA_PIDR                              ------ */

/* -------------------------------------------------------------------------------- */
/* -----------     'FGPIOA' Register Access macros                      ----------- */
/* -------------------------------------------------------------------------------- */

#define FGPIOA_PDOR                    (FGPIOA->PDOR)
#define FGPIOA_PSOR                    (FGPIOA->PSOR)
#define FGPIOA_PCOR                    (FGPIOA->PCOR)
#define FGPIOA_PTOR                    (FGPIOA->PTOR)
#define FGPIOA_PDIR                    (FGPIOA->PDIR)
#define FGPIOA_PDDR                    (FGPIOA->PDDR)
#define FGPIOA_PIDR                    (FGPIOA->PIDR)

/* ================================================================================ */
/* ================           FGPIOB (derived from FGPIOA)         ================ */
/* ================================================================================ */

/**
 * @brief General Purpose Input/Output (FPTB)
 */
typedef FGPIOA_Type FGPIOB_Type;  /*!< FGPIOB Structure                                            */


/* -------------------------------------------------------------------------------- */
/* -----------     'FGPIOB' Register Access macros                      ----------- */
/* -------------------------------------------------------------------------------- */

#define FGPIOB_PDOR                    (FGPIOB->PDOR)
#define FGPIOB_PSOR                    (FGPIOB->PSOR)
#define FGPIOB_PCOR                    (FGPIOB->PCOR)
#define FGPIOB_PTOR                    (FGPIOB->PTOR)
#define FGPIOB_PDIR                    (FGPIOB->PDIR)
#define FGPIOB_PDDR                    (FGPIOB->PDDR)
#define FGPIOB_PIDR                    (FGPIOB->PIDR)

/* ================================================================================ */
/* ================           FTM0 (file:FTM0_2CH_MKE)             ================ */
/* ================================================================================ */

/**
 * @brief FlexTimer Module (2 channels)
 */
typedef struct {                                /*!<       FTM0 Structure                                               */
   __IO uint32_t  SC;                           /*!< 0000: Status and Control                                           */
   __IO uint32_t  CNT;                          /*!< 0004: Counter                                                      */
   __IO uint32_t  MOD;                          /*!< 0008: Modulo                                                       */
   struct { /* (cluster) */                     /*!< 000C: (size=0x0010, 16)                                            */
      __IO uint32_t  CnSC;                      /*!< 000C: Channel (n) Status and Control                               */
      __IO uint32_t  CnV;                       /*!< 0010: Channel (n) Value                                            */
   } CONTROLS[2];
} FTM0_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'FTM0' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- FTM0_SC                                  ------ */
#define FTM_SC_PS_MASK                           (0x07UL << FTM_SC_PS_SHIFT)                         /*!< FTM0_SC: PS Mask                        */
#define FTM_SC_PS_SHIFT                          0                                                   /*!< FTM0_SC: PS Position                    */
#define FTM_SC_PS(x)                             (((x)<<FTM_SC_PS_SHIFT)&FTM_SC_PS_MASK)             /*!< FTM0_SC                                 */
#define FTM_SC_CLKS_MASK                         (0x03UL << FTM_SC_CLKS_SHIFT)                       /*!< FTM0_SC: CLKS Mask                      */
#define FTM_SC_CLKS_SHIFT                        3                                                   /*!< FTM0_SC: CLKS Position                  */
#define FTM_SC_CLKS(x)                           (((x)<<FTM_SC_CLKS_SHIFT)&FTM_SC_CLKS_MASK)         /*!< FTM0_SC                                 */
#define FTM_SC_CPWMS_MASK                        (0x01UL << FTM_SC_CPWMS_SHIFT)                      /*!< FTM0_SC: CPWMS Mask                     */
#define FTM_SC_CPWMS_SHIFT                       5                                                   /*!< FTM0_SC: CPWMS Position                 */
#define FTM_SC_TOIE_MASK                         (0x01UL << FTM_SC_TOIE_SHIFT)                       /*!< FTM0_SC: TOIE Mask                      */
#define FTM_SC_TOIE_SHIFT                        6                                                   /*!< FTM0_SC: TOIE Position                  */
#define FTM_SC_TOF_MASK                          (0x01UL << FTM_SC_TOF_SHIFT)                        /*!< FTM0_SC: TOF Mask                       */
#define FTM_SC_TOF_SHIFT                         7                                                   /*!< FTM0_SC: TOF Position                   */

/* ------- FTM0_CNT                                 ------ */
#define FTM_CNT_COUNT_MASK                       (0xFFFFUL << FTM_CNT_COUNT_SHIFT)                   /*!< FTM0_CNT: COUNT Mask                    */
#define FTM_CNT_COUNT_SHIFT                      0                                                   /*!< FTM0_CNT: COUNT Position                */
#define FTM_CNT_COUNT(x)                         (((x)<<FTM_CNT_COUNT_SHIFT)&FTM_CNT_COUNT_MASK)     /*!< FTM0_CNT                                */

/* ------- FTM0_MOD                                 ------ */
#define FTM_MOD_MOD_MASK                         (0xFFFFUL << FTM_MOD_MOD_SHIFT)                     /*!< FTM0_MOD: MOD Mask                      */
#define FTM_MOD_MOD_SHIFT                        0                                                   /*!< FTM0_MOD: MOD Position                  */
#define FTM_MOD_MOD(x)                           (((x)<<FTM_MOD_MOD_SHIFT)&FTM_MOD_MOD_MASK)         /*!< FTM0_MOD                                */

/* ------- FTM0_CnSC                                ------ */
#define FTM_CnSC_ELSA_MASK                       (0x01UL << FTM_CnSC_ELSA_SHIFT)                     /*!< FTM0_CnSC: ELSA Mask                    */
#define FTM_CnSC_ELSA_SHIFT                      2                                                   /*!< FTM0_CnSC: ELSA Position                */
#define FTM_CnSC_ELSB_MASK                       (0x01UL << FTM_CnSC_ELSB_SHIFT)                     /*!< FTM0_CnSC: ELSB Mask                    */
#define FTM_CnSC_ELSB_SHIFT                      3                                                   /*!< FTM0_CnSC: ELSB Position                */
#define FTM_CnSC_MSA_MASK                        (0x01UL << FTM_CnSC_MSA_SHIFT)                      /*!< FTM0_CnSC: MSA Mask                     */
#define FTM_CnSC_MSA_SHIFT                       4                                                   /*!< FTM0_CnSC: MSA Position                 */
#define FTM_CnSC_MSB_MASK                        (0x01UL << FTM_CnSC_MSB_SHIFT)                      /*!< FTM0_CnSC: MSB Mask                     */
#define FTM_CnSC_MSB_SHIFT                       5                                                   /*!< FTM0_CnSC: MSB Position                 */
#define FTM_CnSC_CHIE_MASK                       (0x01UL << FTM_CnSC_CHIE_SHIFT)                     /*!< FTM0_CnSC: CHIE Mask                    */
#define FTM_CnSC_CHIE_SHIFT                      6                                                   /*!< FTM0_CnSC: CHIE Position                */
#define FTM_CnSC_CHF_MASK                        (0x01UL << FTM_CnSC_CHF_SHIFT)                      /*!< FTM0_CnSC: CHF Mask                     */
#define FTM_CnSC_CHF_SHIFT                       7                                                   /*!< FTM0_CnSC: CHF Position                 */

/* ------- FTM0_CnV                                 ------ */
#define FTM_CnV_VAL_MASK                         (0xFFFFUL << FTM_CnV_VAL_SHIFT)                     /*!< FTM0_CnV: VAL Mask                      */
#define FTM_CnV_VAL_SHIFT                        0                                                   /*!< FTM0_CnV: VAL Position                  */
#define FTM_CnV_VAL(x)                           (((x)<<FTM_CnV_VAL_SHIFT)&FTM_CnV_VAL_MASK)         /*!< FTM0_CnV                                */

/* -------------------------------------------------------------------------------- */
/* -----------     'FTM0' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define FTM0_SC                        (FTM0->SC)
#define FTM0_CNT                       (FTM0->CNT)
#define FTM0_MOD                       (FTM0->MOD)
#define FTM0_C0SC                      (FTM0->CONTROLS[0].CnSC)
#define FTM0_C0V                       (FTM0->CONTROLS[0].CnV)
#define FTM0_C1SC                      (FTM0->CONTROLS[1].CnSC)
#define FTM0_C1V                       (FTM0->CONTROLS[1].CnV)

/* ================================================================================ */
/* ================           FTM1 (derived from FTM0)             ================ */
/* ================================================================================ */

/**
 * @brief FlexTimer Module (2 channels)
 */
typedef FTM0_Type FTM1_Type;  /*!< FTM1 Structure                                              */


/* -------------------------------------------------------------------------------- */
/* -----------     'FTM1' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define FTM1_SC                        (FTM1->SC)
#define FTM1_CNT                       (FTM1->CNT)
#define FTM1_MOD                       (FTM1->MOD)
#define FTM1_C0SC                      (FTM1->CONTROLS[0].CnSC)
#define FTM1_C0V                       (FTM1->CONTROLS[0].CnV)
#define FTM1_C1SC                      (FTM1->CONTROLS[1].CnSC)
#define FTM1_C1V                       (FTM1->CONTROLS[1].CnV)

/* ================================================================================ */
/* ================           FTM2 (file:FTM2_6CH_MKE)             ================ */
/* ================================================================================ */

/**
 * @brief FlexTimer Module (6 channels)
 */
typedef struct {                                /*!<       FTM2 Structure                                               */
   __IO uint32_t  SC;                           /*!< 0000: Status and Control                                           */
   __IO uint32_t  CNT;                          /*!< 0004: Counter                                                      */
   __IO uint32_t  MOD;                          /*!< 0008: Modulo                                                       */
   struct { /* (cluster) */                     /*!< 000C: (size=0x0030, 48)                                            */
      __IO uint32_t  CnSC;                      /*!< 000C: Channel (n) Status and Control                               */
      __IO uint32_t  CnV;                       /*!< 0010: Channel (n) Value                                            */
   } CONTROLS[6];
   __I  uint32_t  RESERVED0[4];                 /*!< 003C:                                                              */
   __IO uint32_t  CNTIN;                        /*!< 004C: Counter Initial Value                                        */
   __I  uint32_t  STATUS;                       /*!< 0050: Capture and Compare Status                                   */
   __IO uint32_t  MODE;                         /*!< 0054: Features Mode Selection                                      */
   __IO uint32_t  SYNC;                         /*!< 0058: Synchronization                                              */
   __IO uint32_t  OUTINIT;                      /*!< 005C: Initial State for Channels Output                            */
   __IO uint32_t  OUTMASK;                      /*!< 0060: Output Mask                                                  */
   __IO uint32_t  COMBINE;                      /*!< 0064: Function for Linked Channels                                 */
   __IO uint32_t  DEADTIME;                     /*!< 0068: Deadtime Insertion Control                                   */
   __IO uint32_t  EXTTRIG;                      /*!< 006C: FTM External Trigger                                         */
   __IO uint32_t  POL;                          /*!< 0070: Channels Polarity                                            */
   __IO uint32_t  FMS;                          /*!< 0074: Fault Mode Status                                            */
   __IO uint32_t  FILTER;                       /*!< 0078: Input Capture Filter Control                                 */
   __IO uint32_t  FLTCTRL;                      /*!< 007C: Fault Control                                                */
   __I  uint32_t  RESERVED1;                    /*!< 0080:                                                              */
   __IO uint32_t  CONF;                         /*!< 0084: Configuration                                                */
   __IO uint32_t  FLTPOL;                       /*!< 0088: FTM Fault Input Polarity                                     */
   __IO uint32_t  SYNCONF;                      /*!< 008C: Synchronization Configuration                                */
   __IO uint32_t  INVCTRL;                      /*!< 0090: FTM Inverting Control                                        */
   __IO uint32_t  SWOCTRL;                      /*!< 0094: FTM Software Output Control                                  */
   __IO uint32_t  PWMLOAD;                      /*!< 0098: FTM PWM Load                                                 */
} FTM2_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'FTM2' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- FTM2_SC                                  ------ */
#define FTM_SC_PS_MASK                           (0x07UL << FTM_SC_PS_SHIFT)                         /*!< FTM0_SC: PS Mask                        */
#define FTM_SC_PS_SHIFT                          0                                                   /*!< FTM0_SC: PS Position                    */
#define FTM_SC_PS(x)                             (((x)<<FTM_SC_PS_SHIFT)&FTM_SC_PS_MASK)             /*!< FTM0_SC                                 */
#define FTM_SC_CLKS_MASK                         (0x03UL << FTM_SC_CLKS_SHIFT)                       /*!< FTM0_SC: CLKS Mask                      */
#define FTM_SC_CLKS_SHIFT                        3                                                   /*!< FTM0_SC: CLKS Position                  */
#define FTM_SC_CLKS(x)                           (((x)<<FTM_SC_CLKS_SHIFT)&FTM_SC_CLKS_MASK)         /*!< FTM0_SC                                 */
#define FTM_SC_CPWMS_MASK                        (0x01UL << FTM_SC_CPWMS_SHIFT)                      /*!< FTM0_SC: CPWMS Mask                     */
#define FTM_SC_CPWMS_SHIFT                       5                                                   /*!< FTM0_SC: CPWMS Position                 */
#define FTM_SC_TOIE_MASK                         (0x01UL << FTM_SC_TOIE_SHIFT)                       /*!< FTM0_SC: TOIE Mask                      */
#define FTM_SC_TOIE_SHIFT                        6                                                   /*!< FTM0_SC: TOIE Position                  */
#define FTM_SC_TOF_MASK                          (0x01UL << FTM_SC_TOF_SHIFT)                        /*!< FTM0_SC: TOF Mask                       */
#define FTM_SC_TOF_SHIFT                         7                                                   /*!< FTM0_SC: TOF Position                   */

/* ------- FTM2_CNT                                 ------ */
#define FTM_CNT_COUNT_MASK                       (0xFFFFUL << FTM_CNT_COUNT_SHIFT)                   /*!< FTM0_CNT: COUNT Mask                    */
#define FTM_CNT_COUNT_SHIFT                      0                                                   /*!< FTM0_CNT: COUNT Position                */
#define FTM_CNT_COUNT(x)                         (((x)<<FTM_CNT_COUNT_SHIFT)&FTM_CNT_COUNT_MASK)     /*!< FTM0_CNT                                */

/* ------- FTM2_MOD                                 ------ */
#define FTM_MOD_MOD_MASK                         (0xFFFFUL << FTM_MOD_MOD_SHIFT)                     /*!< FTM0_MOD: MOD Mask                      */
#define FTM_MOD_MOD_SHIFT                        0                                                   /*!< FTM0_MOD: MOD Position                  */
#define FTM_MOD_MOD(x)                           (((x)<<FTM_MOD_MOD_SHIFT)&FTM_MOD_MOD_MASK)         /*!< FTM0_MOD                                */

/* ------- FTM2_CnSC                                ------ */
#define FTM_CnSC_ELSA_MASK                       (0x01UL << FTM_CnSC_ELSA_SHIFT)                     /*!< FTM0_CnSC: ELSA Mask                    */
#define FTM_CnSC_ELSA_SHIFT                      2                                                   /*!< FTM0_CnSC: ELSA Position                */
#define FTM_CnSC_ELSB_MASK                       (0x01UL << FTM_CnSC_ELSB_SHIFT)                     /*!< FTM0_CnSC: ELSB Mask                    */
#define FTM_CnSC_ELSB_SHIFT                      3                                                   /*!< FTM0_CnSC: ELSB Position                */
#define FTM_CnSC_MSA_MASK                        (0x01UL << FTM_CnSC_MSA_SHIFT)                      /*!< FTM0_CnSC: MSA Mask                     */
#define FTM_CnSC_MSA_SHIFT                       4                                                   /*!< FTM0_CnSC: MSA Position                 */
#define FTM_CnSC_MSB_MASK                        (0x01UL << FTM_CnSC_MSB_SHIFT)                      /*!< FTM0_CnSC: MSB Mask                     */
#define FTM_CnSC_MSB_SHIFT                       5                                                   /*!< FTM0_CnSC: MSB Position                 */
#define FTM_CnSC_CHIE_MASK                       (0x01UL << FTM_CnSC_CHIE_SHIFT)                     /*!< FTM0_CnSC: CHIE Mask                    */
#define FTM_CnSC_CHIE_SHIFT                      6                                                   /*!< FTM0_CnSC: CHIE Position                */
#define FTM_CnSC_CHF_MASK                        (0x01UL << FTM_CnSC_CHF_SHIFT)                      /*!< FTM0_CnSC: CHF Mask                     */
#define FTM_CnSC_CHF_SHIFT                       7                                                   /*!< FTM0_CnSC: CHF Position                 */

/* ------- FTM2_CnV                                 ------ */
#define FTM_CnV_VAL_MASK                         (0xFFFFUL << FTM_CnV_VAL_SHIFT)                     /*!< FTM0_CnV: VAL Mask                      */
#define FTM_CnV_VAL_SHIFT                        0                                                   /*!< FTM0_CnV: VAL Position                  */
#define FTM_CnV_VAL(x)                           (((x)<<FTM_CnV_VAL_SHIFT)&FTM_CnV_VAL_MASK)         /*!< FTM0_CnV                                */

/* ------- FTM2_CNTIN                               ------ */
#define FTM_CNTIN_INIT_MASK                      (0xFFFFUL << FTM_CNTIN_INIT_SHIFT)                  /*!< FTM0_CNTIN: INIT Mask                   */
#define FTM_CNTIN_INIT_SHIFT                     0                                                   /*!< FTM0_CNTIN: INIT Position               */
#define FTM_CNTIN_INIT(x)                        (((x)<<FTM_CNTIN_INIT_SHIFT)&FTM_CNTIN_INIT_MASK)   /*!< FTM0_CNTIN                              */

/* ------- FTM2_STATUS                              ------ */
#define FTM_STATUS_CH0F_MASK                     (0x01UL << FTM_STATUS_CH0F_SHIFT)                   /*!< FTM0_STATUS: CH0F Mask                  */
#define FTM_STATUS_CH0F_SHIFT                    0                                                   /*!< FTM0_STATUS: CH0F Position              */
#define FTM_STATUS_CH1F_MASK                     (0x01UL << FTM_STATUS_CH1F_SHIFT)                   /*!< FTM0_STATUS: CH1F Mask                  */
#define FTM_STATUS_CH1F_SHIFT                    1                                                   /*!< FTM0_STATUS: CH1F Position              */
#define FTM_STATUS_CH2F_MASK                     (0x01UL << FTM_STATUS_CH2F_SHIFT)                   /*!< FTM0_STATUS: CH2F Mask                  */
#define FTM_STATUS_CH2F_SHIFT                    2                                                   /*!< FTM0_STATUS: CH2F Position              */
#define FTM_STATUS_CH3F_MASK                     (0x01UL << FTM_STATUS_CH3F_SHIFT)                   /*!< FTM0_STATUS: CH3F Mask                  */
#define FTM_STATUS_CH3F_SHIFT                    3                                                   /*!< FTM0_STATUS: CH3F Position              */
#define FTM_STATUS_CH4F_MASK                     (0x01UL << FTM_STATUS_CH4F_SHIFT)                   /*!< FTM0_STATUS: CH4F Mask                  */
#define FTM_STATUS_CH4F_SHIFT                    4                                                   /*!< FTM0_STATUS: CH4F Position              */
#define FTM_STATUS_CH5F_MASK                     (0x01UL << FTM_STATUS_CH5F_SHIFT)                   /*!< FTM0_STATUS: CH5F Mask                  */
#define FTM_STATUS_CH5F_SHIFT                    5                                                   /*!< FTM0_STATUS: CH5F Position              */
#define FTM_STATUS_CH6F_MASK                     (0x01UL << FTM_STATUS_CH6F_SHIFT)                   /*!< FTM0_STATUS: CH6F Mask                  */
#define FTM_STATUS_CH6F_SHIFT                    6                                                   /*!< FTM0_STATUS: CH6F Position              */
#define FTM_STATUS_CH7F_MASK                     (0x01UL << FTM_STATUS_CH7F_SHIFT)                   /*!< FTM0_STATUS: CH7F Mask                  */
#define FTM_STATUS_CH7F_SHIFT                    7                                                   /*!< FTM0_STATUS: CH7F Position              */

/* ------- FTM2_MODE                                ------ */
#define FTM_MODE_FTMEN_MASK                      (0x01UL << FTM_MODE_FTMEN_SHIFT)                    /*!< FTM0_MODE: FTMEN Mask                   */
#define FTM_MODE_FTMEN_SHIFT                     0                                                   /*!< FTM0_MODE: FTMEN Position               */
#define FTM_MODE_INIT_MASK                       (0x01UL << FTM_MODE_INIT_SHIFT)                     /*!< FTM0_MODE: INIT Mask                    */
#define FTM_MODE_INIT_SHIFT                      1                                                   /*!< FTM0_MODE: INIT Position                */
#define FTM_MODE_WPDIS_MASK                      (0x01UL << FTM_MODE_WPDIS_SHIFT)                    /*!< FTM0_MODE: WPDIS Mask                   */
#define FTM_MODE_WPDIS_SHIFT                     2                                                   /*!< FTM0_MODE: WPDIS Position               */
#define FTM_MODE_PWMSYNC_MASK                    (0x01UL << FTM_MODE_PWMSYNC_SHIFT)                  /*!< FTM0_MODE: PWMSYNC Mask                 */
#define FTM_MODE_PWMSYNC_SHIFT                   3                                                   /*!< FTM0_MODE: PWMSYNC Position             */
#define FTM_MODE_CAPTEST_MASK                    (0x01UL << FTM_MODE_CAPTEST_SHIFT)                  /*!< FTM0_MODE: CAPTEST Mask                 */
#define FTM_MODE_CAPTEST_SHIFT                   4                                                   /*!< FTM0_MODE: CAPTEST Position             */
#define FTM_MODE_FAULTM_MASK                     (0x03UL << FTM_MODE_FAULTM_SHIFT)                   /*!< FTM0_MODE: FAULTM Mask                  */
#define FTM_MODE_FAULTM_SHIFT                    5                                                   /*!< FTM0_MODE: FAULTM Position              */
#define FTM_MODE_FAULTM(x)                       (((x)<<FTM_MODE_FAULTM_SHIFT)&FTM_MODE_FAULTM_MASK) /*!< FTM0_MODE                               */
#define FTM_MODE_FAULTIE_MASK                    (0x01UL << FTM_MODE_FAULTIE_SHIFT)                  /*!< FTM0_MODE: FAULTIE Mask                 */
#define FTM_MODE_FAULTIE_SHIFT                   7                                                   /*!< FTM0_MODE: FAULTIE Position             */

/* ------- FTM2_SYNC                                ------ */
#define FTM_SYNC_CNTMIN_MASK                     (0x01UL << FTM_SYNC_CNTMIN_SHIFT)                   /*!< FTM0_SYNC: CNTMIN Mask                  */
#define FTM_SYNC_CNTMIN_SHIFT                    0                                                   /*!< FTM0_SYNC: CNTMIN Position              */
#define FTM_SYNC_CNTMAX_MASK                     (0x01UL << FTM_SYNC_CNTMAX_SHIFT)                   /*!< FTM0_SYNC: CNTMAX Mask                  */
#define FTM_SYNC_CNTMAX_SHIFT                    1                                                   /*!< FTM0_SYNC: CNTMAX Position              */
#define FTM_SYNC_REINIT_MASK                     (0x01UL << FTM_SYNC_REINIT_SHIFT)                   /*!< FTM0_SYNC: REINIT Mask                  */
#define FTM_SYNC_REINIT_SHIFT                    2                                                   /*!< FTM0_SYNC: REINIT Position              */
#define FTM_SYNC_SYNCHOM_MASK                    (0x01UL << FTM_SYNC_SYNCHOM_SHIFT)                  /*!< FTM0_SYNC: SYNCHOM Mask                 */
#define FTM_SYNC_SYNCHOM_SHIFT                   3                                                   /*!< FTM0_SYNC: SYNCHOM Position             */
#define FTM_SYNC_TRIG0_MASK                      (0x01UL << FTM_SYNC_TRIG0_SHIFT)                    /*!< FTM0_SYNC: TRIG0 Mask                   */
#define FTM_SYNC_TRIG0_SHIFT                     4                                                   /*!< FTM0_SYNC: TRIG0 Position               */
#define FTM_SYNC_TRIG1_MASK                      (0x01UL << FTM_SYNC_TRIG1_SHIFT)                    /*!< FTM0_SYNC: TRIG1 Mask                   */
#define FTM_SYNC_TRIG1_SHIFT                     5                                                   /*!< FTM0_SYNC: TRIG1 Position               */
#define FTM_SYNC_TRIG2_MASK                      (0x01UL << FTM_SYNC_TRIG2_SHIFT)                    /*!< FTM0_SYNC: TRIG2 Mask                   */
#define FTM_SYNC_TRIG2_SHIFT                     6                                                   /*!< FTM0_SYNC: TRIG2 Position               */
#define FTM_SYNC_SWSYNC_MASK                     (0x01UL << FTM_SYNC_SWSYNC_SHIFT)                   /*!< FTM0_SYNC: SWSYNC Mask                  */
#define FTM_SYNC_SWSYNC_SHIFT                    7                                                   /*!< FTM0_SYNC: SWSYNC Position              */

/* ------- FTM2_OUTINIT                             ------ */
#define FTM_OUTINIT_CH0OI_MASK                   (0x01UL << FTM_OUTINIT_CH0OI_SHIFT)                 /*!< FTM0_OUTINIT: CH0OI Mask                */
#define FTM_OUTINIT_CH0OI_SHIFT                  0                                                   /*!< FTM0_OUTINIT: CH0OI Position            */
#define FTM_OUTINIT_CH1OI_MASK                   (0x01UL << FTM_OUTINIT_CH1OI_SHIFT)                 /*!< FTM0_OUTINIT: CH1OI Mask                */
#define FTM_OUTINIT_CH1OI_SHIFT                  1                                                   /*!< FTM0_OUTINIT: CH1OI Position            */
#define FTM_OUTINIT_CH2OI_MASK                   (0x01UL << FTM_OUTINIT_CH2OI_SHIFT)                 /*!< FTM0_OUTINIT: CH2OI Mask                */
#define FTM_OUTINIT_CH2OI_SHIFT                  2                                                   /*!< FTM0_OUTINIT: CH2OI Position            */
#define FTM_OUTINIT_CH3OI_MASK                   (0x01UL << FTM_OUTINIT_CH3OI_SHIFT)                 /*!< FTM0_OUTINIT: CH3OI Mask                */
#define FTM_OUTINIT_CH3OI_SHIFT                  3                                                   /*!< FTM0_OUTINIT: CH3OI Position            */
#define FTM_OUTINIT_CH4OI_MASK                   (0x01UL << FTM_OUTINIT_CH4OI_SHIFT)                 /*!< FTM0_OUTINIT: CH4OI Mask                */
#define FTM_OUTINIT_CH4OI_SHIFT                  4                                                   /*!< FTM0_OUTINIT: CH4OI Position            */
#define FTM_OUTINIT_CH5OI_MASK                   (0x01UL << FTM_OUTINIT_CH5OI_SHIFT)                 /*!< FTM0_OUTINIT: CH5OI Mask                */
#define FTM_OUTINIT_CH5OI_SHIFT                  5                                                   /*!< FTM0_OUTINIT: CH5OI Position            */
#define FTM_OUTINIT_CH6OI_MASK                   (0x01UL << FTM_OUTINIT_CH6OI_SHIFT)                 /*!< FTM0_OUTINIT: CH6OI Mask                */
#define FTM_OUTINIT_CH6OI_SHIFT                  6                                                   /*!< FTM0_OUTINIT: CH6OI Position            */
#define FTM_OUTINIT_CH7OI_MASK                   (0x01UL << FTM_OUTINIT_CH7OI_SHIFT)                 /*!< FTM0_OUTINIT: CH7OI Mask                */
#define FTM_OUTINIT_CH7OI_SHIFT                  7                                                   /*!< FTM0_OUTINIT: CH7OI Position            */

/* ------- FTM2_OUTMASK                             ------ */
#define FTM_OUTMASK_CH0OM_MASK                   (0x01UL << FTM_OUTMASK_CH0OM_SHIFT)                 /*!< FTM0_OUTMASK: CH0OM Mask                */
#define FTM_OUTMASK_CH0OM_SHIFT                  0                                                   /*!< FTM0_OUTMASK: CH0OM Position            */
#define FTM_OUTMASK_CH1OM_MASK                   (0x01UL << FTM_OUTMASK_CH1OM_SHIFT)                 /*!< FTM0_OUTMASK: CH1OM Mask                */
#define FTM_OUTMASK_CH1OM_SHIFT                  1                                                   /*!< FTM0_OUTMASK: CH1OM Position            */
#define FTM_OUTMASK_CH2OM_MASK                   (0x01UL << FTM_OUTMASK_CH2OM_SHIFT)                 /*!< FTM0_OUTMASK: CH2OM Mask                */
#define FTM_OUTMASK_CH2OM_SHIFT                  2                                                   /*!< FTM0_OUTMASK: CH2OM Position            */
#define FTM_OUTMASK_CH3OM_MASK                   (0x01UL << FTM_OUTMASK_CH3OM_SHIFT)                 /*!< FTM0_OUTMASK: CH3OM Mask                */
#define FTM_OUTMASK_CH3OM_SHIFT                  3                                                   /*!< FTM0_OUTMASK: CH3OM Position            */
#define FTM_OUTMASK_CH4OM_MASK                   (0x01UL << FTM_OUTMASK_CH4OM_SHIFT)                 /*!< FTM0_OUTMASK: CH4OM Mask                */
#define FTM_OUTMASK_CH4OM_SHIFT                  4                                                   /*!< FTM0_OUTMASK: CH4OM Position            */
#define FTM_OUTMASK_CH5OM_MASK                   (0x01UL << FTM_OUTMASK_CH5OM_SHIFT)                 /*!< FTM0_OUTMASK: CH5OM Mask                */
#define FTM_OUTMASK_CH5OM_SHIFT                  5                                                   /*!< FTM0_OUTMASK: CH5OM Position            */
#define FTM_OUTMASK_CH6OM_MASK                   (0x01UL << FTM_OUTMASK_CH6OM_SHIFT)                 /*!< FTM0_OUTMASK: CH6OM Mask                */
#define FTM_OUTMASK_CH6OM_SHIFT                  6                                                   /*!< FTM0_OUTMASK: CH6OM Position            */
#define FTM_OUTMASK_CH7OM_MASK                   (0x01UL << FTM_OUTMASK_CH7OM_SHIFT)                 /*!< FTM0_OUTMASK: CH7OM Mask                */
#define FTM_OUTMASK_CH7OM_SHIFT                  7                                                   /*!< FTM0_OUTMASK: CH7OM Position            */

/* ------- FTM2_COMBINE                             ------ */
#define FTM_COMBINE_COMBINE0_MASK                (0x01UL << FTM_COMBINE_COMBINE0_SHIFT)              /*!< FTM0_COMBINE: COMBINE0 Mask             */
#define FTM_COMBINE_COMBINE0_SHIFT               0                                                   /*!< FTM0_COMBINE: COMBINE0 Position         */
#define FTM_COMBINE_COMP0_MASK                   (0x01UL << FTM_COMBINE_COMP0_SHIFT)                 /*!< FTM0_COMBINE: COMP0 Mask                */
#define FTM_COMBINE_COMP0_SHIFT                  1                                                   /*!< FTM0_COMBINE: COMP0 Position            */
#define FTM_COMBINE_DECAPEN0_MASK                (0x01UL << FTM_COMBINE_DECAPEN0_SHIFT)              /*!< FTM0_COMBINE: DECAPEN0 Mask             */
#define FTM_COMBINE_DECAPEN0_SHIFT               2                                                   /*!< FTM0_COMBINE: DECAPEN0 Position         */
#define FTM_COMBINE_DECAP0_MASK                  (0x01UL << FTM_COMBINE_DECAP0_SHIFT)                /*!< FTM0_COMBINE: DECAP0 Mask               */
#define FTM_COMBINE_DECAP0_SHIFT                 3                                                   /*!< FTM0_COMBINE: DECAP0 Position           */
#define FTM_COMBINE_DTEN0_MASK                   (0x01UL << FTM_COMBINE_DTEN0_SHIFT)                 /*!< FTM0_COMBINE: DTEN0 Mask                */
#define FTM_COMBINE_DTEN0_SHIFT                  4                                                   /*!< FTM0_COMBINE: DTEN0 Position            */
#define FTM_COMBINE_SYNCEN0_MASK                 (0x01UL << FTM_COMBINE_SYNCEN0_SHIFT)               /*!< FTM0_COMBINE: SYNCEN0 Mask              */
#define FTM_COMBINE_SYNCEN0_SHIFT                5                                                   /*!< FTM0_COMBINE: SYNCEN0 Position          */
#define FTM_COMBINE_FAULTEN0_MASK                (0x01UL << FTM_COMBINE_FAULTEN0_SHIFT)              /*!< FTM0_COMBINE: FAULTEN0 Mask             */
#define FTM_COMBINE_FAULTEN0_SHIFT               6                                                   /*!< FTM0_COMBINE: FAULTEN0 Position         */
#define FTM_COMBINE_COMBINE1_MASK                (0x01UL << FTM_COMBINE_COMBINE1_SHIFT)              /*!< FTM0_COMBINE: COMBINE1 Mask             */
#define FTM_COMBINE_COMBINE1_SHIFT               8                                                   /*!< FTM0_COMBINE: COMBINE1 Position         */
#define FTM_COMBINE_COMP1_MASK                   (0x01UL << FTM_COMBINE_COMP1_SHIFT)                 /*!< FTM0_COMBINE: COMP1 Mask                */
#define FTM_COMBINE_COMP1_SHIFT                  9                                                   /*!< FTM0_COMBINE: COMP1 Position            */
#define FTM_COMBINE_DECAPEN1_MASK                (0x01UL << FTM_COMBINE_DECAPEN1_SHIFT)              /*!< FTM0_COMBINE: DECAPEN1 Mask             */
#define FTM_COMBINE_DECAPEN1_SHIFT               10                                                  /*!< FTM0_COMBINE: DECAPEN1 Position         */
#define FTM_COMBINE_DECAP1_MASK                  (0x01UL << FTM_COMBINE_DECAP1_SHIFT)                /*!< FTM0_COMBINE: DECAP1 Mask               */
#define FTM_COMBINE_DECAP1_SHIFT                 11                                                  /*!< FTM0_COMBINE: DECAP1 Position           */
#define FTM_COMBINE_DTEN1_MASK                   (0x01UL << FTM_COMBINE_DTEN1_SHIFT)                 /*!< FTM0_COMBINE: DTEN1 Mask                */
#define FTM_COMBINE_DTEN1_SHIFT                  12                                                  /*!< FTM0_COMBINE: DTEN1 Position            */
#define FTM_COMBINE_SYNCEN1_MASK                 (0x01UL << FTM_COMBINE_SYNCEN1_SHIFT)               /*!< FTM0_COMBINE: SYNCEN1 Mask              */
#define FTM_COMBINE_SYNCEN1_SHIFT                13                                                  /*!< FTM0_COMBINE: SYNCEN1 Position          */
#define FTM_COMBINE_FAULTEN1_MASK                (0x01UL << FTM_COMBINE_FAULTEN1_SHIFT)              /*!< FTM0_COMBINE: FAULTEN1 Mask             */
#define FTM_COMBINE_FAULTEN1_SHIFT               14                                                  /*!< FTM0_COMBINE: FAULTEN1 Position         */
#define FTM_COMBINE_COMBINE2_MASK                (0x01UL << FTM_COMBINE_COMBINE2_SHIFT)              /*!< FTM0_COMBINE: COMBINE2 Mask             */
#define FTM_COMBINE_COMBINE2_SHIFT               16                                                  /*!< FTM0_COMBINE: COMBINE2 Position         */
#define FTM_COMBINE_COMP2_MASK                   (0x01UL << FTM_COMBINE_COMP2_SHIFT)                 /*!< FTM0_COMBINE: COMP2 Mask                */
#define FTM_COMBINE_COMP2_SHIFT                  17                                                  /*!< FTM0_COMBINE: COMP2 Position            */
#define FTM_COMBINE_DECAPEN2_MASK                (0x01UL << FTM_COMBINE_DECAPEN2_SHIFT)              /*!< FTM0_COMBINE: DECAPEN2 Mask             */
#define FTM_COMBINE_DECAPEN2_SHIFT               18                                                  /*!< FTM0_COMBINE: DECAPEN2 Position         */
#define FTM_COMBINE_DECAP2_MASK                  (0x01UL << FTM_COMBINE_DECAP2_SHIFT)                /*!< FTM0_COMBINE: DECAP2 Mask               */
#define FTM_COMBINE_DECAP2_SHIFT                 19                                                  /*!< FTM0_COMBINE: DECAP2 Position           */
#define FTM_COMBINE_DTEN2_MASK                   (0x01UL << FTM_COMBINE_DTEN2_SHIFT)                 /*!< FTM0_COMBINE: DTEN2 Mask                */
#define FTM_COMBINE_DTEN2_SHIFT                  20                                                  /*!< FTM0_COMBINE: DTEN2 Position            */
#define FTM_COMBINE_SYNCEN2_MASK                 (0x01UL << FTM_COMBINE_SYNCEN2_SHIFT)               /*!< FTM0_COMBINE: SYNCEN2 Mask              */
#define FTM_COMBINE_SYNCEN2_SHIFT                21                                                  /*!< FTM0_COMBINE: SYNCEN2 Position          */
#define FTM_COMBINE_FAULTEN2_MASK                (0x01UL << FTM_COMBINE_FAULTEN2_SHIFT)              /*!< FTM0_COMBINE: FAULTEN2 Mask             */
#define FTM_COMBINE_FAULTEN2_SHIFT               22                                                  /*!< FTM0_COMBINE: FAULTEN2 Position         */
#define FTM_COMBINE_COMBINE3_MASK                (0x01UL << FTM_COMBINE_COMBINE3_SHIFT)              /*!< FTM0_COMBINE: COMBINE3 Mask             */
#define FTM_COMBINE_COMBINE3_SHIFT               24                                                  /*!< FTM0_COMBINE: COMBINE3 Position         */
#define FTM_COMBINE_COMP3_MASK                   (0x01UL << FTM_COMBINE_COMP3_SHIFT)                 /*!< FTM0_COMBINE: COMP3 Mask                */
#define FTM_COMBINE_COMP3_SHIFT                  25                                                  /*!< FTM0_COMBINE: COMP3 Position            */
#define FTM_COMBINE_DECAPEN3_MASK                (0x01UL << FTM_COMBINE_DECAPEN3_SHIFT)              /*!< FTM0_COMBINE: DECAPEN3 Mask             */
#define FTM_COMBINE_DECAPEN3_SHIFT               26                                                  /*!< FTM0_COMBINE: DECAPEN3 Position         */
#define FTM_COMBINE_DECAP3_MASK                  (0x01UL << FTM_COMBINE_DECAP3_SHIFT)                /*!< FTM0_COMBINE: DECAP3 Mask               */
#define FTM_COMBINE_DECAP3_SHIFT                 27                                                  /*!< FTM0_COMBINE: DECAP3 Position           */
#define FTM_COMBINE_DTEN3_MASK                   (0x01UL << FTM_COMBINE_DTEN3_SHIFT)                 /*!< FTM0_COMBINE: DTEN3 Mask                */
#define FTM_COMBINE_DTEN3_SHIFT                  28                                                  /*!< FTM0_COMBINE: DTEN3 Position            */
#define FTM_COMBINE_SYNCEN3_MASK                 (0x01UL << FTM_COMBINE_SYNCEN3_SHIFT)               /*!< FTM0_COMBINE: SYNCEN3 Mask              */
#define FTM_COMBINE_SYNCEN3_SHIFT                29                                                  /*!< FTM0_COMBINE: SYNCEN3 Position          */
#define FTM_COMBINE_FAULTEN3_MASK                (0x01UL << FTM_COMBINE_FAULTEN3_SHIFT)              /*!< FTM0_COMBINE: FAULTEN3 Mask             */
#define FTM_COMBINE_FAULTEN3_SHIFT               30                                                  /*!< FTM0_COMBINE: FAULTEN3 Position         */

/* ------- FTM2_DEADTIME                            ------ */
#define FTM_DEADTIME_DTVAL_MASK                  (0x3FUL << FTM_DEADTIME_DTVAL_SHIFT)                /*!< FTM0_DEADTIME: DTVAL Mask               */
#define FTM_DEADTIME_DTVAL_SHIFT                 0                                                   /*!< FTM0_DEADTIME: DTVAL Position           */
#define FTM_DEADTIME_DTVAL(x)                    (((x)<<FTM_DEADTIME_DTVAL_SHIFT)&FTM_DEADTIME_DTVAL_MASK) /*!< FTM0_DEADTIME                           */
#define FTM_DEADTIME_DTPS_MASK                   (0x03UL << FTM_DEADTIME_DTPS_SHIFT)                 /*!< FTM0_DEADTIME: DTPS Mask                */
#define FTM_DEADTIME_DTPS_SHIFT                  6                                                   /*!< FTM0_DEADTIME: DTPS Position            */
#define FTM_DEADTIME_DTPS(x)                     (((x)<<FTM_DEADTIME_DTPS_SHIFT)&FTM_DEADTIME_DTPS_MASK) /*!< FTM0_DEADTIME                           */

/* ------- FTM2_EXTTRIG                             ------ */
#define FTM_EXTTRIG_CH2TRIG_MASK                 (0x01UL << FTM_EXTTRIG_CH2TRIG_SHIFT)               /*!< FTM0_EXTTRIG: CH2TRIG Mask              */
#define FTM_EXTTRIG_CH2TRIG_SHIFT                0                                                   /*!< FTM0_EXTTRIG: CH2TRIG Position          */
#define FTM_EXTTRIG_CH3TRIG_MASK                 (0x01UL << FTM_EXTTRIG_CH3TRIG_SHIFT)               /*!< FTM0_EXTTRIG: CH3TRIG Mask              */
#define FTM_EXTTRIG_CH3TRIG_SHIFT                1                                                   /*!< FTM0_EXTTRIG: CH3TRIG Position          */
#define FTM_EXTTRIG_CH4TRIG_MASK                 (0x01UL << FTM_EXTTRIG_CH4TRIG_SHIFT)               /*!< FTM0_EXTTRIG: CH4TRIG Mask              */
#define FTM_EXTTRIG_CH4TRIG_SHIFT                2                                                   /*!< FTM0_EXTTRIG: CH4TRIG Position          */
#define FTM_EXTTRIG_CH5TRIG_MASK                 (0x01UL << FTM_EXTTRIG_CH5TRIG_SHIFT)               /*!< FTM0_EXTTRIG: CH5TRIG Mask              */
#define FTM_EXTTRIG_CH5TRIG_SHIFT                3                                                   /*!< FTM0_EXTTRIG: CH5TRIG Position          */
#define FTM_EXTTRIG_CH0TRIG_MASK                 (0x01UL << FTM_EXTTRIG_CH0TRIG_SHIFT)               /*!< FTM0_EXTTRIG: CH0TRIG Mask              */
#define FTM_EXTTRIG_CH0TRIG_SHIFT                4                                                   /*!< FTM0_EXTTRIG: CH0TRIG Position          */
#define FTM_EXTTRIG_CH1TRIG_MASK                 (0x01UL << FTM_EXTTRIG_CH1TRIG_SHIFT)               /*!< FTM0_EXTTRIG: CH1TRIG Mask              */
#define FTM_EXTTRIG_CH1TRIG_SHIFT                5                                                   /*!< FTM0_EXTTRIG: CH1TRIG Position          */
#define FTM_EXTTRIG_INITTRIGEN_MASK              (0x01UL << FTM_EXTTRIG_INITTRIGEN_SHIFT)            /*!< FTM0_EXTTRIG: INITTRIGEN Mask           */
#define FTM_EXTTRIG_INITTRIGEN_SHIFT             6                                                   /*!< FTM0_EXTTRIG: INITTRIGEN Position       */
#define FTM_EXTTRIG_TRIGF_MASK                   (0x01UL << FTM_EXTTRIG_TRIGF_SHIFT)                 /*!< FTM0_EXTTRIG: TRIGF Mask                */
#define FTM_EXTTRIG_TRIGF_SHIFT                  7                                                   /*!< FTM0_EXTTRIG: TRIGF Position            */

/* ------- FTM2_POL                                 ------ */
#define FTM_POL_POL0_MASK                        (0x01UL << FTM_POL_POL0_SHIFT)                      /*!< FTM0_POL: POL0 Mask                     */
#define FTM_POL_POL0_SHIFT                       0                                                   /*!< FTM0_POL: POL0 Position                 */
#define FTM_POL_POL1_MASK                        (0x01UL << FTM_POL_POL1_SHIFT)                      /*!< FTM0_POL: POL1 Mask                     */
#define FTM_POL_POL1_SHIFT                       1                                                   /*!< FTM0_POL: POL1 Position                 */
#define FTM_POL_POL2_MASK                        (0x01UL << FTM_POL_POL2_SHIFT)                      /*!< FTM0_POL: POL2 Mask                     */
#define FTM_POL_POL2_SHIFT                       2                                                   /*!< FTM0_POL: POL2 Position                 */
#define FTM_POL_POL3_MASK                        (0x01UL << FTM_POL_POL3_SHIFT)                      /*!< FTM0_POL: POL3 Mask                     */
#define FTM_POL_POL3_SHIFT                       3                                                   /*!< FTM0_POL: POL3 Position                 */
#define FTM_POL_POL4_MASK                        (0x01UL << FTM_POL_POL4_SHIFT)                      /*!< FTM0_POL: POL4 Mask                     */
#define FTM_POL_POL4_SHIFT                       4                                                   /*!< FTM0_POL: POL4 Position                 */
#define FTM_POL_POL5_MASK                        (0x01UL << FTM_POL_POL5_SHIFT)                      /*!< FTM0_POL: POL5 Mask                     */
#define FTM_POL_POL5_SHIFT                       5                                                   /*!< FTM0_POL: POL5 Position                 */
#define FTM_POL_POL6_MASK                        (0x01UL << FTM_POL_POL6_SHIFT)                      /*!< FTM0_POL: POL6 Mask                     */
#define FTM_POL_POL6_SHIFT                       6                                                   /*!< FTM0_POL: POL6 Position                 */
#define FTM_POL_POL7_MASK                        (0x01UL << FTM_POL_POL7_SHIFT)                      /*!< FTM0_POL: POL7 Mask                     */
#define FTM_POL_POL7_SHIFT                       7                                                   /*!< FTM0_POL: POL7 Position                 */

/* ------- FTM2_FMS                                 ------ */
#define FTM_FMS_FAULTF0_MASK                     (0x01UL << FTM_FMS_FAULTF0_SHIFT)                   /*!< FTM0_FMS: FAULTF0 Mask                  */
#define FTM_FMS_FAULTF0_SHIFT                    0                                                   /*!< FTM0_FMS: FAULTF0 Position              */
#define FTM_FMS_FAULTF1_MASK                     (0x01UL << FTM_FMS_FAULTF1_SHIFT)                   /*!< FTM0_FMS: FAULTF1 Mask                  */
#define FTM_FMS_FAULTF1_SHIFT                    1                                                   /*!< FTM0_FMS: FAULTF1 Position              */
#define FTM_FMS_FAULTF2_MASK                     (0x01UL << FTM_FMS_FAULTF2_SHIFT)                   /*!< FTM0_FMS: FAULTF2 Mask                  */
#define FTM_FMS_FAULTF2_SHIFT                    2                                                   /*!< FTM0_FMS: FAULTF2 Position              */
#define FTM_FMS_FAULTF3_MASK                     (0x01UL << FTM_FMS_FAULTF3_SHIFT)                   /*!< FTM0_FMS: FAULTF3 Mask                  */
#define FTM_FMS_FAULTF3_SHIFT                    3                                                   /*!< FTM0_FMS: FAULTF3 Position              */
#define FTM_FMS_FAULTIN_MASK                     (0x01UL << FTM_FMS_FAULTIN_SHIFT)                   /*!< FTM0_FMS: FAULTIN Mask                  */
#define FTM_FMS_FAULTIN_SHIFT                    5                                                   /*!< FTM0_FMS: FAULTIN Position              */
#define FTM_FMS_WPEN_MASK                        (0x01UL << FTM_FMS_WPEN_SHIFT)                      /*!< FTM0_FMS: WPEN Mask                     */
#define FTM_FMS_WPEN_SHIFT                       6                                                   /*!< FTM0_FMS: WPEN Position                 */
#define FTM_FMS_FAULTF_MASK                      (0x01UL << FTM_FMS_FAULTF_SHIFT)                    /*!< FTM0_FMS: FAULTF Mask                   */
#define FTM_FMS_FAULTF_SHIFT                     7                                                   /*!< FTM0_FMS: FAULTF Position               */

/* ------- FTM2_FILTER                              ------ */
#define FTM_FILTER_CH0FVAL_MASK                  (0x0FUL << FTM_FILTER_CH0FVAL_SHIFT)                /*!< FTM0_FILTER: CH0FVAL Mask               */
#define FTM_FILTER_CH0FVAL_SHIFT                 0                                                   /*!< FTM0_FILTER: CH0FVAL Position           */
#define FTM_FILTER_CH0FVAL(x)                    (((x)<<FTM_FILTER_CH0FVAL_SHIFT)&FTM_FILTER_CH0FVAL_MASK) /*!< FTM0_FILTER                             */
#define FTM_FILTER_CH1FVAL_MASK                  (0x0FUL << FTM_FILTER_CH1FVAL_SHIFT)                /*!< FTM0_FILTER: CH1FVAL Mask               */
#define FTM_FILTER_CH1FVAL_SHIFT                 4                                                   /*!< FTM0_FILTER: CH1FVAL Position           */
#define FTM_FILTER_CH1FVAL(x)                    (((x)<<FTM_FILTER_CH1FVAL_SHIFT)&FTM_FILTER_CH1FVAL_MASK) /*!< FTM0_FILTER                             */
#define FTM_FILTER_CH2FVAL_MASK                  (0x0FUL << FTM_FILTER_CH2FVAL_SHIFT)                /*!< FTM0_FILTER: CH2FVAL Mask               */
#define FTM_FILTER_CH2FVAL_SHIFT                 8                                                   /*!< FTM0_FILTER: CH2FVAL Position           */
#define FTM_FILTER_CH2FVAL(x)                    (((x)<<FTM_FILTER_CH2FVAL_SHIFT)&FTM_FILTER_CH2FVAL_MASK) /*!< FTM0_FILTER                             */
#define FTM_FILTER_CH3FVAL_MASK                  (0x0FUL << FTM_FILTER_CH3FVAL_SHIFT)                /*!< FTM0_FILTER: CH3FVAL Mask               */
#define FTM_FILTER_CH3FVAL_SHIFT                 12                                                  /*!< FTM0_FILTER: CH3FVAL Position           */
#define FTM_FILTER_CH3FVAL(x)                    (((x)<<FTM_FILTER_CH3FVAL_SHIFT)&FTM_FILTER_CH3FVAL_MASK) /*!< FTM0_FILTER                             */

/* ------- FTM2_FLTCTRL                             ------ */
#define FTM_FLTCTRL_FAULT0EN_MASK                (0x01UL << FTM_FLTCTRL_FAULT0EN_SHIFT)              /*!< FTM0_FLTCTRL: FAULT0EN Mask             */
#define FTM_FLTCTRL_FAULT0EN_SHIFT               0                                                   /*!< FTM0_FLTCTRL: FAULT0EN Position         */
#define FTM_FLTCTRL_FAULT1EN_MASK                (0x01UL << FTM_FLTCTRL_FAULT1EN_SHIFT)              /*!< FTM0_FLTCTRL: FAULT1EN Mask             */
#define FTM_FLTCTRL_FAULT1EN_SHIFT               1                                                   /*!< FTM0_FLTCTRL: FAULT1EN Position         */
#define FTM_FLTCTRL_FAULT2EN_MASK                (0x01UL << FTM_FLTCTRL_FAULT2EN_SHIFT)              /*!< FTM0_FLTCTRL: FAULT2EN Mask             */
#define FTM_FLTCTRL_FAULT2EN_SHIFT               2                                                   /*!< FTM0_FLTCTRL: FAULT2EN Position         */
#define FTM_FLTCTRL_FAULT3EN_MASK                (0x01UL << FTM_FLTCTRL_FAULT3EN_SHIFT)              /*!< FTM0_FLTCTRL: FAULT3EN Mask             */
#define FTM_FLTCTRL_FAULT3EN_SHIFT               3                                                   /*!< FTM0_FLTCTRL: FAULT3EN Position         */
#define FTM_FLTCTRL_FFLTR0EN_MASK                (0x01UL << FTM_FLTCTRL_FFLTR0EN_SHIFT)              /*!< FTM0_FLTCTRL: FFLTR0EN Mask             */
#define FTM_FLTCTRL_FFLTR0EN_SHIFT               4                                                   /*!< FTM0_FLTCTRL: FFLTR0EN Position         */
#define FTM_FLTCTRL_FFLTR1EN_MASK                (0x01UL << FTM_FLTCTRL_FFLTR1EN_SHIFT)              /*!< FTM0_FLTCTRL: FFLTR1EN Mask             */
#define FTM_FLTCTRL_FFLTR1EN_SHIFT               5                                                   /*!< FTM0_FLTCTRL: FFLTR1EN Position         */
#define FTM_FLTCTRL_FFLTR2EN_MASK                (0x01UL << FTM_FLTCTRL_FFLTR2EN_SHIFT)              /*!< FTM0_FLTCTRL: FFLTR2EN Mask             */
#define FTM_FLTCTRL_FFLTR2EN_SHIFT               6                                                   /*!< FTM0_FLTCTRL: FFLTR2EN Position         */
#define FTM_FLTCTRL_FFLTR3EN_MASK                (0x01UL << FTM_FLTCTRL_FFLTR3EN_SHIFT)              /*!< FTM0_FLTCTRL: FFLTR3EN Mask             */
#define FTM_FLTCTRL_FFLTR3EN_SHIFT               7                                                   /*!< FTM0_FLTCTRL: FFLTR3EN Position         */
#define FTM_FLTCTRL_FFVAL_MASK                   (0x0FUL << FTM_FLTCTRL_FFVAL_SHIFT)                 /*!< FTM0_FLTCTRL: FFVAL Mask                */
#define FTM_FLTCTRL_FFVAL_SHIFT                  8                                                   /*!< FTM0_FLTCTRL: FFVAL Position            */
#define FTM_FLTCTRL_FFVAL(x)                     (((x)<<FTM_FLTCTRL_FFVAL_SHIFT)&FTM_FLTCTRL_FFVAL_MASK) /*!< FTM0_FLTCTRL                            */

/* ------- FTM2_CONF                                ------ */
#define FTM_CONF_NUMTOF_MASK                     (0x1FUL << FTM_CONF_NUMTOF_SHIFT)                   /*!< FTM0_CONF: NUMTOF Mask                  */
#define FTM_CONF_NUMTOF_SHIFT                    0                                                   /*!< FTM0_CONF: NUMTOF Position              */
#define FTM_CONF_NUMTOF(x)                       (((x)<<FTM_CONF_NUMTOF_SHIFT)&FTM_CONF_NUMTOF_MASK) /*!< FTM0_CONF                               */
#define FTM_CONF_BDMMODE_MASK                    (0x03UL << FTM_CONF_BDMMODE_SHIFT)                  /*!< FTM0_CONF: BDMMODE Mask                 */
#define FTM_CONF_BDMMODE_SHIFT                   6                                                   /*!< FTM0_CONF: BDMMODE Position             */
#define FTM_CONF_BDMMODE(x)                      (((x)<<FTM_CONF_BDMMODE_SHIFT)&FTM_CONF_BDMMODE_MASK) /*!< FTM0_CONF                               */
#define FTM_CONF_GTBEEN_MASK                     (0x01UL << FTM_CONF_GTBEEN_SHIFT)                   /*!< FTM0_CONF: GTBEEN Mask                  */
#define FTM_CONF_GTBEEN_SHIFT                    9                                                   /*!< FTM0_CONF: GTBEEN Position              */
#define FTM_CONF_GTBEOUT_MASK                    (0x01UL << FTM_CONF_GTBEOUT_SHIFT)                  /*!< FTM0_CONF: GTBEOUT Mask                 */
#define FTM_CONF_GTBEOUT_SHIFT                   10                                                  /*!< FTM0_CONF: GTBEOUT Position             */

/* ------- FTM2_FLTPOL                              ------ */
#define FTM_FLTPOL_FLT0POL_MASK                  (0x01UL << FTM_FLTPOL_FLT0POL_SHIFT)                /*!< FTM0_FLTPOL: FLT0POL Mask               */
#define FTM_FLTPOL_FLT0POL_SHIFT                 0                                                   /*!< FTM0_FLTPOL: FLT0POL Position           */
#define FTM_FLTPOL_FLT1POL_MASK                  (0x01UL << FTM_FLTPOL_FLT1POL_SHIFT)                /*!< FTM0_FLTPOL: FLT1POL Mask               */
#define FTM_FLTPOL_FLT1POL_SHIFT                 1                                                   /*!< FTM0_FLTPOL: FLT1POL Position           */
#define FTM_FLTPOL_FLT2POL_MASK                  (0x01UL << FTM_FLTPOL_FLT2POL_SHIFT)                /*!< FTM0_FLTPOL: FLT2POL Mask               */
#define FTM_FLTPOL_FLT2POL_SHIFT                 2                                                   /*!< FTM0_FLTPOL: FLT2POL Position           */
#define FTM_FLTPOL_FLT3POL_MASK                  (0x01UL << FTM_FLTPOL_FLT3POL_SHIFT)                /*!< FTM0_FLTPOL: FLT3POL Mask               */
#define FTM_FLTPOL_FLT3POL_SHIFT                 3                                                   /*!< FTM0_FLTPOL: FLT3POL Position           */

/* ------- FTM2_SYNCONF                             ------ */
#define FTM_SYNCONF_HWTRIGMODE_MASK              (0x01UL << FTM_SYNCONF_HWTRIGMODE_SHIFT)            /*!< FTM0_SYNCONF: HWTRIGMODE Mask           */
#define FTM_SYNCONF_HWTRIGMODE_SHIFT             0                                                   /*!< FTM0_SYNCONF: HWTRIGMODE Position       */
#define FTM_SYNCONF_CNTINC_MASK                  (0x01UL << FTM_SYNCONF_CNTINC_SHIFT)                /*!< FTM0_SYNCONF: CNTINC Mask               */
#define FTM_SYNCONF_CNTINC_SHIFT                 2                                                   /*!< FTM0_SYNCONF: CNTINC Position           */
#define FTM_SYNCONF_INVC_MASK                    (0x01UL << FTM_SYNCONF_INVC_SHIFT)                  /*!< FTM0_SYNCONF: INVC Mask                 */
#define FTM_SYNCONF_INVC_SHIFT                   4                                                   /*!< FTM0_SYNCONF: INVC Position             */
#define FTM_SYNCONF_SWOC_MASK                    (0x01UL << FTM_SYNCONF_SWOC_SHIFT)                  /*!< FTM0_SYNCONF: SWOC Mask                 */
#define FTM_SYNCONF_SWOC_SHIFT                   5                                                   /*!< FTM0_SYNCONF: SWOC Position             */
#define FTM_SYNCONF_SYNCMODE_MASK                (0x01UL << FTM_SYNCONF_SYNCMODE_SHIFT)              /*!< FTM0_SYNCONF: SYNCMODE Mask             */
#define FTM_SYNCONF_SYNCMODE_SHIFT               7                                                   /*!< FTM0_SYNCONF: SYNCMODE Position         */
#define FTM_SYNCONF_SWRSTCNT_MASK                (0x01UL << FTM_SYNCONF_SWRSTCNT_SHIFT)              /*!< FTM0_SYNCONF: SWRSTCNT Mask             */
#define FTM_SYNCONF_SWRSTCNT_SHIFT               8                                                   /*!< FTM0_SYNCONF: SWRSTCNT Position         */
#define FTM_SYNCONF_SWWRBUF_MASK                 (0x01UL << FTM_SYNCONF_SWWRBUF_SHIFT)               /*!< FTM0_SYNCONF: SWWRBUF Mask              */
#define FTM_SYNCONF_SWWRBUF_SHIFT                9                                                   /*!< FTM0_SYNCONF: SWWRBUF Position          */
#define FTM_SYNCONF_SWOM_MASK                    (0x01UL << FTM_SYNCONF_SWOM_SHIFT)                  /*!< FTM0_SYNCONF: SWOM Mask                 */
#define FTM_SYNCONF_SWOM_SHIFT                   10                                                  /*!< FTM0_SYNCONF: SWOM Position             */
#define FTM_SYNCONF_SWINVC_MASK                  (0x01UL << FTM_SYNCONF_SWINVC_SHIFT)                /*!< FTM0_SYNCONF: SWINVC Mask               */
#define FTM_SYNCONF_SWINVC_SHIFT                 11                                                  /*!< FTM0_SYNCONF: SWINVC Position           */
#define FTM_SYNCONF_SWSOC_MASK                   (0x01UL << FTM_SYNCONF_SWSOC_SHIFT)                 /*!< FTM0_SYNCONF: SWSOC Mask                */
#define FTM_SYNCONF_SWSOC_SHIFT                  12                                                  /*!< FTM0_SYNCONF: SWSOC Position            */
#define FTM_SYNCONF_HWRSTCNT_MASK                (0x01UL << FTM_SYNCONF_HWRSTCNT_SHIFT)              /*!< FTM0_SYNCONF: HWRSTCNT Mask             */
#define FTM_SYNCONF_HWRSTCNT_SHIFT               16                                                  /*!< FTM0_SYNCONF: HWRSTCNT Position         */
#define FTM_SYNCONF_HWWRBUF_MASK                 (0x01UL << FTM_SYNCONF_HWWRBUF_SHIFT)               /*!< FTM0_SYNCONF: HWWRBUF Mask              */
#define FTM_SYNCONF_HWWRBUF_SHIFT                17                                                  /*!< FTM0_SYNCONF: HWWRBUF Position          */
#define FTM_SYNCONF_HWOM_MASK                    (0x01UL << FTM_SYNCONF_HWOM_SHIFT)                  /*!< FTM0_SYNCONF: HWOM Mask                 */
#define FTM_SYNCONF_HWOM_SHIFT                   18                                                  /*!< FTM0_SYNCONF: HWOM Position             */
#define FTM_SYNCONF_HWINVC_MASK                  (0x01UL << FTM_SYNCONF_HWINVC_SHIFT)                /*!< FTM0_SYNCONF: HWINVC Mask               */
#define FTM_SYNCONF_HWINVC_SHIFT                 19                                                  /*!< FTM0_SYNCONF: HWINVC Position           */
#define FTM_SYNCONF_HWSOC_MASK                   (0x01UL << FTM_SYNCONF_HWSOC_SHIFT)                 /*!< FTM0_SYNCONF: HWSOC Mask                */
#define FTM_SYNCONF_HWSOC_SHIFT                  20                                                  /*!< FTM0_SYNCONF: HWSOC Position            */

/* ------- FTM2_INVCTRL                             ------ */
#define FTM_INVCTRL_INV0EN_MASK                  (0x01UL << FTM_INVCTRL_INV0EN_SHIFT)                /*!< FTM0_INVCTRL: INV0EN Mask               */
#define FTM_INVCTRL_INV0EN_SHIFT                 0                                                   /*!< FTM0_INVCTRL: INV0EN Position           */
#define FTM_INVCTRL_INV1EN_MASK                  (0x01UL << FTM_INVCTRL_INV1EN_SHIFT)                /*!< FTM0_INVCTRL: INV1EN Mask               */
#define FTM_INVCTRL_INV1EN_SHIFT                 1                                                   /*!< FTM0_INVCTRL: INV1EN Position           */
#define FTM_INVCTRL_INV2EN_MASK                  (0x01UL << FTM_INVCTRL_INV2EN_SHIFT)                /*!< FTM0_INVCTRL: INV2EN Mask               */
#define FTM_INVCTRL_INV2EN_SHIFT                 2                                                   /*!< FTM0_INVCTRL: INV2EN Position           */
#define FTM_INVCTRL_INV3EN_MASK                  (0x01UL << FTM_INVCTRL_INV3EN_SHIFT)                /*!< FTM0_INVCTRL: INV3EN Mask               */
#define FTM_INVCTRL_INV3EN_SHIFT                 3                                                   /*!< FTM0_INVCTRL: INV3EN Position           */

/* ------- FTM2_SWOCTRL                             ------ */
#define FTM_SWOCTRL_CH0OC_MASK                   (0x01UL << FTM_SWOCTRL_CH0OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH0OC Mask                */
#define FTM_SWOCTRL_CH0OC_SHIFT                  0                                                   /*!< FTM0_SWOCTRL: CH0OC Position            */
#define FTM_SWOCTRL_CH1OC_MASK                   (0x01UL << FTM_SWOCTRL_CH1OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH1OC Mask                */
#define FTM_SWOCTRL_CH1OC_SHIFT                  1                                                   /*!< FTM0_SWOCTRL: CH1OC Position            */
#define FTM_SWOCTRL_CH2OC_MASK                   (0x01UL << FTM_SWOCTRL_CH2OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH2OC Mask                */
#define FTM_SWOCTRL_CH2OC_SHIFT                  2                                                   /*!< FTM0_SWOCTRL: CH2OC Position            */
#define FTM_SWOCTRL_CH3OC_MASK                   (0x01UL << FTM_SWOCTRL_CH3OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH3OC Mask                */
#define FTM_SWOCTRL_CH3OC_SHIFT                  3                                                   /*!< FTM0_SWOCTRL: CH3OC Position            */
#define FTM_SWOCTRL_CH4OC_MASK                   (0x01UL << FTM_SWOCTRL_CH4OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH4OC Mask                */
#define FTM_SWOCTRL_CH4OC_SHIFT                  4                                                   /*!< FTM0_SWOCTRL: CH4OC Position            */
#define FTM_SWOCTRL_CH5OC_MASK                   (0x01UL << FTM_SWOCTRL_CH5OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH5OC Mask                */
#define FTM_SWOCTRL_CH5OC_SHIFT                  5                                                   /*!< FTM0_SWOCTRL: CH5OC Position            */
#define FTM_SWOCTRL_CH6OC_MASK                   (0x01UL << FTM_SWOCTRL_CH6OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH6OC Mask                */
#define FTM_SWOCTRL_CH6OC_SHIFT                  6                                                   /*!< FTM0_SWOCTRL: CH6OC Position            */
#define FTM_SWOCTRL_CH7OC_MASK                   (0x01UL << FTM_SWOCTRL_CH7OC_SHIFT)                 /*!< FTM0_SWOCTRL: CH7OC Mask                */
#define FTM_SWOCTRL_CH7OC_SHIFT                  7                                                   /*!< FTM0_SWOCTRL: CH7OC Position            */
#define FTM_SWOCTRL_CH0OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH0OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH0OCV Mask               */
#define FTM_SWOCTRL_CH0OCV_SHIFT                 8                                                   /*!< FTM0_SWOCTRL: CH0OCV Position           */
#define FTM_SWOCTRL_CH1OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH1OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH1OCV Mask               */
#define FTM_SWOCTRL_CH1OCV_SHIFT                 9                                                   /*!< FTM0_SWOCTRL: CH1OCV Position           */
#define FTM_SWOCTRL_CH2OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH2OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH2OCV Mask               */
#define FTM_SWOCTRL_CH2OCV_SHIFT                 10                                                  /*!< FTM0_SWOCTRL: CH2OCV Position           */
#define FTM_SWOCTRL_CH3OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH3OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH3OCV Mask               */
#define FTM_SWOCTRL_CH3OCV_SHIFT                 11                                                  /*!< FTM0_SWOCTRL: CH3OCV Position           */
#define FTM_SWOCTRL_CH4OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH4OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH4OCV Mask               */
#define FTM_SWOCTRL_CH4OCV_SHIFT                 12                                                  /*!< FTM0_SWOCTRL: CH4OCV Position           */
#define FTM_SWOCTRL_CH5OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH5OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH5OCV Mask               */
#define FTM_SWOCTRL_CH5OCV_SHIFT                 13                                                  /*!< FTM0_SWOCTRL: CH5OCV Position           */
#define FTM_SWOCTRL_CH6OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH6OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH6OCV Mask               */
#define FTM_SWOCTRL_CH6OCV_SHIFT                 14                                                  /*!< FTM0_SWOCTRL: CH6OCV Position           */
#define FTM_SWOCTRL_CH7OCV_MASK                  (0x01UL << FTM_SWOCTRL_CH7OCV_SHIFT)                /*!< FTM0_SWOCTRL: CH7OCV Mask               */
#define FTM_SWOCTRL_CH7OCV_SHIFT                 15                                                  /*!< FTM0_SWOCTRL: CH7OCV Position           */

/* ------- FTM2_PWMLOAD                             ------ */
#define FTM_PWMLOAD_CH0SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH0SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH0SEL Mask               */
#define FTM_PWMLOAD_CH0SEL_SHIFT                 0                                                   /*!< FTM0_PWMLOAD: CH0SEL Position           */
#define FTM_PWMLOAD_CH1SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH1SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH1SEL Mask               */
#define FTM_PWMLOAD_CH1SEL_SHIFT                 1                                                   /*!< FTM0_PWMLOAD: CH1SEL Position           */
#define FTM_PWMLOAD_CH2SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH2SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH2SEL Mask               */
#define FTM_PWMLOAD_CH2SEL_SHIFT                 2                                                   /*!< FTM0_PWMLOAD: CH2SEL Position           */
#define FTM_PWMLOAD_CH3SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH3SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH3SEL Mask               */
#define FTM_PWMLOAD_CH3SEL_SHIFT                 3                                                   /*!< FTM0_PWMLOAD: CH3SEL Position           */
#define FTM_PWMLOAD_CH4SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH4SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH4SEL Mask               */
#define FTM_PWMLOAD_CH4SEL_SHIFT                 4                                                   /*!< FTM0_PWMLOAD: CH4SEL Position           */
#define FTM_PWMLOAD_CH5SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH5SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH5SEL Mask               */
#define FTM_PWMLOAD_CH5SEL_SHIFT                 5                                                   /*!< FTM0_PWMLOAD: CH5SEL Position           */
#define FTM_PWMLOAD_CH6SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH6SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH6SEL Mask               */
#define FTM_PWMLOAD_CH6SEL_SHIFT                 6                                                   /*!< FTM0_PWMLOAD: CH6SEL Position           */
#define FTM_PWMLOAD_CH7SEL_MASK                  (0x01UL << FTM_PWMLOAD_CH7SEL_SHIFT)                /*!< FTM0_PWMLOAD: CH7SEL Mask               */
#define FTM_PWMLOAD_CH7SEL_SHIFT                 7                                                   /*!< FTM0_PWMLOAD: CH7SEL Position           */
#define FTM_PWMLOAD_LDOK_MASK                    (0x01UL << FTM_PWMLOAD_LDOK_SHIFT)                  /*!< FTM0_PWMLOAD: LDOK Mask                 */
#define FTM_PWMLOAD_LDOK_SHIFT                   9                                                   /*!< FTM0_PWMLOAD: LDOK Position             */

/* -------------------------------------------------------------------------------- */
/* -----------     'FTM2' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define FTM2_SC                        (FTM2->SC)
#define FTM2_CNT                       (FTM2->CNT)
#define FTM2_MOD                       (FTM2->MOD)
#define FTM2_C0SC                      (FTM2->CONTROLS[0].CnSC)
#define FTM2_C0V                       (FTM2->CONTROLS[0].CnV)
#define FTM2_C1SC                      (FTM2->CONTROLS[1].CnSC)
#define FTM2_C1V                       (FTM2->CONTROLS[1].CnV)
#define FTM2_C2SC                      (FTM2->CONTROLS[2].CnSC)
#define FTM2_C2V                       (FTM2->CONTROLS[2].CnV)
#define FTM2_C3SC                      (FTM2->CONTROLS[3].CnSC)
#define FTM2_C3V                       (FTM2->CONTROLS[3].CnV)
#define FTM2_C4SC                      (FTM2->CONTROLS[4].CnSC)
#define FTM2_C4V                       (FTM2->CONTROLS[4].CnV)
#define FTM2_C5SC                      (FTM2->CONTROLS[5].CnSC)
#define FTM2_C5V                       (FTM2->CONTROLS[5].CnV)
#define FTM2_CNTIN                     (FTM2->CNTIN)
#define FTM2_STATUS                    (FTM2->STATUS)
#define FTM2_MODE                      (FTM2->MODE)
#define FTM2_SYNC                      (FTM2->SYNC)
#define FTM2_OUTINIT                   (FTM2->OUTINIT)
#define FTM2_OUTMASK                   (FTM2->OUTMASK)
#define FTM2_COMBINE                   (FTM2->COMBINE)
#define FTM2_DEADTIME                  (FTM2->DEADTIME)
#define FTM2_EXTTRIG                   (FTM2->EXTTRIG)
#define FTM2_POL                       (FTM2->POL)
#define FTM2_FMS                       (FTM2->FMS)
#define FTM2_FILTER                    (FTM2->FILTER)
#define FTM2_FLTCTRL                   (FTM2->FLTCTRL)
#define FTM2_CONF                      (FTM2->CONF)
#define FTM2_FLTPOL                    (FTM2->FLTPOL)
#define FTM2_SYNCONF                   (FTM2->SYNCONF)
#define FTM2_INVCTRL                   (FTM2->INVCTRL)
#define FTM2_SWOCTRL                   (FTM2->SWOCTRL)
#define FTM2_PWMLOAD                   (FTM2->PWMLOAD)

/* ================================================================================ */
/* ================           FTMRH (file:FTMRH_MKE)               ================ */
/* ================================================================================ */

/**
 * @brief Flash Memory Interface (FTMRH)
 */
typedef struct {                                /*!<       FTMRH Structure                                              */
   __IO uint8_t   FCLKDIV;                      /*!< 0000: Flash Clock Divider Register                                 */
   __IO uint8_t   FSEC;                         /*!< 0001: Flash Security Register                                      */
   __IO uint8_t   FCCOBIX;                      /*!< 0002: Flash CCOB Index Register                                    */
   __I  uint8_t   RESERVED0;                    /*!< 0003:                                                              */
   __IO uint8_t   FCNFG;                        /*!< 0004: Flash Configuration Register                                 */
   __IO uint8_t   FERCNFG;                      /*!< 0005: Flash Error Configuration Register                           */
   __IO uint8_t   FSTAT;                        /*!< 0006: Flash Status Register                                        */
   __IO uint8_t   FERSTAT;                      /*!< 0007: Flash Error Status Register                                  */
   __IO uint8_t   FPROT;                        /*!< 0008: Flash Protection Register                                    */
   __IO uint8_t   EEPROT;                       /*!< 0009: EEPROM Protection Register                                   */
   union {                                      /*!< 0000: (size=0002)                                                  */
      __IO uint16_t  FCCOB;                     /*!< 000A: Flash Common Command Object Register (FCCOBLO:FCCOBHI)       */
      struct {                                  /*!< 0000: (size=0002)                                                  */
         __IO uint8_t   FCCOBHI;                /*!< 000A: Flash Common Command Object Register:High                    */
         __IO uint8_t   FCCOBLO;                /*!< 000B: Flash Common Command Object Register:Low                     */
      };
   };
   __IO uint8_t   FOPT;                         /*!< 000C: Flash Option Register                                        */
} FTMRH_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'FTMRH' Position & Mask macros                       ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- FTMRH_FCLKDIV                            ------ */
#define FTMRH_FCLKDIV_FDIV_MASK                  (0x3FUL << FTMRH_FCLKDIV_FDIV_SHIFT)                /*!< FTMRH_FCLKDIV: FDIV Mask                */
#define FTMRH_FCLKDIV_FDIV_SHIFT                 0                                                   /*!< FTMRH_FCLKDIV: FDIV Position            */
#define FTMRH_FCLKDIV_FDIV(x)                    (((x)<<FTMRH_FCLKDIV_FDIV_SHIFT)&FTMRH_FCLKDIV_FDIV_MASK) /*!< FTMRH_FCLKDIV                           */
#define FTMRH_FCLKDIV_FDIVLCK_MASK               (0x01UL << FTMRH_FCLKDIV_FDIVLCK_SHIFT)             /*!< FTMRH_FCLKDIV: FDIVLCK Mask             */
#define FTMRH_FCLKDIV_FDIVLCK_SHIFT              6                                                   /*!< FTMRH_FCLKDIV: FDIVLCK Position         */
#define FTMRH_FCLKDIV_FDIVLD_MASK                (0x01UL << FTMRH_FCLKDIV_FDIVLD_SHIFT)              /*!< FTMRH_FCLKDIV: FDIVLD Mask              */
#define FTMRH_FCLKDIV_FDIVLD_SHIFT               7                                                   /*!< FTMRH_FCLKDIV: FDIVLD Position          */

/* ------- FTMRH_FSEC                               ------ */
#define FTMRH_FSEC_SEC_MASK                      (0x03UL << FTMRH_FSEC_SEC_SHIFT)                    /*!< FTMRH_FSEC: SEC Mask                    */
#define FTMRH_FSEC_SEC_SHIFT                     0                                                   /*!< FTMRH_FSEC: SEC Position                */
#define FTMRH_FSEC_SEC(x)                        (((x)<<FTMRH_FSEC_SEC_SHIFT)&FTMRH_FSEC_SEC_MASK)   /*!< FTMRH_FSEC                              */
#define FTMRH_FSEC_KEYEN_MASK                    (0x03UL << FTMRH_FSEC_KEYEN_SHIFT)                  /*!< FTMRH_FSEC: KEYEN Mask                  */
#define FTMRH_FSEC_KEYEN_SHIFT                   6                                                   /*!< FTMRH_FSEC: KEYEN Position              */
#define FTMRH_FSEC_KEYEN(x)                      (((x)<<FTMRH_FSEC_KEYEN_SHIFT)&FTMRH_FSEC_KEYEN_MASK) /*!< FTMRH_FSEC                              */

/* ------- FTMRH_FCCOBIX                            ------ */
#define FTMRH_FCCOBIX_CCOBIX_MASK                (0x07UL << FTMRH_FCCOBIX_CCOBIX_SHIFT)              /*!< FTMRH_FCCOBIX: CCOBIX Mask              */
#define FTMRH_FCCOBIX_CCOBIX_SHIFT               0                                                   /*!< FTMRH_FCCOBIX: CCOBIX Position          */
#define FTMRH_FCCOBIX_CCOBIX(x)                  (((x)<<FTMRH_FCCOBIX_CCOBIX_SHIFT)&FTMRH_FCCOBIX_CCOBIX_MASK) /*!< FTMRH_FCCOBIX                           */

/* ------- FTMRH_FCNFG                              ------ */
#define FTMRH_FCNFG_FSFD_MASK                    (0x01UL << FTMRH_FCNFG_FSFD_SHIFT)                  /*!< FTMRH_FCNFG: FSFD Mask                  */
#define FTMRH_FCNFG_FSFD_SHIFT                   0                                                   /*!< FTMRH_FCNFG: FSFD Position              */
#define FTMRH_FCNFG_FDFD_MASK                    (0x01UL << FTMRH_FCNFG_FDFD_SHIFT)                  /*!< FTMRH_FCNFG: FDFD Mask                  */
#define FTMRH_FCNFG_FDFD_SHIFT                   1                                                   /*!< FTMRH_FCNFG: FDFD Position              */
#define FTMRH_FCNFG_IGNSF_MASK                   (0x01UL << FTMRH_FCNFG_IGNSF_SHIFT)                 /*!< FTMRH_FCNFG: IGNSF Mask                 */
#define FTMRH_FCNFG_IGNSF_SHIFT                  4                                                   /*!< FTMRH_FCNFG: IGNSF Position             */
#define FTMRH_FCNFG_CCIE_MASK                    (0x01UL << FTMRH_FCNFG_CCIE_SHIFT)                  /*!< FTMRH_FCNFG: CCIE Mask                  */
#define FTMRH_FCNFG_CCIE_SHIFT                   7                                                   /*!< FTMRH_FCNFG: CCIE Position              */

/* ------- FTMRH_FERCNFG                            ------ */
#define FTMRH_FERCNFG_SFDIE_MASK                 (0x01UL << FTMRH_FERCNFG_SFDIE_SHIFT)               /*!< FTMRH_FERCNFG: SFDIE Mask               */
#define FTMRH_FERCNFG_SFDIE_SHIFT                0                                                   /*!< FTMRH_FERCNFG: SFDIE Position           */
#define FTMRH_FERCNFG_DFDIE_MASK                 (0x01UL << FTMRH_FERCNFG_DFDIE_SHIFT)               /*!< FTMRH_FERCNFG: DFDIE Mask               */
#define FTMRH_FERCNFG_DFDIE_SHIFT                1                                                   /*!< FTMRH_FERCNFG: DFDIE Position           */

/* ------- FTMRH_FSTAT                              ------ */
#define FTMRH_FSTAT_MGSTAT_MASK                  (0x03UL << FTMRH_FSTAT_MGSTAT_SHIFT)                /*!< FTMRH_FSTAT: MGSTAT Mask                */
#define FTMRH_FSTAT_MGSTAT_SHIFT                 0                                                   /*!< FTMRH_FSTAT: MGSTAT Position            */
#define FTMRH_FSTAT_MGSTAT(x)                    (((x)<<FTMRH_FSTAT_MGSTAT_SHIFT)&FTMRH_FSTAT_MGSTAT_MASK) /*!< FTMRH_FSTAT                             */
#define FTMRH_FSTAT_MGBUSY_MASK                  (0x01UL << FTMRH_FSTAT_MGBUSY_SHIFT)                /*!< FTMRH_FSTAT: MGBUSY Mask                */
#define FTMRH_FSTAT_MGBUSY_SHIFT                 3                                                   /*!< FTMRH_FSTAT: MGBUSY Position            */
#define FTMRH_FSTAT_FPVIOL_MASK                  (0x01UL << FTMRH_FSTAT_FPVIOL_SHIFT)                /*!< FTMRH_FSTAT: FPVIOL Mask                */
#define FTMRH_FSTAT_FPVIOL_SHIFT                 4                                                   /*!< FTMRH_FSTAT: FPVIOL Position            */
#define FTMRH_FSTAT_ACCERR_MASK                  (0x01UL << FTMRH_FSTAT_ACCERR_SHIFT)                /*!< FTMRH_FSTAT: ACCERR Mask                */
#define FTMRH_FSTAT_ACCERR_SHIFT                 5                                                   /*!< FTMRH_FSTAT: ACCERR Position            */
#define FTMRH_FSTAT_CCIF_MASK                    (0x01UL << FTMRH_FSTAT_CCIF_SHIFT)                  /*!< FTMRH_FSTAT: CCIF Mask                  */
#define FTMRH_FSTAT_CCIF_SHIFT                   7                                                   /*!< FTMRH_FSTAT: CCIF Position              */

/* ------- FTMRH_FERSTAT                            ------ */
#define FTMRH_FERSTAT_SFDIF_MASK                 (0x01UL << FTMRH_FERSTAT_SFDIF_SHIFT)               /*!< FTMRH_FERSTAT: SFDIF Mask               */
#define FTMRH_FERSTAT_SFDIF_SHIFT                0                                                   /*!< FTMRH_FERSTAT: SFDIF Position           */
#define FTMRH_FERSTAT_DFDIF_MASK                 (0x01UL << FTMRH_FERSTAT_DFDIF_SHIFT)               /*!< FTMRH_FERSTAT: DFDIF Mask               */
#define FTMRH_FERSTAT_DFDIF_SHIFT                1                                                   /*!< FTMRH_FERSTAT: DFDIF Position           */

/* ------- FTMRH_FPROT                              ------ */
#define FTMRH_FPROT_FPLS_MASK                    (0x03UL << FTMRH_FPROT_FPLS_SHIFT)                  /*!< FTMRH_FPROT: FPLS Mask                  */
#define FTMRH_FPROT_FPLS_SHIFT                   0                                                   /*!< FTMRH_FPROT: FPLS Position              */
#define FTMRH_FPROT_FPLS(x)                      (((x)<<FTMRH_FPROT_FPLS_SHIFT)&FTMRH_FPROT_FPLS_MASK) /*!< FTMRH_FPROT                             */
#define FTMRH_FPROT_FPLDIS_MASK                  (0x01UL << FTMRH_FPROT_FPLDIS_SHIFT)                /*!< FTMRH_FPROT: FPLDIS Mask                */
#define FTMRH_FPROT_FPLDIS_SHIFT                 2                                                   /*!< FTMRH_FPROT: FPLDIS Position            */
#define FTMRH_FPROT_FPHS_MASK                    (0x03UL << FTMRH_FPROT_FPHS_SHIFT)                  /*!< FTMRH_FPROT: FPHS Mask                  */
#define FTMRH_FPROT_FPHS_SHIFT                   3                                                   /*!< FTMRH_FPROT: FPHS Position              */
#define FTMRH_FPROT_FPHS(x)                      (((x)<<FTMRH_FPROT_FPHS_SHIFT)&FTMRH_FPROT_FPHS_MASK) /*!< FTMRH_FPROT                             */
#define FTMRH_FPROT_FPHDIS_MASK                  (0x01UL << FTMRH_FPROT_FPHDIS_SHIFT)                /*!< FTMRH_FPROT: FPHDIS Mask                */
#define FTMRH_FPROT_FPHDIS_SHIFT                 5                                                   /*!< FTMRH_FPROT: FPHDIS Position            */
#define FTMRH_FPROT_FPOPEN_MASK                  (0x01UL << FTMRH_FPROT_FPOPEN_SHIFT)                /*!< FTMRH_FPROT: FPOPEN Mask                */
#define FTMRH_FPROT_FPOPEN_SHIFT                 7                                                   /*!< FTMRH_FPROT: FPOPEN Position            */

/* ------- FTMRH_EEPROT                             ------ */
#define FTMRH_EEPROT_DPS_MASK                    (0x07UL << FTMRH_EEPROT_DPS_SHIFT)                  /*!< FTMRH_EEPROT: DPS Mask                  */
#define FTMRH_EEPROT_DPS_SHIFT                   0                                                   /*!< FTMRH_EEPROT: DPS Position              */
#define FTMRH_EEPROT_DPS(x)                      (((x)<<FTMRH_EEPROT_DPS_SHIFT)&FTMRH_EEPROT_DPS_MASK) /*!< FTMRH_EEPROT                            */
#define FTMRH_EEPROT_DPOPEN_MASK                 (0x01UL << FTMRH_EEPROT_DPOPEN_SHIFT)               /*!< FTMRH_EEPROT: DPOPEN Mask               */
#define FTMRH_EEPROT_DPOPEN_SHIFT                7                                                   /*!< FTMRH_EEPROT: DPOPEN Position           */

/* ------- FTMRH_FCCOB                              ------ */

/* ------- FTMRH_FCCOBHI                            ------ */

/* ------- FTMRH_FCCOBLO                            ------ */

/* ------- FTMRH_FOPT                               ------ */

/* -------------------------------------------------------------------------------- */
/* -----------     'FTMRH' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define FTMRH_FCLKDIV                  (FTMRH->FCLKDIV)
#define FTMRH_FSEC                     (FTMRH->FSEC)
#define FTMRH_FCCOBIX                  (FTMRH->FCCOBIX)
#define FTMRH_FCNFG                    (FTMRH->FCNFG)
#define FTMRH_FERCNFG                  (FTMRH->FERCNFG)
#define FTMRH_FSTAT                    (FTMRH->FSTAT)
#define FTMRH_FERSTAT                  (FTMRH->FERSTAT)
#define FTMRH_FPROT                    (FTMRH->FPROT)
#define FTMRH_EEPROT                   (FTMRH->EEPROT)
#define FTMRH_FCCOB                    (FTMRH->FCCOB)
#define FTMRH_FCCOBHI                  (FTMRH->FCCOBHI)
#define FTMRH_FCCOBLO                  (FTMRH->FCCOBLO)
#define FTMRH_FOPT                     (FTMRH->FOPT)

/* ================================================================================ */
/* ================           GPIOA (derived from FGPIOA)          ================ */
/* ================================================================================ */

/**
 * @brief General Purpose Input/Output (GPIOA)
 */
typedef FGPIOA_Type GPIOA_Type;  /*!< GPIOA Structure                                             */


/* -------------------------------------------------------------------------------- */
/* -----------     'GPIOA' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define GPIOA_PDOR                     (GPIOA->PDOR)
#define GPIOA_PSOR                     (GPIOA->PSOR)
#define GPIOA_PCOR                     (GPIOA->PCOR)
#define GPIOA_PTOR                     (GPIOA->PTOR)
#define GPIOA_PDIR                     (GPIOA->PDIR)
#define GPIOA_PDDR                     (GPIOA->PDDR)
#define GPIOA_PIDR                     (GPIOA->PIDR)

/* ================================================================================ */
/* ================           GPIOB (derived from FGPIOA)          ================ */
/* ================================================================================ */

/**
 * @brief General Purpose Input/Output (GPIOB)
 */
typedef FGPIOA_Type GPIOB_Type;  /*!< GPIOB Structure                                             */


/* -------------------------------------------------------------------------------- */
/* -----------     'GPIOB' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define GPIOB_PDOR                     (GPIOB->PDOR)
#define GPIOB_PSOR                     (GPIOB->PSOR)
#define GPIOB_PCOR                     (GPIOB->PCOR)
#define GPIOB_PTOR                     (GPIOB->PTOR)
#define GPIOB_PDIR                     (GPIOB->PDIR)
#define GPIOB_PDDR                     (GPIOB->PDDR)
#define GPIOB_PIDR                     (GPIOB->PIDR)

/* ================================================================================ */
/* ================           I2C0 (file:I2C0_MKE)                 ================ */
/* ================================================================================ */

/**
 * @brief Inter-Integrated Circuit (I2C0)
 */
typedef struct {                                /*!<       I2C0 Structure                                               */
   __IO uint8_t   A1;                           /*!< 0000: I2C Address Register 1                                       */
   __IO uint8_t   F;                            /*!< 0001: I2C Frequency Divider register                               */
   __IO uint8_t   C1;                           /*!< 0002: I2C Control Register 1                                       */
   __IO uint8_t   S;                            /*!< 0003: I2C Status Register                                          */
   __IO uint8_t   D;                            /*!< 0004: I2C Data I/O register                                        */
   __IO uint8_t   C2;                           /*!< 0005: I2C Control Register 2                                       */
   __IO uint8_t   FLT;                          /*!< 0006: I2C Programmable Input Glitch Filter register                */
   __IO uint8_t   RA;                           /*!< 0007: I2C Range Address register                                   */
   __IO uint8_t   SMB;                          /*!< 0008: I2C SMBus Control and Status register                        */
   __IO uint8_t   A2;                           /*!< 0009: I2C Address Register 2                                       */
   __IO uint8_t   SLTH;                         /*!< 000A: I2C SCL Low Timeout Register High                            */
   __IO uint8_t   SLTL;                         /*!< 000B: I2C SCL Low Timeout Register Low                             */
} I2C0_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'I2C0' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- I2C0_A1                                  ------ */
#define I2C_A1_AD_MASK                           (0x7FUL << I2C_A1_AD_SHIFT)                         /*!< I2C0_A1: AD Mask                        */
#define I2C_A1_AD_SHIFT                          1                                                   /*!< I2C0_A1: AD Position                    */
#define I2C_A1_AD(x)                             (((x)<<I2C_A1_AD_SHIFT)&I2C_A1_AD_MASK)             /*!< I2C0_A1                                 */

/* ------- I2C0_F                                   ------ */
#define I2C_F_ICR_MASK                           (0x3FUL << I2C_F_ICR_SHIFT)                         /*!< I2C0_F: ICR Mask                        */
#define I2C_F_ICR_SHIFT                          0                                                   /*!< I2C0_F: ICR Position                    */
#define I2C_F_ICR(x)                             (((x)<<I2C_F_ICR_SHIFT)&I2C_F_ICR_MASK)             /*!< I2C0_F                                  */
#define I2C_F_MULT_MASK                          (0x03UL << I2C_F_MULT_SHIFT)                        /*!< I2C0_F: MULT Mask                       */
#define I2C_F_MULT_SHIFT                         6                                                   /*!< I2C0_F: MULT Position                   */
#define I2C_F_MULT(x)                            (((x)<<I2C_F_MULT_SHIFT)&I2C_F_MULT_MASK)           /*!< I2C0_F                                  */

/* ------- I2C0_C1                                  ------ */
#define I2C_C1_WUEN_MASK                         (0x01UL << I2C_C1_WUEN_SHIFT)                       /*!< I2C0_C1: WUEN Mask                      */
#define I2C_C1_WUEN_SHIFT                        1                                                   /*!< I2C0_C1: WUEN Position                  */
#define I2C_C1_RSTA_MASK                         (0x01UL << I2C_C1_RSTA_SHIFT)                       /*!< I2C0_C1: RSTA Mask                      */
#define I2C_C1_RSTA_SHIFT                        2                                                   /*!< I2C0_C1: RSTA Position                  */
#define I2C_C1_TXAK_MASK                         (0x01UL << I2C_C1_TXAK_SHIFT)                       /*!< I2C0_C1: TXAK Mask                      */
#define I2C_C1_TXAK_SHIFT                        3                                                   /*!< I2C0_C1: TXAK Position                  */
#define I2C_C1_TX_MASK                           (0x01UL << I2C_C1_TX_SHIFT)                         /*!< I2C0_C1: TX Mask                        */
#define I2C_C1_TX_SHIFT                          4                                                   /*!< I2C0_C1: TX Position                    */
#define I2C_C1_MST_MASK                          (0x01UL << I2C_C1_MST_SHIFT)                        /*!< I2C0_C1: MST Mask                       */
#define I2C_C1_MST_SHIFT                         5                                                   /*!< I2C0_C1: MST Position                   */
#define I2C_C1_IICIE_MASK                        (0x01UL << I2C_C1_IICIE_SHIFT)                      /*!< I2C0_C1: IICIE Mask                     */
#define I2C_C1_IICIE_SHIFT                       6                                                   /*!< I2C0_C1: IICIE Position                 */
#define I2C_C1_IICEN_MASK                        (0x01UL << I2C_C1_IICEN_SHIFT)                      /*!< I2C0_C1: IICEN Mask                     */
#define I2C_C1_IICEN_SHIFT                       7                                                   /*!< I2C0_C1: IICEN Position                 */

/* ------- I2C0_S                                   ------ */
#define I2C_S_RXAK_MASK                          (0x01UL << I2C_S_RXAK_SHIFT)                        /*!< I2C0_S: RXAK Mask                       */
#define I2C_S_RXAK_SHIFT                         0                                                   /*!< I2C0_S: RXAK Position                   */
#define I2C_S_IICIF_MASK                         (0x01UL << I2C_S_IICIF_SHIFT)                       /*!< I2C0_S: IICIF Mask                      */
#define I2C_S_IICIF_SHIFT                        1                                                   /*!< I2C0_S: IICIF Position                  */
#define I2C_S_SRW_MASK                           (0x01UL << I2C_S_SRW_SHIFT)                         /*!< I2C0_S: SRW Mask                        */
#define I2C_S_SRW_SHIFT                          2                                                   /*!< I2C0_S: SRW Position                    */
#define I2C_S_RAM_MASK                           (0x01UL << I2C_S_RAM_SHIFT)                         /*!< I2C0_S: RAM Mask                        */
#define I2C_S_RAM_SHIFT                          3                                                   /*!< I2C0_S: RAM Position                    */
#define I2C_S_ARBL_MASK                          (0x01UL << I2C_S_ARBL_SHIFT)                        /*!< I2C0_S: ARBL Mask                       */
#define I2C_S_ARBL_SHIFT                         4                                                   /*!< I2C0_S: ARBL Position                   */
#define I2C_S_BUSY_MASK                          (0x01UL << I2C_S_BUSY_SHIFT)                        /*!< I2C0_S: BUSY Mask                       */
#define I2C_S_BUSY_SHIFT                         5                                                   /*!< I2C0_S: BUSY Position                   */
#define I2C_S_IAAS_MASK                          (0x01UL << I2C_S_IAAS_SHIFT)                        /*!< I2C0_S: IAAS Mask                       */
#define I2C_S_IAAS_SHIFT                         6                                                   /*!< I2C0_S: IAAS Position                   */
#define I2C_S_TCF_MASK                           (0x01UL << I2C_S_TCF_SHIFT)                         /*!< I2C0_S: TCF Mask                        */
#define I2C_S_TCF_SHIFT                          7                                                   /*!< I2C0_S: TCF Position                    */

/* ------- I2C0_D                                   ------ */
#define I2C_D_DATA_MASK                          (0xFFUL << I2C_D_DATA_SHIFT)                        /*!< I2C0_D: DATA Mask                       */
#define I2C_D_DATA_SHIFT                         0                                                   /*!< I2C0_D: DATA Position                   */
#define I2C_D_DATA(x)                            (((x)<<I2C_D_DATA_SHIFT)&I2C_D_DATA_MASK)           /*!< I2C0_D                                  */

/* ------- I2C0_C2                                  ------ */
#define I2C_C2_AD_MASK                           (0x07UL << I2C_C2_AD_SHIFT)                         /*!< I2C0_C2: AD Mask                        */
#define I2C_C2_AD_SHIFT                          0                                                   /*!< I2C0_C2: AD Position                    */
#define I2C_C2_AD(x)                             (((x)<<I2C_C2_AD_SHIFT)&I2C_C2_AD_MASK)             /*!< I2C0_C2                                 */
#define I2C_C2_RMEN_MASK                         (0x01UL << I2C_C2_RMEN_SHIFT)                       /*!< I2C0_C2: RMEN Mask                      */
#define I2C_C2_RMEN_SHIFT                        3                                                   /*!< I2C0_C2: RMEN Position                  */
#define I2C_C2_SBRC_MASK                         (0x01UL << I2C_C2_SBRC_SHIFT)                       /*!< I2C0_C2: SBRC Mask                      */
#define I2C_C2_SBRC_SHIFT                        4                                                   /*!< I2C0_C2: SBRC Position                  */
#define I2C_C2_HDRS_MASK                         (0x01UL << I2C_C2_HDRS_SHIFT)                       /*!< I2C0_C2: HDRS Mask                      */
#define I2C_C2_HDRS_SHIFT                        5                                                   /*!< I2C0_C2: HDRS Position                  */
#define I2C_C2_ADEXT_MASK                        (0x01UL << I2C_C2_ADEXT_SHIFT)                      /*!< I2C0_C2: ADEXT Mask                     */
#define I2C_C2_ADEXT_SHIFT                       6                                                   /*!< I2C0_C2: ADEXT Position                 */
#define I2C_C2_GCAEN_MASK                        (0x01UL << I2C_C2_GCAEN_SHIFT)                      /*!< I2C0_C2: GCAEN Mask                     */
#define I2C_C2_GCAEN_SHIFT                       7                                                   /*!< I2C0_C2: GCAEN Position                 */

/* ------- I2C0_FLT                                 ------ */
#define I2C_FLT_FLT_MASK                         (0x1FUL << I2C_FLT_FLT_SHIFT)                       /*!< I2C0_FLT: FLT Mask                      */
#define I2C_FLT_FLT_SHIFT                        0                                                   /*!< I2C0_FLT: FLT Position                  */
#define I2C_FLT_FLT(x)                           (((x)<<I2C_FLT_FLT_SHIFT)&I2C_FLT_FLT_MASK)         /*!< I2C0_FLT                                */
#define I2C_FLT_STOPIE_MASK                      (0x01UL << I2C_FLT_STOPIE_SHIFT)                    /*!< I2C0_FLT: STOPIE Mask                   */
#define I2C_FLT_STOPIE_SHIFT                     5                                                   /*!< I2C0_FLT: STOPIE Position               */
#define I2C_FLT_STOPF_MASK                       (0x01UL << I2C_FLT_STOPF_SHIFT)                     /*!< I2C0_FLT: STOPF Mask                    */
#define I2C_FLT_STOPF_SHIFT                      6                                                   /*!< I2C0_FLT: STOPF Position                */
#define I2C_FLT_SHEN_MASK                        (0x01UL << I2C_FLT_SHEN_SHIFT)                      /*!< I2C0_FLT: SHEN Mask                     */
#define I2C_FLT_SHEN_SHIFT                       7                                                   /*!< I2C0_FLT: SHEN Position                 */

/* ------- I2C0_RA                                  ------ */
#define I2C_RA_RAD_MASK                          (0x7FUL << I2C_RA_RAD_SHIFT)                        /*!< I2C0_RA: RAD Mask                       */
#define I2C_RA_RAD_SHIFT                         1                                                   /*!< I2C0_RA: RAD Position                   */
#define I2C_RA_RAD(x)                            (((x)<<I2C_RA_RAD_SHIFT)&I2C_RA_RAD_MASK)           /*!< I2C0_RA                                 */

/* ------- I2C0_SMB                                 ------ */
#define I2C_SMB_SHTF2IE_MASK                     (0x01UL << I2C_SMB_SHTF2IE_SHIFT)                   /*!< I2C0_SMB: SHTF2IE Mask                  */
#define I2C_SMB_SHTF2IE_SHIFT                    0                                                   /*!< I2C0_SMB: SHTF2IE Position              */
#define I2C_SMB_SHTF2_MASK                       (0x01UL << I2C_SMB_SHTF2_SHIFT)                     /*!< I2C0_SMB: SHTF2 Mask                    */
#define I2C_SMB_SHTF2_SHIFT                      1                                                   /*!< I2C0_SMB: SHTF2 Position                */
#define I2C_SMB_SHTF1_MASK                       (0x01UL << I2C_SMB_SHTF1_SHIFT)                     /*!< I2C0_SMB: SHTF1 Mask                    */
#define I2C_SMB_SHTF1_SHIFT                      2                                                   /*!< I2C0_SMB: SHTF1 Position                */
#define I2C_SMB_SLTF_MASK                        (0x01UL << I2C_SMB_SLTF_SHIFT)                      /*!< I2C0_SMB: SLTF Mask                     */
#define I2C_SMB_SLTF_SHIFT                       3                                                   /*!< I2C0_SMB: SLTF Position                 */
#define I2C_SMB_TCKSEL_MASK                      (0x01UL << I2C_SMB_TCKSEL_SHIFT)                    /*!< I2C0_SMB: TCKSEL Mask                   */
#define I2C_SMB_TCKSEL_SHIFT                     4                                                   /*!< I2C0_SMB: TCKSEL Position               */
#define I2C_SMB_SIICAEN_MASK                     (0x01UL << I2C_SMB_SIICAEN_SHIFT)                   /*!< I2C0_SMB: SIICAEN Mask                  */
#define I2C_SMB_SIICAEN_SHIFT                    5                                                   /*!< I2C0_SMB: SIICAEN Position              */
#define I2C_SMB_ALERTEN_MASK                     (0x01UL << I2C_SMB_ALERTEN_SHIFT)                   /*!< I2C0_SMB: ALERTEN Mask                  */
#define I2C_SMB_ALERTEN_SHIFT                    6                                                   /*!< I2C0_SMB: ALERTEN Position              */
#define I2C_SMB_FACK_MASK                        (0x01UL << I2C_SMB_FACK_SHIFT)                      /*!< I2C0_SMB: FACK Mask                     */
#define I2C_SMB_FACK_SHIFT                       7                                                   /*!< I2C0_SMB: FACK Position                 */

/* ------- I2C0_A2                                  ------ */
#define I2C_A2_SAD_MASK                          (0x7FUL << I2C_A2_SAD_SHIFT)                        /*!< I2C0_A2: SAD Mask                       */
#define I2C_A2_SAD_SHIFT                         1                                                   /*!< I2C0_A2: SAD Position                   */
#define I2C_A2_SAD(x)                            (((x)<<I2C_A2_SAD_SHIFT)&I2C_A2_SAD_MASK)           /*!< I2C0_A2                                 */

/* ------- I2C0_SLTH                                ------ */

/* ------- I2C0_SLTL                                ------ */

/* -------------------------------------------------------------------------------- */
/* -----------     'I2C0' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define I2C0_A1                        (I2C0->A1)
#define I2C0_F                         (I2C0->F)
#define I2C0_C1                        (I2C0->C1)
#define I2C0_S                         (I2C0->S)
#define I2C0_D                         (I2C0->D)
#define I2C0_C2                        (I2C0->C2)
#define I2C0_FLT                       (I2C0->FLT)
#define I2C0_RA                        (I2C0->RA)
#define I2C0_SMB                       (I2C0->SMB)
#define I2C0_A2                        (I2C0->A2)
#define I2C0_SLTH                      (I2C0->SLTH)
#define I2C0_SLTL                      (I2C0->SLTL)

/* ================================================================================ */
/* ================           ICS (file:ICS_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Clock management (ICS)
 */
typedef struct {                                /*!<       ICS Structure                                                */
   __IO uint8_t   C1;                           /*!< 0000: ICS Control 1 Register                                       */
   __IO uint8_t   C2;                           /*!< 0001: ICS Control 2 Register                                       */
   __IO uint8_t   C3;                           /*!< 0002: ICS Control 2 Register                                       */
   __IO uint8_t   C4;                           /*!< 0003: ICS Control 4 Register                                       */
   __I  uint8_t   S;                            /*!< 0004: MCG Status Register                                          */
} ICS_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'ICS' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- ICS_C1                                   ------ */
#define ICS_C1_IREFSTEN_MASK                     (0x01UL << ICS_C1_IREFSTEN_SHIFT)                   /*!< ICS_C1: IREFSTEN Mask                   */
#define ICS_C1_IREFSTEN_SHIFT                    0                                                   /*!< ICS_C1: IREFSTEN Position               */
#define ICS_C1_IRCLKEN_MASK                      (0x01UL << ICS_C1_IRCLKEN_SHIFT)                    /*!< ICS_C1: IRCLKEN Mask                    */
#define ICS_C1_IRCLKEN_SHIFT                     1                                                   /*!< ICS_C1: IRCLKEN Position                */
#define ICS_C1_IREFS_MASK                        (0x01UL << ICS_C1_IREFS_SHIFT)                      /*!< ICS_C1: IREFS Mask                      */
#define ICS_C1_IREFS_SHIFT                       2                                                   /*!< ICS_C1: IREFS Position                  */
#define ICS_C1_RDIV_MASK                         (0x07UL << ICS_C1_RDIV_SHIFT)                       /*!< ICS_C1: RDIV Mask                       */
#define ICS_C1_RDIV_SHIFT                        3                                                   /*!< ICS_C1: RDIV Position                   */
#define ICS_C1_RDIV(x)                           (((x)<<ICS_C1_RDIV_SHIFT)&ICS_C1_RDIV_MASK)         /*!< ICS_C1                                  */
#define ICS_C1_CLKS_MASK                         (0x03UL << ICS_C1_CLKS_SHIFT)                       /*!< ICS_C1: CLKS Mask                       */
#define ICS_C1_CLKS_SHIFT                        6                                                   /*!< ICS_C1: CLKS Position                   */
#define ICS_C1_CLKS(x)                           (((x)<<ICS_C1_CLKS_SHIFT)&ICS_C1_CLKS_MASK)         /*!< ICS_C1                                  */

/* ------- ICS_C2                                   ------ */
#define ICS_C2_LP_MASK                           (0x01UL << ICS_C2_LP_SHIFT)                         /*!< ICS_C2: LP Mask                         */
#define ICS_C2_LP_SHIFT                          4                                                   /*!< ICS_C2: LP Position                     */
#define ICS_C2_BDIV_MASK                         (0x07UL << ICS_C2_BDIV_SHIFT)                       /*!< ICS_C2: BDIV Mask                       */
#define ICS_C2_BDIV_SHIFT                        5                                                   /*!< ICS_C2: BDIV Position                   */
#define ICS_C2_BDIV(x)                           (((x)<<ICS_C2_BDIV_SHIFT)&ICS_C2_BDIV_MASK)         /*!< ICS_C2                                  */

/* ------- ICS_C3                                   ------ */
#define ICS_C3_SCTRIM_MASK                       (0xFFUL << ICS_C3_SCTRIM_SHIFT)                     /*!< ICS_C3: SCTRIM Mask                     */
#define ICS_C3_SCTRIM_SHIFT                      0                                                   /*!< ICS_C3: SCTRIM Position                 */
#define ICS_C3_SCTRIM(x)                         (((x)<<ICS_C3_SCTRIM_SHIFT)&ICS_C3_SCTRIM_MASK)     /*!< ICS_C3                                  */

/* ------- ICS_C4                                   ------ */
#define ICS_C4_SCFTRIM_MASK                      (0x01UL << ICS_C4_SCFTRIM_SHIFT)                    /*!< ICS_C4: SCFTRIM Mask                    */
#define ICS_C4_SCFTRIM_SHIFT                     0                                                   /*!< ICS_C4: SCFTRIM Position                */
#define ICS_C4_CME_MASK                          (0x01UL << ICS_C4_CME_SHIFT)                        /*!< ICS_C4: CME Mask                        */
#define ICS_C4_CME_SHIFT                         5                                                   /*!< ICS_C4: CME Position                    */
#define ICS_C4_LOLIE0_MASK                       (0x01UL << ICS_C4_LOLIE0_SHIFT)                     /*!< ICS_C4: LOLIE0 Mask                     */
#define ICS_C4_LOLIE0_SHIFT                      7                                                   /*!< ICS_C4: LOLIE0 Position                 */

/* ------- ICS_S                                    ------ */
#define ICS_S_CLKST_MASK                         (0x03UL << ICS_S_CLKST_SHIFT)                       /*!< ICS_S: CLKST Mask                       */
#define ICS_S_CLKST_SHIFT                        2                                                   /*!< ICS_S: CLKST Position                   */
#define ICS_S_CLKST(x)                           (((x)<<ICS_S_CLKST_SHIFT)&ICS_S_CLKST_MASK)         /*!< ICS_S                                   */
#define ICS_S_IREFST_MASK                        (0x01UL << ICS_S_IREFST_SHIFT)                      /*!< ICS_S: IREFST Mask                      */
#define ICS_S_IREFST_SHIFT                       4                                                   /*!< ICS_S: IREFST Position                  */
#define ICS_S_LOCK_MASK                          (0x01UL << ICS_S_LOCK_SHIFT)                        /*!< ICS_S: LOCK Mask                        */
#define ICS_S_LOCK_SHIFT                         6                                                   /*!< ICS_S: LOCK Position                    */
#define ICS_S_LOLS_MASK                          (0x01UL << ICS_S_LOLS_SHIFT)                        /*!< ICS_S: LOLS Mask                        */
#define ICS_S_LOLS_SHIFT                         7                                                   /*!< ICS_S: LOLS Position                    */

/* -------------------------------------------------------------------------------- */
/* -----------     'ICS' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define ICS_C1                         (ICS->C1)
#define ICS_C2                         (ICS->C2)
#define ICS_C3                         (ICS->C3)
#define ICS_C4                         (ICS->C4)
#define ICS_S                          (ICS->S)

/* ================================================================================ */
/* ================           IRQ (file:IRQ_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Interrupt (IRQ)
 */
typedef struct {                                /*!<       IRQ Structure                                                */
   __IO uint8_t   SC;                           /*!< 0000: Interrupt Pin Request Status and Control Register            */
} IRQ_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'IRQ' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- IRQ_SC                                   ------ */
#define IRQ_SC_IRQMOD_MASK                       (0x01UL << IRQ_SC_IRQMOD_SHIFT)                     /*!< IRQ_SC: IRQMOD Mask                     */
#define IRQ_SC_IRQMOD_SHIFT                      0                                                   /*!< IRQ_SC: IRQMOD Position                 */
#define IRQ_SC_IRQIE_MASK                        (0x01UL << IRQ_SC_IRQIE_SHIFT)                      /*!< IRQ_SC: IRQIE Mask                      */
#define IRQ_SC_IRQIE_SHIFT                       1                                                   /*!< IRQ_SC: IRQIE Position                  */
#define IRQ_SC_IRQACK_MASK                       (0x01UL << IRQ_SC_IRQACK_SHIFT)                     /*!< IRQ_SC: IRQACK Mask                     */
#define IRQ_SC_IRQACK_SHIFT                      2                                                   /*!< IRQ_SC: IRQACK Position                 */
#define IRQ_SC_IRQF_MASK                         (0x01UL << IRQ_SC_IRQF_SHIFT)                       /*!< IRQ_SC: IRQF Mask                       */
#define IRQ_SC_IRQF_SHIFT                        3                                                   /*!< IRQ_SC: IRQF Position                   */
#define IRQ_SC_IRQPE_MASK                        (0x01UL << IRQ_SC_IRQPE_SHIFT)                      /*!< IRQ_SC: IRQPE Mask                      */
#define IRQ_SC_IRQPE_SHIFT                       4                                                   /*!< IRQ_SC: IRQPE Position                  */
#define IRQ_SC_IRQEDG_MASK                       (0x01UL << IRQ_SC_IRQEDG_SHIFT)                     /*!< IRQ_SC: IRQEDG Mask                     */
#define IRQ_SC_IRQEDG_SHIFT                      5                                                   /*!< IRQ_SC: IRQEDG Position                 */
#define IRQ_SC_IRQPDD_MASK                       (0x01UL << IRQ_SC_IRQPDD_SHIFT)                     /*!< IRQ_SC: IRQPDD Mask                     */
#define IRQ_SC_IRQPDD_SHIFT                      6                                                   /*!< IRQ_SC: IRQPDD Position                 */

/* -------------------------------------------------------------------------------- */
/* -----------     'IRQ' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define IRQ_SC                         (IRQ->SC)

/* ================================================================================ */
/* ================           KBI0 (file:KBI0_MKE)                 ================ */
/* ================================================================================ */

/**
 * @brief Keyboard interrupts (KBI0)
 */
typedef struct {                                /*!<       KBI0 Structure                                               */
   __IO uint8_t   SC;                           /*!< 0000: KBI Status and Control Register                              */
   __IO uint8_t   PE;                           /*!< 0001: KBI Pin Enable Register                                      */
   __IO uint8_t   ES;                           /*!< 0002: KBI Edge Select Register                                     */
} KBI0_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'KBI0' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- KBI0_SC                                  ------ */
#define KBI0_SC_KBMOD_MASK                       (0x01UL << KBI0_SC_KBMOD_SHIFT)                     /*!< KBI0_SC: KBMOD Mask                     */
#define KBI0_SC_KBMOD_SHIFT                      0                                                   /*!< KBI0_SC: KBMOD Position                 */
#define KBI0_SC_KBIE_MASK                        (0x01UL << KBI0_SC_KBIE_SHIFT)                      /*!< KBI0_SC: KBIE Mask                      */
#define KBI0_SC_KBIE_SHIFT                       1                                                   /*!< KBI0_SC: KBIE Position                  */
#define KBI0_SC_KBACK_MASK                       (0x01UL << KBI0_SC_KBACK_SHIFT)                     /*!< KBI0_SC: KBACK Mask                     */
#define KBI0_SC_KBACK_SHIFT                      2                                                   /*!< KBI0_SC: KBACK Position                 */
#define KBI0_SC_KBF_MASK                         (0x01UL << KBI0_SC_KBF_SHIFT)                       /*!< KBI0_SC: KBF Mask                       */
#define KBI0_SC_KBF_SHIFT                        3                                                   /*!< KBI0_SC: KBF Position                   */

/* ------- KBI0_PE                                  ------ */
#define KBI0_PE_KBIPE_MASK                       (0x01UL << KBI0_PE_KBIPE_SHIFT)                     /*!< KBI0_PE: KBIPE Mask                     */
#define KBI0_PE_KBIPE_SHIFT                      0                                                   /*!< KBI0_PE: KBIPE Position                 */

/* ------- KBI0_ES                                  ------ */
#define KBI0_ES_KBEDG_MASK                       (0x01UL << KBI0_ES_KBEDG_SHIFT)                     /*!< KBI0_ES: KBEDG Mask                     */
#define KBI0_ES_KBEDG_SHIFT                      0                                                   /*!< KBI0_ES: KBEDG Position                 */

/* -------------------------------------------------------------------------------- */
/* -----------     'KBI0' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define KBI0_SC                        (KBI0->SC)
#define KBI0_PE                        (KBI0->PE)
#define KBI0_ES                        (KBI0->ES)

/* ================================================================================ */
/* ================           KBI1 (derived from KBI0)             ================ */
/* ================================================================================ */

/**
 * @brief Keyboard interrupts (KBI1)
 */
typedef KBI0_Type KBI1_Type;  /*!< KBI1 Structure                                              */


/* -------------------------------------------------------------------------------- */
/* -----------     'KBI1' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define KBI1_SC                        (KBI1->SC)
#define KBI1_PE                        (KBI1->PE)
#define KBI1_ES                        (KBI1->ES)

/* ================================================================================ */
/* ================           MCM (file:MCM_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Core Platform Miscellaneous Control Module (MCM)
 */
typedef struct {                                /*!<       MCM Structure                                                */
   __I  uint32_t  RESERVED0[2];                 /*!< 0000:                                                              */
   __I  uint16_t  PLASC;                        /*!< 0008: Crossbar Switch (AXBS) Slave Configuration                   */
   __I  uint16_t  PLAMC;                        /*!< 000A: Crossbar Switch (AXBS) Master Configuration                  */
   __IO uint32_t  PLACR;                        /*!< 000C: Platform Control Register                                    */
} MCM_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'MCM' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- MCM_PLASC                                ------ */
#define MCM_PLASC_ASC_MASK                       (0xFFUL << MCM_PLASC_ASC_SHIFT)                     /*!< MCM_PLASC: ASC Mask                     */
#define MCM_PLASC_ASC_SHIFT                      0                                                   /*!< MCM_PLASC: ASC Position                 */
#define MCM_PLASC_ASC(x)                         (((x)<<MCM_PLASC_ASC_SHIFT)&MCM_PLASC_ASC_MASK)     /*!< MCM_PLASC                               */

/* ------- MCM_PLAMC                                ------ */
#define MCM_PLAMC_AMC_MASK                       (0xFFUL << MCM_PLAMC_AMC_SHIFT)                     /*!< MCM_PLAMC: AMC Mask                     */
#define MCM_PLAMC_AMC_SHIFT                      0                                                   /*!< MCM_PLAMC: AMC Position                 */
#define MCM_PLAMC_AMC(x)                         (((x)<<MCM_PLAMC_AMC_SHIFT)&MCM_PLAMC_AMC_MASK)     /*!< MCM_PLAMC                               */

/* ------- MCM_PLACR                                ------ */
#define MCM_PLACR_CFCC_MASK                      (0x01UL << MCM_PLACR_CFCC_SHIFT)                    /*!< MCM_PLACR: CFCC Mask                    */
#define MCM_PLACR_CFCC_SHIFT                     10                                                  /*!< MCM_PLACR: CFCC Position                */
#define MCM_PLACR_DFCDA_MASK                     (0x01UL << MCM_PLACR_DFCDA_SHIFT)                   /*!< MCM_PLACR: DFCDA Mask                   */
#define MCM_PLACR_DFCDA_SHIFT                    11                                                  /*!< MCM_PLACR: DFCDA Position               */
#define MCM_PLACR_DFCIC_MASK                     (0x01UL << MCM_PLACR_DFCIC_SHIFT)                   /*!< MCM_PLACR: DFCIC Mask                   */
#define MCM_PLACR_DFCIC_SHIFT                    12                                                  /*!< MCM_PLACR: DFCIC Position               */
#define MCM_PLACR_DFCC_MASK                      (0x01UL << MCM_PLACR_DFCC_SHIFT)                    /*!< MCM_PLACR: DFCC Mask                    */
#define MCM_PLACR_DFCC_SHIFT                     13                                                  /*!< MCM_PLACR: DFCC Position                */
#define MCM_PLACR_EFDS_MASK                      (0x01UL << MCM_PLACR_EFDS_SHIFT)                    /*!< MCM_PLACR: EFDS Mask                    */
#define MCM_PLACR_EFDS_SHIFT                     14                                                  /*!< MCM_PLACR: EFDS Position                */
#define MCM_PLACR_DFCS_MASK                      (0x01UL << MCM_PLACR_DFCS_SHIFT)                    /*!< MCM_PLACR: DFCS Mask                    */
#define MCM_PLACR_DFCS_SHIFT                     15                                                  /*!< MCM_PLACR: DFCS Position                */
#define MCM_PLACR_ESFC_MASK                      (0x01UL << MCM_PLACR_ESFC_SHIFT)                    /*!< MCM_PLACR: ESFC Mask                    */
#define MCM_PLACR_ESFC_SHIFT                     16                                                  /*!< MCM_PLACR: ESFC Position                */

/* -------------------------------------------------------------------------------- */
/* -----------     'MCM' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define MCM_PLASC                      (MCM->PLASC)
#define MCM_PLAMC                      (MCM->PLAMC)
#define MCM_PLACR                      (MCM->PLACR)

/* ================================================================================ */
/* ================           NV (file:NV_MKE)                     ================ */
/* ================================================================================ */

/**
 * @brief Flash configuration field
 */
typedef struct {                                /*!<       NV Structure                                                 */
   __I  uint8_t   BACKKEY[8];                   /*!< 0000: Backdoor Comparison Key                                      */
   __I  uint32_t  RESERVED0;                    /*!< 0008:                                                              */
   __I  uint8_t   EEPROT;                       /*!< 000C: Non-volatile EE-Flash Protection Register                    */
   __I  uint8_t   FPROT;                        /*!< 000D: Non-volatile P-Flash Protection Register                     */
   __I  uint8_t   FSEC;                         /*!< 000E: Non-volatile Flash Security Register                         */
   __I  uint8_t   FOPT;                         /*!< 000F: Non-volatile Flash Option Register                           */
} NV_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'NV' Position & Mask macros                          ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- NV_BACKKEY                               ------ */
#define NV_BACKKEY_KEY_MASK                      (0xFFUL << NV_BACKKEY_KEY_SHIFT)                    /*!< NV_BACKKEY: KEY Mask                    */
#define NV_BACKKEY_KEY_SHIFT                     0                                                   /*!< NV_BACKKEY: KEY Position                */
#define NV_BACKKEY_KEY(x)                        (((x)<<NV_BACKKEY_KEY_SHIFT)&NV_BACKKEY_KEY_MASK)   /*!< NV_BACKKEY                              */

/* ------- NV_EEPROT                                ------ */
#define NV_EEPROT_PROT_MASK                      (0xFFUL << NV_EEPROT_PROT_SHIFT)                    /*!< NV_EEPROT: PROT Mask                    */
#define NV_EEPROT_PROT_SHIFT                     0                                                   /*!< NV_EEPROT: PROT Position                */
#define NV_EEPROT_PROT(x)                        (((x)<<NV_EEPROT_PROT_SHIFT)&NV_EEPROT_PROT_MASK)   /*!< NV_EEPROT                               */

/* ------- NV_FPROT                                 ------ */
#define NV_FPROT_PROT_MASK                       (0xFFUL << NV_FPROT_PROT_SHIFT)                     /*!< NV_FPROT: PROT Mask                     */
#define NV_FPROT_PROT_SHIFT                      0                                                   /*!< NV_FPROT: PROT Position                 */
#define NV_FPROT_PROT(x)                         (((x)<<NV_FPROT_PROT_SHIFT)&NV_FPROT_PROT_MASK)     /*!< NV_FPROT                                */

/* ------- NV_FSEC                                  ------ */
#define NV_FSEC_SEC_MASK                         (0x03UL << NV_FSEC_SEC_SHIFT)                       /*!< NV_FSEC: SEC Mask                       */
#define NV_FSEC_SEC_SHIFT                        0                                                   /*!< NV_FSEC: SEC Position                   */
#define NV_FSEC_SEC(x)                           (((x)<<NV_FSEC_SEC_SHIFT)&NV_FSEC_SEC_MASK)         /*!< NV_FSEC                                 */
#define NV_FSEC_FSLACC_MASK                      (0x03UL << NV_FSEC_FSLACC_SHIFT)                    /*!< NV_FSEC: FSLACC Mask                    */
#define NV_FSEC_FSLACC_SHIFT                     2                                                   /*!< NV_FSEC: FSLACC Position                */
#define NV_FSEC_FSLACC(x)                        (((x)<<NV_FSEC_FSLACC_SHIFT)&NV_FSEC_FSLACC_MASK)   /*!< NV_FSEC                                 */
#define NV_FSEC_MEEN_MASK                        (0x03UL << NV_FSEC_MEEN_SHIFT)                      /*!< NV_FSEC: MEEN Mask                      */
#define NV_FSEC_MEEN_SHIFT                       4                                                   /*!< NV_FSEC: MEEN Position                  */
#define NV_FSEC_MEEN(x)                          (((x)<<NV_FSEC_MEEN_SHIFT)&NV_FSEC_MEEN_MASK)       /*!< NV_FSEC                                 */
#define NV_FSEC_KEYEN_MASK                       (0x03UL << NV_FSEC_KEYEN_SHIFT)                     /*!< NV_FSEC: KEYEN Mask                     */
#define NV_FSEC_KEYEN_SHIFT                      6                                                   /*!< NV_FSEC: KEYEN Position                 */
#define NV_FSEC_KEYEN(x)                         (((x)<<NV_FSEC_KEYEN_SHIFT)&NV_FSEC_KEYEN_MASK)     /*!< NV_FSEC                                 */

/* ------- NV_FOPT                                  ------ */
#define NV_FOPT_LPBOOT0_MASK                     (0x01UL << NV_FOPT_LPBOOT0_SHIFT)                   /*!< NV_FOPT: LPBOOT0 Mask                   */
#define NV_FOPT_LPBOOT0_SHIFT                    0                                                   /*!< NV_FOPT: LPBOOT0 Position               */
#define NV_FOPT_NMI_DIS_MASK                     (0x01UL << NV_FOPT_NMI_DIS_SHIFT)                   /*!< NV_FOPT: NMI_DIS Mask                   */
#define NV_FOPT_NMI_DIS_SHIFT                    2                                                   /*!< NV_FOPT: NMI_DIS Position               */
#define NV_FOPT_RESET_PIN_CFG_MASK               (0x01UL << NV_FOPT_RESET_PIN_CFG_SHIFT)             /*!< NV_FOPT: RESET_PIN_CFG Mask             */
#define NV_FOPT_RESET_PIN_CFG_SHIFT              3                                                   /*!< NV_FOPT: RESET_PIN_CFG Position         */
#define NV_FOPT_LPBOOT1_MASK                     (0x01UL << NV_FOPT_LPBOOT1_SHIFT)                   /*!< NV_FOPT: LPBOOT1 Mask                   */
#define NV_FOPT_LPBOOT1_SHIFT                    4                                                   /*!< NV_FOPT: LPBOOT1 Position               */
#define NV_FOPT_FAST_INIT_MASK                   (0x01UL << NV_FOPT_FAST_INIT_SHIFT)                 /*!< NV_FOPT: FAST_INIT Mask                 */
#define NV_FOPT_FAST_INIT_SHIFT                  5                                                   /*!< NV_FOPT: FAST_INIT Position             */

/* -------------------------------------------------------------------------------- */
/* -----------     'NV' Register Access macros                          ----------- */
/* -------------------------------------------------------------------------------- */

#define NV_BACKKEY0                    (NV->BACKKEY[0])
#define NV_BACKKEY1                    (NV->BACKKEY[1])
#define NV_BACKKEY2                    (NV->BACKKEY[2])
#define NV_BACKKEY3                    (NV->BACKKEY[3])
#define NV_BACKKEY4                    (NV->BACKKEY[4])
#define NV_BACKKEY5                    (NV->BACKKEY[5])
#define NV_BACKKEY6                    (NV->BACKKEY[6])
#define NV_BACKKEY7                    (NV->BACKKEY[7])
#define NV_EEPROT                      (NV->EEPROT)
#define NV_FPROT                       (NV->FPROT)
#define NV_FSEC                        (NV->FSEC)
#define NV_FOPT                        (NV->FOPT)

/* ================================================================================ */
/* ================           OSC (file:OSC_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Oscillator (OSC)
 */
typedef struct {                                /*!<       OSC Structure                                                */
   __IO uint8_t   CR;                           /*!< 0000: OSC Control Register                                         */
} OSC_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'OSC' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- OSC_CR                                   ------ */
#define OSC_CR_OSCINIT_MASK                      (0x01UL << OSC_CR_OSCINIT_SHIFT)                    /*!< OSC_CR: OSCINIT Mask                    */
#define OSC_CR_OSCINIT_SHIFT                     0                                                   /*!< OSC_CR: OSCINIT Position                */
#define OSC_CR_HGO_MASK                          (0x01UL << OSC_CR_HGO_SHIFT)                        /*!< OSC_CR: HGO Mask                        */
#define OSC_CR_HGO_SHIFT                         1                                                   /*!< OSC_CR: HGO Position                    */
#define OSC_CR_RANGE_MASK                        (0x01UL << OSC_CR_RANGE_SHIFT)                      /*!< OSC_CR: RANGE Mask                      */
#define OSC_CR_RANGE_SHIFT                       2                                                   /*!< OSC_CR: RANGE Position                  */
#define OSC_CR_OSCOS_MASK                        (0x01UL << OSC_CR_OSCOS_SHIFT)                      /*!< OSC_CR: OSCOS Mask                      */
#define OSC_CR_OSCOS_SHIFT                       4                                                   /*!< OSC_CR: OSCOS Position                  */
#define OSC_CR_OSCSTEN_MASK                      (0x01UL << OSC_CR_OSCSTEN_SHIFT)                    /*!< OSC_CR: OSCSTEN Mask                    */
#define OSC_CR_OSCSTEN_SHIFT                     5                                                   /*!< OSC_CR: OSCSTEN Position                */
#define OSC_CR_OSCEN_MASK                        (0x00UL << OSC_CR_OSCEN_SHIFT)                      /*!< OSC_CR: OSCEN Mask                      */
#define OSC_CR_OSCEN_SHIFT                       7                                                   /*!< OSC_CR: OSCEN Position                  */

/* -------------------------------------------------------------------------------- */
/* -----------     'OSC' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define OSC_CR                         (OSC->CR)

/* ================================================================================ */
/* ================           PIT (file:PIT_2CH_CHAIN)             ================ */
/* ================================================================================ */

/**
 * @brief Periodic Interrupt Timer (2 channels)
 */
typedef struct {                                /*!<       PIT Structure                                                */
   __IO uint32_t  MCR;                          /*!< 0000: PIT Module Control Register                                  */
   __I  uint32_t  RESERVED0[63];                /*!< 0004:                                                              */
   struct { /* (cluster) */                     /*!< 0100: (size=0x0020, 32)                                            */
      __IO uint32_t  LDVAL;                     /*!< 0100: Timer Load Value Register                                    */
      __I  uint32_t  CVAL;                      /*!< 0104: Current Timer Value Register                                 */
      __IO uint32_t  TCTRL;                     /*!< 0108: Timer Control Register                                       */
      __IO uint32_t  TFLG;                      /*!< 010C: Timer Flag Register                                          */
   } CS[2];
} PIT_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'PIT' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- PIT_MCR                                  ------ */
#define PIT_MCR_FRZ_MASK                         (0x01UL << PIT_MCR_FRZ_SHIFT)                       /*!< PIT_MCR: FRZ Mask                       */
#define PIT_MCR_FRZ_SHIFT                        0                                                   /*!< PIT_MCR: FRZ Position                   */
#define PIT_MCR_MDIS_MASK                        (0x01UL << PIT_MCR_MDIS_SHIFT)                      /*!< PIT_MCR: MDIS Mask                      */
#define PIT_MCR_MDIS_SHIFT                       1                                                   /*!< PIT_MCR: MDIS Position                  */

/* ------- PIT_LDVAL                                ------ */
#define PIT_LDVAL_TSV_MASK                       (0xFFFFFFFFUL << PIT_LDVAL_TSV_SHIFT)               /*!< PIT_LDVAL: TSV Mask                     */
#define PIT_LDVAL_TSV_SHIFT                      0                                                   /*!< PIT_LDVAL: TSV Position                 */
#define PIT_LDVAL_TSV(x)                         (((x)<<PIT_LDVAL_TSV_SHIFT)&PIT_LDVAL_TSV_MASK)     /*!< PIT_LDVAL                               */

/* ------- PIT_CVAL                                 ------ */
#define PIT_CVAL_TVL_MASK                        (0xFFFFFFFFUL << PIT_CVAL_TVL_SHIFT)                /*!< PIT_CVAL: TVL Mask                      */
#define PIT_CVAL_TVL_SHIFT                       0                                                   /*!< PIT_CVAL: TVL Position                  */
#define PIT_CVAL_TVL(x)                          (((x)<<PIT_CVAL_TVL_SHIFT)&PIT_CVAL_TVL_MASK)       /*!< PIT_CVAL                                */

/* ------- PIT_TCTRL                                ------ */
#define PIT_TCTRL_TEN_MASK                       (0x01UL << PIT_TCTRL_TEN_SHIFT)                     /*!< PIT_TCTRL: TEN Mask                     */
#define PIT_TCTRL_TEN_SHIFT                      0                                                   /*!< PIT_TCTRL: TEN Position                 */
#define PIT_TCTRL_TIE_MASK                       (0x01UL << PIT_TCTRL_TIE_SHIFT)                     /*!< PIT_TCTRL: TIE Mask                     */
#define PIT_TCTRL_TIE_SHIFT                      1                                                   /*!< PIT_TCTRL: TIE Position                 */
#define PIT_TCTRL_CHN_MASK                       (0x01UL << PIT_TCTRL_CHN_SHIFT)                     /*!< PIT_TCTRL: CHN Mask                     */
#define PIT_TCTRL_CHN_SHIFT                      2                                                   /*!< PIT_TCTRL: CHN Position                 */

/* ------- PIT_TFLG                                 ------ */
#define PIT_TFLG_TIF_MASK                        (0x01UL << PIT_TFLG_TIF_SHIFT)                      /*!< PIT_TFLG: TIF Mask                      */
#define PIT_TFLG_TIF_SHIFT                       0                                                   /*!< PIT_TFLG: TIF Position                  */

/* -------------------------------------------------------------------------------- */
/* -----------     'PIT' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define PIT_MCR                        (PIT->MCR)
#define PIT_LDVAL0                     (PIT->CS[0].LDVAL)
#define PIT_CVAL0                      (PIT->CS[0].CVAL)
#define PIT_TCTRL0                     (PIT->CS[0].TCTRL)
#define PIT_TFLG0                      (PIT->CS[0].TFLG)
#define PIT_LDVAL1                     (PIT->CS[1].LDVAL)
#define PIT_CVAL1                      (PIT->CS[1].CVAL)
#define PIT_TCTRL1                     (PIT->CS[1].TCTRL)
#define PIT_TFLG1                      (PIT->CS[1].TFLG)

/* ================================================================================ */
/* ================           PMC (file:PMC_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Power Management Controller (PMC)
 */
typedef struct {                                /*!<       PMC Structure                                                */
   __IO uint8_t   SPMSC1;                       /*!< 0000: Low Voltage Detect Status and Control 1 Register             */
   __IO uint8_t   SPMSC2;                       /*!< 0001: Low Voltage Detect Status and Control 2 Register             */
} PMC_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'PMC' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- PMC_SPMSC1                               ------ */
#define PMC_SPMSC1_BGBE_MASK                     (0x01UL << PMC_SPMSC1_BGBE_SHIFT)                   /*!< PMC_SPMSC1: BGBE Mask                   */
#define PMC_SPMSC1_BGBE_SHIFT                    0                                                   /*!< PMC_SPMSC1: BGBE Position               */
#define PMC_SPMSC1_LVDE_MASK                     (0x01UL << PMC_SPMSC1_LVDE_SHIFT)                   /*!< PMC_SPMSC1: LVDE Mask                   */
#define PMC_SPMSC1_LVDE_SHIFT                    2                                                   /*!< PMC_SPMSC1: LVDE Position               */
#define PMC_SPMSC1_LVDSE_MASK                    (0x01UL << PMC_SPMSC1_LVDSE_SHIFT)                  /*!< PMC_SPMSC1: LVDSE Mask                  */
#define PMC_SPMSC1_LVDSE_SHIFT                   3                                                   /*!< PMC_SPMSC1: LVDSE Position              */
#define PMC_SPMSC1_LVDRE_MASK                    (0x01UL << PMC_SPMSC1_LVDRE_SHIFT)                  /*!< PMC_SPMSC1: LVDRE Mask                  */
#define PMC_SPMSC1_LVDRE_SHIFT                   4                                                   /*!< PMC_SPMSC1: LVDRE Position              */
#define PMC_SPMSC1_LVWIE_MASK                    (0x01UL << PMC_SPMSC1_LVWIE_SHIFT)                  /*!< PMC_SPMSC1: LVWIE Mask                  */
#define PMC_SPMSC1_LVWIE_SHIFT                   5                                                   /*!< PMC_SPMSC1: LVWIE Position              */
#define PMC_SPMSC1_LVWACK_MASK                   (0x01UL << PMC_SPMSC1_LVWACK_SHIFT)                 /*!< PMC_SPMSC1: LVWACK Mask                 */
#define PMC_SPMSC1_LVWACK_SHIFT                  6                                                   /*!< PMC_SPMSC1: LVWACK Position             */
#define PMC_SPMSC1_LVWF_MASK                     (0x01UL << PMC_SPMSC1_LVWF_SHIFT)                   /*!< PMC_SPMSC1: LVWF Mask                   */
#define PMC_SPMSC1_LVWF_SHIFT                    7                                                   /*!< PMC_SPMSC1: LVWF Position               */

/* ------- PMC_SPMSC2                               ------ */
#define PMC_SPMSC2_LVWV_MASK                     (0x03UL << PMC_SPMSC2_LVWV_SHIFT)                   /*!< PMC_SPMSC2: LVWV Mask                   */
#define PMC_SPMSC2_LVWV_SHIFT                    4                                                   /*!< PMC_SPMSC2: LVWV Position               */
#define PMC_SPMSC2_LVWV(x)                       (((x)<<PMC_SPMSC2_LVWV_SHIFT)&PMC_SPMSC2_LVWV_MASK) /*!< PMC_SPMSC2                              */
#define PMC_SPMSC2_LVDV_MASK                     (0x01UL << PMC_SPMSC2_LVDV_SHIFT)                   /*!< PMC_SPMSC2: LVDV Mask                   */
#define PMC_SPMSC2_LVDV_SHIFT                    6                                                   /*!< PMC_SPMSC2: LVDV Position               */

/* -------------------------------------------------------------------------------- */
/* -----------     'PMC' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define PMC_SPMSC1                     (PMC->SPMSC1)
#define PMC_SPMSC2                     (PMC->SPMSC2)

/* ================================================================================ */
/* ================           PORT (file:PORT_MKE)                 ================ */
/* ================================================================================ */

/**
 * @brief Port control (PORT)
 */
typedef struct {                                /*!<       PORT Structure                                               */
   __IO uint32_t  IOFLT;                        /*!< 0000: Port Filter Register                                         */
   __IO uint32_t  PUEL;                         /*!< 0004: Port Pull-up Enable Low Register                             */
   __IO uint32_t  PUEH;                         /*!< 0008: Port Pull-up Enable High Register                            */
   __IO uint32_t  HDRVE;                        /*!< 000C: Port High Drive Enable Register                              */
} PORT_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'PORT' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- PORT_IOFLT                               ------ */
#define PORT_IOFLT_FLTA_MASK                     (0x03UL << PORT_IOFLT_FLTA_SHIFT)                   /*!< PORT_IOFLT: FLTA Mask                   */
#define PORT_IOFLT_FLTA_SHIFT                    0                                                   /*!< PORT_IOFLT: FLTA Position               */
#define PORT_IOFLT_FLTA(x)                       (((x)<<PORT_IOFLT_FLTA_SHIFT)&PORT_IOFLT_FLTA_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTB_MASK                     (0x03UL << PORT_IOFLT_FLTB_SHIFT)                   /*!< PORT_IOFLT: FLTB Mask                   */
#define PORT_IOFLT_FLTB_SHIFT                    2                                                   /*!< PORT_IOFLT: FLTB Position               */
#define PORT_IOFLT_FLTB(x)                       (((x)<<PORT_IOFLT_FLTB_SHIFT)&PORT_IOFLT_FLTB_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTC_MASK                     (0x03UL << PORT_IOFLT_FLTC_SHIFT)                   /*!< PORT_IOFLT: FLTC Mask                   */
#define PORT_IOFLT_FLTC_SHIFT                    4                                                   /*!< PORT_IOFLT: FLTC Position               */
#define PORT_IOFLT_FLTC(x)                       (((x)<<PORT_IOFLT_FLTC_SHIFT)&PORT_IOFLT_FLTC_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTD_MASK                     (0x03UL << PORT_IOFLT_FLTD_SHIFT)                   /*!< PORT_IOFLT: FLTD Mask                   */
#define PORT_IOFLT_FLTD_SHIFT                    6                                                   /*!< PORT_IOFLT: FLTD Position               */
#define PORT_IOFLT_FLTD(x)                       (((x)<<PORT_IOFLT_FLTD_SHIFT)&PORT_IOFLT_FLTD_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTE_MASK                     (0x03UL << PORT_IOFLT_FLTE_SHIFT)                   /*!< PORT_IOFLT: FLTE Mask                   */
#define PORT_IOFLT_FLTE_SHIFT                    8                                                   /*!< PORT_IOFLT: FLTE Position               */
#define PORT_IOFLT_FLTE(x)                       (((x)<<PORT_IOFLT_FLTE_SHIFT)&PORT_IOFLT_FLTE_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTF_MASK                     (0x03UL << PORT_IOFLT_FLTF_SHIFT)                   /*!< PORT_IOFLT: FLTF Mask                   */
#define PORT_IOFLT_FLTF_SHIFT                    10                                                  /*!< PORT_IOFLT: FLTF Position               */
#define PORT_IOFLT_FLTF(x)                       (((x)<<PORT_IOFLT_FLTF_SHIFT)&PORT_IOFLT_FLTF_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTG_MASK                     (0x03UL << PORT_IOFLT_FLTG_SHIFT)                   /*!< PORT_IOFLT: FLTG Mask                   */
#define PORT_IOFLT_FLTG_SHIFT                    12                                                  /*!< PORT_IOFLT: FLTG Position               */
#define PORT_IOFLT_FLTG(x)                       (((x)<<PORT_IOFLT_FLTG_SHIFT)&PORT_IOFLT_FLTG_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTH_MASK                     (0x03UL << PORT_IOFLT_FLTH_SHIFT)                   /*!< PORT_IOFLT: FLTH Mask                   */
#define PORT_IOFLT_FLTH_SHIFT                    14                                                  /*!< PORT_IOFLT: FLTH Position               */
#define PORT_IOFLT_FLTH(x)                       (((x)<<PORT_IOFLT_FLTH_SHIFT)&PORT_IOFLT_FLTH_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTRST_MASK                   (0x03UL << PORT_IOFLT_FLTRST_SHIFT)                 /*!< PORT_IOFLT: FLTRST Mask                 */
#define PORT_IOFLT_FLTRST_SHIFT                  16                                                  /*!< PORT_IOFLT: FLTRST Position             */
#define PORT_IOFLT_FLTRST(x)                     (((x)<<PORT_IOFLT_FLTRST_SHIFT)&PORT_IOFLT_FLTRST_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTKBI0_MASK                  (0x03UL << PORT_IOFLT_FLTKBI0_SHIFT)                /*!< PORT_IOFLT: FLTKBI0 Mask                */
#define PORT_IOFLT_FLTKBI0_SHIFT                 18                                                  /*!< PORT_IOFLT: FLTKBI0 Position            */
#define PORT_IOFLT_FLTKBI0(x)                    (((x)<<PORT_IOFLT_FLTKBI0_SHIFT)&PORT_IOFLT_FLTKBI0_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTKBI1_MASK                  (0x03UL << PORT_IOFLT_FLTKBI1_SHIFT)                /*!< PORT_IOFLT: FLTKBI1 Mask                */
#define PORT_IOFLT_FLTKBI1_SHIFT                 20                                                  /*!< PORT_IOFLT: FLTKBI1 Position            */
#define PORT_IOFLT_FLTKBI1(x)                    (((x)<<PORT_IOFLT_FLTKBI1_SHIFT)&PORT_IOFLT_FLTKBI1_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTNMI_MASK                   (0x03UL << PORT_IOFLT_FLTNMI_SHIFT)                 /*!< PORT_IOFLT: FLTNMI Mask                 */
#define PORT_IOFLT_FLTNMI_SHIFT                  22                                                  /*!< PORT_IOFLT: FLTNMI Position             */
#define PORT_IOFLT_FLTNMI(x)                     (((x)<<PORT_IOFLT_FLTNMI_SHIFT)&PORT_IOFLT_FLTNMI_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTDIV1_MASK                  (0x03UL << PORT_IOFLT_FLTDIV1_SHIFT)                /*!< PORT_IOFLT: FLTDIV1 Mask                */
#define PORT_IOFLT_FLTDIV1_SHIFT                 24                                                  /*!< PORT_IOFLT: FLTDIV1 Position            */
#define PORT_IOFLT_FLTDIV1(x)                    (((x)<<PORT_IOFLT_FLTDIV1_SHIFT)&PORT_IOFLT_FLTDIV1_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTDIV2_MASK                  (0x07UL << PORT_IOFLT_FLTDIV2_SHIFT)                /*!< PORT_IOFLT: FLTDIV2 Mask                */
#define PORT_IOFLT_FLTDIV2_SHIFT                 26                                                  /*!< PORT_IOFLT: FLTDIV2 Position            */
#define PORT_IOFLT_FLTDIV2(x)                    (((x)<<PORT_IOFLT_FLTDIV2_SHIFT)&PORT_IOFLT_FLTDIV2_MASK) /*!< PORT_IOFLT                              */
#define PORT_IOFLT_FLTDIV3_MASK                  (0x07UL << PORT_IOFLT_FLTDIV3_SHIFT)                /*!< PORT_IOFLT: FLTDIV3 Mask                */
#define PORT_IOFLT_FLTDIV3_SHIFT                 29                                                  /*!< PORT_IOFLT: FLTDIV3 Position            */
#define PORT_IOFLT_FLTDIV3(x)                    (((x)<<PORT_IOFLT_FLTDIV3_SHIFT)&PORT_IOFLT_FLTDIV3_MASK) /*!< PORT_IOFLT                              */

/* ------- PORT_PUEL                                ------ */
#define PORT_PUEL_PTAPE_MASK                     (0xFFUL << PORT_PUEL_PTAPE_SHIFT)                   /*!< PORT_PUEL: PTAPE Mask                   */
#define PORT_PUEL_PTAPE_SHIFT                    0                                                   /*!< PORT_PUEL: PTAPE Position               */
#define PORT_PUEL_PTAPE(x)                       (((x)<<PORT_PUEL_PTAPE_SHIFT)&PORT_PUEL_PTAPE_MASK) /*!< PORT_PUEL                               */
#define PORT_PUEL_PTBPE_MASK                     (0xFFUL << PORT_PUEL_PTBPE_SHIFT)                   /*!< PORT_PUEL: PTBPE Mask                   */
#define PORT_PUEL_PTBPE_SHIFT                    8                                                   /*!< PORT_PUEL: PTBPE Position               */
#define PORT_PUEL_PTBPE(x)                       (((x)<<PORT_PUEL_PTBPE_SHIFT)&PORT_PUEL_PTBPE_MASK) /*!< PORT_PUEL                               */
#define PORT_PUEL_PTCPE_MASK                     (0xFFUL << PORT_PUEL_PTCPE_SHIFT)                   /*!< PORT_PUEL: PTCPE Mask                   */
#define PORT_PUEL_PTCPE_SHIFT                    16                                                  /*!< PORT_PUEL: PTCPE Position               */
#define PORT_PUEL_PTCPE(x)                       (((x)<<PORT_PUEL_PTCPE_SHIFT)&PORT_PUEL_PTCPE_MASK) /*!< PORT_PUEL                               */
#define PORT_PUEL_PTDPE_MASK                     (0xFFUL << PORT_PUEL_PTDPE_SHIFT)                   /*!< PORT_PUEL: PTDPE Mask                   */
#define PORT_PUEL_PTDPE_SHIFT                    24                                                  /*!< PORT_PUEL: PTDPE Position               */
#define PORT_PUEL_PTDPE(x)                       (((x)<<PORT_PUEL_PTDPE_SHIFT)&PORT_PUEL_PTDPE_MASK) /*!< PORT_PUEL                               */

/* ------- PORT_PUEH                                ------ */
#define PORT_PUEH_PTEPE_MASK                     (0xFFUL << PORT_PUEH_PTEPE_SHIFT)                   /*!< PORT_PUEH: PTEPE Mask                   */
#define PORT_PUEH_PTEPE_SHIFT                    0                                                   /*!< PORT_PUEH: PTEPE Position               */
#define PORT_PUEH_PTEPE(x)                       (((x)<<PORT_PUEH_PTEPE_SHIFT)&PORT_PUEH_PTEPE_MASK) /*!< PORT_PUEH                               */
#define PORT_PUEH_PTFPE_MASK                     (0xFFUL << PORT_PUEH_PTFPE_SHIFT)                   /*!< PORT_PUEH: PTFPE Mask                   */
#define PORT_PUEH_PTFPE_SHIFT                    8                                                   /*!< PORT_PUEH: PTFPE Position               */
#define PORT_PUEH_PTFPE(x)                       (((x)<<PORT_PUEH_PTFPE_SHIFT)&PORT_PUEH_PTFPE_MASK) /*!< PORT_PUEH                               */
#define PORT_PUEH_PTGPE_MASK                     (0xFFUL << PORT_PUEH_PTGPE_SHIFT)                   /*!< PORT_PUEH: PTGPE Mask                   */
#define PORT_PUEH_PTGPE_SHIFT                    16                                                  /*!< PORT_PUEH: PTGPE Position               */
#define PORT_PUEH_PTGPE(x)                       (((x)<<PORT_PUEH_PTGPE_SHIFT)&PORT_PUEH_PTGPE_MASK) /*!< PORT_PUEH                               */
#define PORT_PUEH_PTHPE_MASK                     (0xFFUL << PORT_PUEH_PTHPE_SHIFT)                   /*!< PORT_PUEH: PTHPE Mask                   */
#define PORT_PUEH_PTHPE_SHIFT                    24                                                  /*!< PORT_PUEH: PTHPE Position               */
#define PORT_PUEH_PTHPE(x)                       (((x)<<PORT_PUEH_PTHPE_SHIFT)&PORT_PUEH_PTHPE_MASK) /*!< PORT_PUEH                               */

/* ------- PORT_HDRVE                               ------ */
#define PORT_HDRVE_PTB4_MASK                     (0x01UL << PORT_HDRVE_PTB4_SHIFT)                   /*!< PORT_HDRVE: PTB4 Mask                   */
#define PORT_HDRVE_PTB4_SHIFT                    0                                                   /*!< PORT_HDRVE: PTB4 Position               */
#define PORT_HDRVE_PTB5_MASK                     (0x01UL << PORT_HDRVE_PTB5_SHIFT)                   /*!< PORT_HDRVE: PTB5 Mask                   */
#define PORT_HDRVE_PTB5_SHIFT                    1                                                   /*!< PORT_HDRVE: PTB5 Position               */
#define PORT_HDRVE_PTD0_MASK                     (0x01UL << PORT_HDRVE_PTD0_SHIFT)                   /*!< PORT_HDRVE: PTD0 Mask                   */
#define PORT_HDRVE_PTD0_SHIFT                    2                                                   /*!< PORT_HDRVE: PTD0 Position               */
#define PORT_HDRVE_PTD1_MASK                     (0x01UL << PORT_HDRVE_PTD1_SHIFT)                   /*!< PORT_HDRVE: PTD1 Mask                   */
#define PORT_HDRVE_PTD1_SHIFT                    3                                                   /*!< PORT_HDRVE: PTD1 Position               */
#define PORT_HDRVE_PTE0_MASK                     (0x01UL << PORT_HDRVE_PTE0_SHIFT)                   /*!< PORT_HDRVE: PTE0 Mask                   */
#define PORT_HDRVE_PTE0_SHIFT                    4                                                   /*!< PORT_HDRVE: PTE0 Position               */
#define PORT_HDRVE_PTE1_MASK                     (0x01UL << PORT_HDRVE_PTE1_SHIFT)                   /*!< PORT_HDRVE: PTE1 Mask                   */
#define PORT_HDRVE_PTE1_SHIFT                    5                                                   /*!< PORT_HDRVE: PTE1 Position               */
#define PORT_HDRVE_PTH0_MASK                     (0x01UL << PORT_HDRVE_PTH0_SHIFT)                   /*!< PORT_HDRVE: PTH0 Mask                   */
#define PORT_HDRVE_PTH0_SHIFT                    6                                                   /*!< PORT_HDRVE: PTH0 Position               */
#define PORT_HDRVE_PTH1_MASK                     (0x01UL << PORT_HDRVE_PTH1_SHIFT)                   /*!< PORT_HDRVE: PTH1 Mask                   */
#define PORT_HDRVE_PTH1_SHIFT                    7                                                   /*!< PORT_HDRVE: PTH1 Position               */

/* -------------------------------------------------------------------------------- */
/* -----------     'PORT' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define PORT_IOFLT                     (PORT->IOFLT)
#define PORT_PUEL                      (PORT->PUEL)
#define PORT_PUEH                      (PORT->PUEH)
#define PORT_HDRVE                     (PORT->HDRVE)

/* ================================================================================ */
/* ================           RTC (file:RTC_MKE)                   ================ */
/* ================================================================================ */

/**
 * @brief Real-time counter (RTC)
 */
typedef struct {                                /*!<       RTC Structure                                                */
   __IO uint32_t  SC;                           /*!< 0000: RTC Status and Control Register                              */
   __IO uint32_t  MOD;                          /*!< 0004: RTC Modulo Register: Contains the modulo value used to reset the count to 0x0000 upon a compare match and set SC[RTIF] status field */
   __I  uint32_t  CNT;                          /*!< 0008: RTC Counter Register: Reset or writing different values to SC[RTCLKS] and SC[RTCPS] clear the count to 0x0000 */
} RTC_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'RTC' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- RTC_SC                                   ------ */
#define RTC_SC_RTCO_MASK                         (0x01UL << RTC_SC_RTCO_SHIFT)                       /*!< RTC_SC: RTCO Mask                       */
#define RTC_SC_RTCO_SHIFT                        4                                                   /*!< RTC_SC: RTCO Position                   */
#define RTC_SC_RTIE_MASK                         (0x01UL << RTC_SC_RTIE_SHIFT)                       /*!< RTC_SC: RTIE Mask                       */
#define RTC_SC_RTIE_SHIFT                        6                                                   /*!< RTC_SC: RTIE Position                   */
#define RTC_SC_RTIF_MASK                         (0x01UL << RTC_SC_RTIF_SHIFT)                       /*!< RTC_SC: RTIF Mask                       */
#define RTC_SC_RTIF_SHIFT                        7                                                   /*!< RTC_SC: RTIF Position                   */
#define RTC_SC_RTCPS_MASK                        (0x07UL << RTC_SC_RTCPS_SHIFT)                      /*!< RTC_SC: RTCPS Mask                      */
#define RTC_SC_RTCPS_SHIFT                       8                                                   /*!< RTC_SC: RTCPS Position                  */
#define RTC_SC_RTCPS(x)                          (((x)<<RTC_SC_RTCPS_SHIFT)&RTC_SC_RTCPS_MASK)       /*!< RTC_SC                                  */
#define RTC_SC_RTCLKS_MASK                       (0x03UL << RTC_SC_RTCLKS_SHIFT)                     /*!< RTC_SC: RTCLKS Mask                     */
#define RTC_SC_RTCLKS_SHIFT                      14                                                  /*!< RTC_SC: RTCLKS Position                 */
#define RTC_SC_RTCLKS(x)                         (((x)<<RTC_SC_RTCLKS_SHIFT)&RTC_SC_RTCLKS_MASK)     /*!< RTC_SC                                  */

/* ------- RTC_MOD                                  ------ */
#define RTC_MOD_MOD_MASK                         (0xFFFFUL << RTC_MOD_MOD_SHIFT)                     /*!< RTC_MOD: MOD Mask                       */
#define RTC_MOD_MOD_SHIFT                        0                                                   /*!< RTC_MOD: MOD Position                   */
#define RTC_MOD_MOD(x)                           (((x)<<RTC_MOD_MOD_SHIFT)&RTC_MOD_MOD_MASK)         /*!< RTC_MOD                                 */

/* ------- RTC_CNT                                  ------ */
#define RTC_CNT_CNT_MASK                         (0xFFFFUL << RTC_CNT_CNT_SHIFT)                     /*!< RTC_CNT: CNT Mask                       */
#define RTC_CNT_CNT_SHIFT                        0                                                   /*!< RTC_CNT: CNT Position                   */
#define RTC_CNT_CNT(x)                           (((x)<<RTC_CNT_CNT_SHIFT)&RTC_CNT_CNT_MASK)         /*!< RTC_CNT                                 */

/* -------------------------------------------------------------------------------- */
/* -----------     'RTC' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define RTC_SC                         (RTC->SC)
#define RTC_MOD                        (RTC->MOD)
#define RTC_CNT                        (RTC->CNT)

/* ================================================================================ */
/* ================           SIM (file:SIM_MKE02Z2)               ================ */
/* ================================================================================ */

/**
 * @brief System Integration Module
 */
typedef struct {                                /*!<       SIM Structure                                                */
   __IO uint32_t  SRSID;                        /*!< 0000: System Reset Status and ID Register                          */
   __IO uint32_t  SOPT;                         /*!< 0004: System Options Register                                      */
   __IO uint32_t  PINSEL;                       /*!< 0008: Pin Selection Register                                       */
   __IO uint32_t  SCGC;                         /*!< 000C: System Clock Gating Control Register                         */
   __IO uint32_t  UUIDL;                        /*!< 0010: Universally Unique Identifier Low Register                   */
   __IO uint32_t  UUIDH;                        /*!< 0014: Universally Unique Identifier High Register                  */
   __IO uint32_t  BUSDIV;                       /*!< 0018: BUS Clock Divider Register                                   */
} SIM_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'SIM' Position & Mask macros                         ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- SIM_SRSID                                ------ */
#define SIM_SRSID_LVD_MASK                       (0x01UL << SIM_SRSID_LVD_SHIFT)                     /*!< SIM_SRSID: LVD Mask                     */
#define SIM_SRSID_LVD_SHIFT                      1                                                   /*!< SIM_SRSID: LVD Position                 */
#define SIM_SRSID_LOC_MASK                       (0x01UL << SIM_SRSID_LOC_SHIFT)                     /*!< SIM_SRSID: LOC Mask                     */
#define SIM_SRSID_LOC_SHIFT                      2                                                   /*!< SIM_SRSID: LOC Position                 */
#define SIM_SRSID_WDOG_MASK                      (0x01UL << SIM_SRSID_WDOG_SHIFT)                    /*!< SIM_SRSID: WDOG Mask                    */
#define SIM_SRSID_WDOG_SHIFT                     5                                                   /*!< SIM_SRSID: WDOG Position                */
#define SIM_SRSID_PIN_MASK                       (0x01UL << SIM_SRSID_PIN_SHIFT)                     /*!< SIM_SRSID: PIN Mask                     */
#define SIM_SRSID_PIN_SHIFT                      6                                                   /*!< SIM_SRSID: PIN Position                 */
#define SIM_SRSID_POR_MASK                       (0x01UL << SIM_SRSID_POR_SHIFT)                     /*!< SIM_SRSID: POR Mask                     */
#define SIM_SRSID_POR_SHIFT                      7                                                   /*!< SIM_SRSID: POR Position                 */
#define SIM_SRSID_LOCKUP_MASK                    (0x01UL << SIM_SRSID_LOCKUP_SHIFT)                  /*!< SIM_SRSID: LOCKUP Mask                  */
#define SIM_SRSID_LOCKUP_SHIFT                   9                                                   /*!< SIM_SRSID: LOCKUP Position              */
#define SIM_SRSID_SW_MASK                        (0x01UL << SIM_SRSID_SW_SHIFT)                      /*!< SIM_SRSID: SW Mask                      */
#define SIM_SRSID_SW_SHIFT                       10                                                  /*!< SIM_SRSID: SW Position                  */
#define SIM_SRSID_MDMAP_MASK                     (0x01UL << SIM_SRSID_MDMAP_SHIFT)                   /*!< SIM_SRSID: MDMAP Mask                   */
#define SIM_SRSID_MDMAP_SHIFT                    11                                                  /*!< SIM_SRSID: MDMAP Position               */
#define SIM_SRSID_SACKERR_MASK                   (0x01UL << SIM_SRSID_SACKERR_SHIFT)                 /*!< SIM_SRSID: SACKERR Mask                 */
#define SIM_SRSID_SACKERR_SHIFT                  13                                                  /*!< SIM_SRSID: SACKERR Position             */
#define SIM_SRSID_PINID_MASK                     (0x0FUL << SIM_SRSID_PINID_SHIFT)                   /*!< SIM_SRSID: PINID Mask                   */
#define SIM_SRSID_PINID_SHIFT                    16                                                  /*!< SIM_SRSID: PINID Position               */
#define SIM_SRSID_PINID(x)                       (((x)<<SIM_SRSID_PINID_SHIFT)&SIM_SRSID_PINID_MASK) /*!< SIM_SRSID                               */
#define SIM_SRSID_REVID_MASK                     (0x0FUL << SIM_SRSID_REVID_SHIFT)                   /*!< SIM_SRSID: REVID Mask                   */
#define SIM_SRSID_REVID_SHIFT                    20                                                  /*!< SIM_SRSID: REVID Position               */
#define SIM_SRSID_REVID(x)                       (((x)<<SIM_SRSID_REVID_SHIFT)&SIM_SRSID_REVID_MASK) /*!< SIM_SRSID                               */
#define SIM_SRSID_SUBFAMID_MASK                  (0x0FUL << SIM_SRSID_SUBFAMID_SHIFT)                /*!< SIM_SRSID: SUBFAMID Mask                */
#define SIM_SRSID_SUBFAMID_SHIFT                 24                                                  /*!< SIM_SRSID: SUBFAMID Position            */
#define SIM_SRSID_SUBFAMID(x)                    (((x)<<SIM_SRSID_SUBFAMID_SHIFT)&SIM_SRSID_SUBFAMID_MASK) /*!< SIM_SRSID                               */
#define SIM_SRSID_FAMID_MASK                     (0x0FUL << SIM_SRSID_FAMID_SHIFT)                   /*!< SIM_SRSID: FAMID Mask                   */
#define SIM_SRSID_FAMID_SHIFT                    28                                                  /*!< SIM_SRSID: FAMID Position               */
#define SIM_SRSID_FAMID(x)                       (((x)<<SIM_SRSID_FAMID_SHIFT)&SIM_SRSID_FAMID_MASK) /*!< SIM_SRSID                               */

/* ------- SIM_SOPT                                 ------ */
#define SIM_SOPT_NMIE_MASK                       (0x01UL << SIM_SOPT_NMIE_SHIFT)                     /*!< SIM_SOPT: NMIE Mask                     */
#define SIM_SOPT_NMIE_SHIFT                      1                                                   /*!< SIM_SOPT: NMIE Position                 */
#define SIM_SOPT_RSTPE_MASK                      (0x01UL << SIM_SOPT_RSTPE_SHIFT)                    /*!< SIM_SOPT: RSTPE Mask                    */
#define SIM_SOPT_RSTPE_SHIFT                     2                                                   /*!< SIM_SOPT: RSTPE Position                */
#define SIM_SOPT_SWDE_MASK                       (0x01UL << SIM_SOPT_SWDE_SHIFT)                     /*!< SIM_SOPT: SWDE Mask                     */
#define SIM_SOPT_SWDE_SHIFT                      3                                                   /*!< SIM_SOPT: SWDE Position                 */
#define SIM_SOPT_ADHWT_MASK                      (0x03UL << SIM_SOPT_ADHWT_SHIFT)                    /*!< SIM_SOPT: ADHWT Mask                    */
#define SIM_SOPT_ADHWT_SHIFT                     8                                                   /*!< SIM_SOPT: ADHWT Position                */
#define SIM_SOPT_ADHWT(x)                        (((x)<<SIM_SOPT_ADHWT_SHIFT)&SIM_SOPT_ADHWT_MASK)   /*!< SIM_SOPT                                */
#define SIM_SOPT_RTCC_MASK                       (0x01UL << SIM_SOPT_RTCC_SHIFT)                     /*!< SIM_SOPT: RTCC Mask                     */
#define SIM_SOPT_RTCC_SHIFT                      10                                                  /*!< SIM_SOPT: RTCC Position                 */
#define SIM_SOPT_ACIC_MASK                       (0x01UL << SIM_SOPT_ACIC_SHIFT)                     /*!< SIM_SOPT: ACIC Mask                     */
#define SIM_SOPT_ACIC_SHIFT                      11                                                  /*!< SIM_SOPT: ACIC Position                 */
#define SIM_SOPT_RXDCE_MASK                      (0x01UL << SIM_SOPT_RXDCE_SHIFT)                    /*!< SIM_SOPT: RXDCE Mask                    */
#define SIM_SOPT_RXDCE_SHIFT                     12                                                  /*!< SIM_SOPT: RXDCE Position                */
#define SIM_SOPT_RXDFE_MASK                      (0x01UL << SIM_SOPT_RXDFE_SHIFT)                    /*!< SIM_SOPT: RXDFE Mask                    */
#define SIM_SOPT_RXDFE_SHIFT                     13                                                  /*!< SIM_SOPT: RXDFE Position                */
#define SIM_SOPT_FTMSYNC_MASK                    (0x01UL << SIM_SOPT_FTMSYNC_SHIFT)                  /*!< SIM_SOPT: FTMSYNC Mask                  */
#define SIM_SOPT_FTMSYNC_SHIFT                   14                                                  /*!< SIM_SOPT: FTMSYNC Position              */
#define SIM_SOPT_TXDME_MASK                      (0x01UL << SIM_SOPT_TXDME_SHIFT)                    /*!< SIM_SOPT: TXDME Mask                    */
#define SIM_SOPT_TXDME_SHIFT                     15                                                  /*!< SIM_SOPT: TXDME Position                */
#define SIM_SOPT_BUSREF_MASK                     (0x07UL << SIM_SOPT_BUSREF_SHIFT)                   /*!< SIM_SOPT: BUSREF Mask                   */
#define SIM_SOPT_BUSREF_SHIFT                    16                                                  /*!< SIM_SOPT: BUSREF Position               */
#define SIM_SOPT_BUSREF(x)                       (((x)<<SIM_SOPT_BUSREF_SHIFT)&SIM_SOPT_BUSREF_MASK) /*!< SIM_SOPT                                */
#define SIM_SOPT_CLKOE_MASK                      (0x01UL << SIM_SOPT_CLKOE_SHIFT)                    /*!< SIM_SOPT: CLKOE Mask                    */
#define SIM_SOPT_CLKOE_SHIFT                     19                                                  /*!< SIM_SOPT: CLKOE Position                */
#define SIM_SOPT_DLYACT_MASK                     (0x01UL << SIM_SOPT_DLYACT_SHIFT)                   /*!< SIM_SOPT: DLYACT Mask                   */
#define SIM_SOPT_DLYACT_SHIFT                    23                                                  /*!< SIM_SOPT: DLYACT Position               */
#define SIM_SOPT_DELAY_MASK                      (0xFFUL << SIM_SOPT_DELAY_SHIFT)                    /*!< SIM_SOPT: DELAY Mask                    */
#define SIM_SOPT_DELAY_SHIFT                     24                                                  /*!< SIM_SOPT: DELAY Position                */
#define SIM_SOPT_DELAY(x)                        (((x)<<SIM_SOPT_DELAY_SHIFT)&SIM_SOPT_DELAY_MASK)   /*!< SIM_SOPT                                */

/* ------- SIM_PINSEL                               ------ */
#define SIM_PINSEL_RTCPS_MASK                    (0x01UL << SIM_PINSEL_RTCPS_SHIFT)                  /*!< SIM_PINSEL: RTCPS Mask                  */
#define SIM_PINSEL_RTCPS_SHIFT                   4                                                   /*!< SIM_PINSEL: RTCPS Position              */
#define SIM_PINSEL_I2C0PS_MASK                   (0x01UL << SIM_PINSEL_I2C0PS_SHIFT)                 /*!< SIM_PINSEL: I2C0PS Mask                 */
#define SIM_PINSEL_I2C0PS_SHIFT                  5                                                   /*!< SIM_PINSEL: I2C0PS Position             */
#define SIM_PINSEL_SPI0PS_MASK                   (0x01UL << SIM_PINSEL_SPI0PS_SHIFT)                 /*!< SIM_PINSEL: SPI0PS Mask                 */
#define SIM_PINSEL_SPI0PS_SHIFT                  6                                                   /*!< SIM_PINSEL: SPI0PS Position             */
#define SIM_PINSEL_UART0PS_MASK                  (0x01UL << SIM_PINSEL_UART0PS_SHIFT)                /*!< SIM_PINSEL: UART0PS Mask                */
#define SIM_PINSEL_UART0PS_SHIFT                 7                                                   /*!< SIM_PINSEL: UART0PS Position            */
#define SIM_PINSEL_FTM0PS0_MASK                  (0x01UL << SIM_PINSEL_FTM0PS0_SHIFT)                /*!< SIM_PINSEL: FTM0PS0 Mask                */
#define SIM_PINSEL_FTM0PS0_SHIFT                 8                                                   /*!< SIM_PINSEL: FTM0PS0 Position            */
#define SIM_PINSEL_FTM0PS1_MASK                  (0x01UL << SIM_PINSEL_FTM0PS1_SHIFT)                /*!< SIM_PINSEL: FTM0PS1 Mask                */
#define SIM_PINSEL_FTM0PS1_SHIFT                 9                                                   /*!< SIM_PINSEL: FTM0PS1 Position            */
#define SIM_PINSEL_FTM1PS0_MASK                  (0x01UL << SIM_PINSEL_FTM1PS0_SHIFT)                /*!< SIM_PINSEL: FTM1PS0 Mask                */
#define SIM_PINSEL_FTM1PS0_SHIFT                 10                                                  /*!< SIM_PINSEL: FTM1PS0 Position            */
#define SIM_PINSEL_FTM1PS1_MASK                  (0x01UL << SIM_PINSEL_FTM1PS1_SHIFT)                /*!< SIM_PINSEL: FTM1PS1 Mask                */
#define SIM_PINSEL_FTM1PS1_SHIFT                 11                                                  /*!< SIM_PINSEL: FTM1PS1 Position            */
#define SIM_PINSEL_FTM2PS0_MASK                  (0x01UL << SIM_PINSEL_FTM2PS0_SHIFT)                /*!< SIM_PINSEL: FTM2PS0 Mask                */
#define SIM_PINSEL_FTM2PS0_SHIFT                 12                                                  /*!< SIM_PINSEL: FTM2PS0 Position            */
#define SIM_PINSEL_FTM2PS1_MASK                  (0x01UL << SIM_PINSEL_FTM2PS1_SHIFT)                /*!< SIM_PINSEL: FTM2PS1 Mask                */
#define SIM_PINSEL_FTM2PS1_SHIFT                 13                                                  /*!< SIM_PINSEL: FTM2PS1 Position            */
#define SIM_PINSEL_FTM2PS2_MASK                  (0x01UL << SIM_PINSEL_FTM2PS2_SHIFT)                /*!< SIM_PINSEL: FTM2PS2 Mask                */
#define SIM_PINSEL_FTM2PS2_SHIFT                 14                                                  /*!< SIM_PINSEL: FTM2PS2 Position            */
#define SIM_PINSEL_FTM2PS3_MASK                  (0x01UL << SIM_PINSEL_FTM2PS3_SHIFT)                /*!< SIM_PINSEL: FTM2PS3 Mask                */
#define SIM_PINSEL_FTM2PS3_SHIFT                 15                                                  /*!< SIM_PINSEL: FTM2PS3 Position            */

/* ------- SIM_SCGC                                 ------ */
#define SIM_SCGC_RTC_MASK                        (0x01UL << SIM_SCGC_RTC_SHIFT)                      /*!< SIM_SCGC: RTC Mask                      */
#define SIM_SCGC_RTC_SHIFT                       0                                                   /*!< SIM_SCGC: RTC Position                  */
#define SIM_SCGC_PIT_MASK                        (0x01UL << SIM_SCGC_PIT_SHIFT)                      /*!< SIM_SCGC: PIT Mask                      */
#define SIM_SCGC_PIT_SHIFT                       1                                                   /*!< SIM_SCGC: PIT Position                  */
#define SIM_SCGC_FTM0_MASK                       (0x01UL << SIM_SCGC_FTM0_SHIFT)                     /*!< SIM_SCGC: FTM0 Mask                     */
#define SIM_SCGC_FTM0_SHIFT                      5                                                   /*!< SIM_SCGC: FTM0 Position                 */
#define SIM_SCGC_FTM1_MASK                       (0x01UL << SIM_SCGC_FTM1_SHIFT)                     /*!< SIM_SCGC: FTM1 Mask                     */
#define SIM_SCGC_FTM1_SHIFT                      6                                                   /*!< SIM_SCGC: FTM1 Position                 */
#define SIM_SCGC_FTM2_MASK                       (0x01UL << SIM_SCGC_FTM2_SHIFT)                     /*!< SIM_SCGC: FTM2 Mask                     */
#define SIM_SCGC_FTM2_SHIFT                      7                                                   /*!< SIM_SCGC: FTM2 Position                 */
#define SIM_SCGC_CRC_MASK                        (0x01UL << SIM_SCGC_CRC_SHIFT)                      /*!< SIM_SCGC: CRC Mask                      */
#define SIM_SCGC_CRC_SHIFT                       10                                                  /*!< SIM_SCGC: CRC Position                  */
#define SIM_SCGC_FLASH_MASK                      (0x01UL << SIM_SCGC_FLASH_SHIFT)                    /*!< SIM_SCGC: FLASH Mask                    */
#define SIM_SCGC_FLASH_SHIFT                     12                                                  /*!< SIM_SCGC: FLASH Position                */
#define SIM_SCGC_SWD_MASK                        (0x01UL << SIM_SCGC_SWD_SHIFT)                      /*!< SIM_SCGC: SWD Mask                      */
#define SIM_SCGC_SWD_SHIFT                       13                                                  /*!< SIM_SCGC: SWD Position                  */
#define SIM_SCGC_I2C_MASK                        (0x01UL << SIM_SCGC_I2C_SHIFT)                      /*!< SIM_SCGC: I2C Mask                      */
#define SIM_SCGC_I2C_SHIFT                       17                                                  /*!< SIM_SCGC: I2C Position                  */
#define SIM_SCGC_SPI0_MASK                       (0x01UL << SIM_SCGC_SPI0_SHIFT)                     /*!< SIM_SCGC: SPI0 Mask                     */
#define SIM_SCGC_SPI0_SHIFT                      18                                                  /*!< SIM_SCGC: SPI0 Position                 */
#define SIM_SCGC_SPI1_MASK                       (0x01UL << SIM_SCGC_SPI1_SHIFT)                     /*!< SIM_SCGC: SPI1 Mask                     */
#define SIM_SCGC_SPI1_SHIFT                      19                                                  /*!< SIM_SCGC: SPI1 Position                 */
#define SIM_SCGC_UART0_MASK                      (0x01UL << SIM_SCGC_UART0_SHIFT)                    /*!< SIM_SCGC: UART0 Mask                    */
#define SIM_SCGC_UART0_SHIFT                     20                                                  /*!< SIM_SCGC: UART0 Position                */
#define SIM_SCGC_UART1_MASK                      (0x01UL << SIM_SCGC_UART1_SHIFT)                    /*!< SIM_SCGC: UART1 Mask                    */
#define SIM_SCGC_UART1_SHIFT                     21                                                  /*!< SIM_SCGC: UART1 Position                */
#define SIM_SCGC_UART2_MASK                      (0x01UL << SIM_SCGC_UART2_SHIFT)                    /*!< SIM_SCGC: UART2 Mask                    */
#define SIM_SCGC_UART2_SHIFT                     22                                                  /*!< SIM_SCGC: UART2 Position                */
#define SIM_SCGC_KBI0_MASK                       (0x01UL << SIM_SCGC_KBI0_SHIFT)                     /*!< SIM_SCGC: KBI0 Mask                     */
#define SIM_SCGC_KBI0_SHIFT                      24                                                  /*!< SIM_SCGC: KBI0 Position                 */
#define SIM_SCGC_KBI1_MASK                       (0x01UL << SIM_SCGC_KBI1_SHIFT)                     /*!< SIM_SCGC: KBI1 Mask                     */
#define SIM_SCGC_KBI1_SHIFT                      25                                                  /*!< SIM_SCGC: KBI1 Position                 */
#define SIM_SCGC_IRQ_MASK                        (0x01UL << SIM_SCGC_IRQ_SHIFT)                      /*!< SIM_SCGC: IRQ Mask                      */
#define SIM_SCGC_IRQ_SHIFT                       27                                                  /*!< SIM_SCGC: IRQ Position                  */
#define SIM_SCGC_ADC_MASK                        (0x01UL << SIM_SCGC_ADC_SHIFT)                      /*!< SIM_SCGC: ADC Mask                      */
#define SIM_SCGC_ADC_SHIFT                       29                                                  /*!< SIM_SCGC: ADC Position                  */
#define SIM_SCGC_ACMP2_MASK                      (0x01UL << SIM_SCGC_ACMP2_SHIFT)                    /*!< SIM_SCGC: ACMP2 Mask                    */
#define SIM_SCGC_ACMP2_SHIFT                     30                                                  /*!< SIM_SCGC: ACMP2 Position                */
#define SIM_SCGC_ACMP1_MASK                      (0x01UL << SIM_SCGC_ACMP1_SHIFT)                    /*!< SIM_SCGC: ACMP1 Mask                    */
#define SIM_SCGC_ACMP1_SHIFT                     31                                                  /*!< SIM_SCGC: ACMP1 Position                */

/* ------- SIM_UUIDL                                ------ */

/* ------- SIM_UUIDH                                ------ */

/* ------- SIM_BUSDIV                               ------ */
#define SIM_BUSDIV_BUSDIV_MASK                   (0x01UL << SIM_BUSDIV_BUSDIV_SHIFT)                 /*!< SIM_BUSDIV: BUSDIV Mask                 */
#define SIM_BUSDIV_BUSDIV_SHIFT                  0                                                   /*!< SIM_BUSDIV: BUSDIV Position             */

/* -------------------------------------------------------------------------------- */
/* -----------     'SIM' Register Access macros                         ----------- */
/* -------------------------------------------------------------------------------- */

#define SIM_SRSID                      (SIM->SRSID)
#define SIM_SOPT                       (SIM->SOPT)
#define SIM_PINSEL                     (SIM->PINSEL)
#define SIM_SCGC                       (SIM->SCGC)
#define SIM_UUIDL                      (SIM->UUIDL)
#define SIM_UUIDH                      (SIM->UUIDH)
#define SIM_BUSDIV                     (SIM->BUSDIV)

/* ================================================================================ */
/* ================           SPI0 (file:SPI0_MKE)                 ================ */
/* ================================================================================ */

/**
 * @brief Serial Peripheral Interface (SPI0)
 */
typedef struct {                                /*!<       SPI0 Structure                                               */
   __IO uint8_t   C1;                           /*!< 0000: SPI control register 1                                       */
   __IO uint8_t   C2;                           /*!< 0001: SPI control register 2                                       */
   __IO uint8_t   BR;                           /*!< 0002: SPI baud rate register BAUD = (Bus Clock)/Prescaler/Baud Rate Divisor */
   __I  uint8_t   S;                            /*!< 0003: SPI status register                                          */
   __I  uint8_t   RESERVED0;                    /*!< 0004:                                                              */
   __IO uint8_t   D;                            /*!< 0005: SPI data register                                            */
   __I  uint8_t   RESERVED1;                    /*!< 0006:                                                              */
   __IO uint8_t   M;                            /*!< 0007: SPI match register:                                          */
} SPI0_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'SPI0' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- SPI0_C1                                  ------ */
#define SPI_C1_LSBFE_MASK                        (0x01UL << SPI_C1_LSBFE_SHIFT)                      /*!< SPI0_C1: LSBFE Mask                     */
#define SPI_C1_LSBFE_SHIFT                       0                                                   /*!< SPI0_C1: LSBFE Position                 */
#define SPI_C1_SSOE_MASK                         (0x01UL << SPI_C1_SSOE_SHIFT)                       /*!< SPI0_C1: SSOE Mask                      */
#define SPI_C1_SSOE_SHIFT                        1                                                   /*!< SPI0_C1: SSOE Position                  */
#define SPI_C1_CPHA_MASK                         (0x01UL << SPI_C1_CPHA_SHIFT)                       /*!< SPI0_C1: CPHA Mask                      */
#define SPI_C1_CPHA_SHIFT                        2                                                   /*!< SPI0_C1: CPHA Position                  */
#define SPI_C1_CPOL_MASK                         (0x01UL << SPI_C1_CPOL_SHIFT)                       /*!< SPI0_C1: CPOL Mask                      */
#define SPI_C1_CPOL_SHIFT                        3                                                   /*!< SPI0_C1: CPOL Position                  */
#define SPI_C1_MSTR_MASK                         (0x01UL << SPI_C1_MSTR_SHIFT)                       /*!< SPI0_C1: MSTR Mask                      */
#define SPI_C1_MSTR_SHIFT                        4                                                   /*!< SPI0_C1: MSTR Position                  */
#define SPI_C1_SPTIE_MASK                        (0x01UL << SPI_C1_SPTIE_SHIFT)                      /*!< SPI0_C1: SPTIE Mask                     */
#define SPI_C1_SPTIE_SHIFT                       5                                                   /*!< SPI0_C1: SPTIE Position                 */
#define SPI_C1_SPE_MASK                          (0x01UL << SPI_C1_SPE_SHIFT)                        /*!< SPI0_C1: SPE Mask                       */
#define SPI_C1_SPE_SHIFT                         6                                                   /*!< SPI0_C1: SPE Position                   */
#define SPI_C1_SPIE_MASK                         (0x01UL << SPI_C1_SPIE_SHIFT)                       /*!< SPI0_C1: SPIE Mask                      */
#define SPI_C1_SPIE_SHIFT                        7                                                   /*!< SPI0_C1: SPIE Position                  */

/* ------- SPI0_C2                                  ------ */
#define SPI_C2_SPC0_MASK                         (0x01UL << SPI_C2_SPC0_SHIFT)                       /*!< SPI0_C2: SPC0 Mask                      */
#define SPI_C2_SPC0_SHIFT                        0                                                   /*!< SPI0_C2: SPC0 Position                  */
#define SPI_C2_SPISWAI_MASK                      (0x01UL << SPI_C2_SPISWAI_SHIFT)                    /*!< SPI0_C2: SPISWAI Mask                   */
#define SPI_C2_SPISWAI_SHIFT                     1                                                   /*!< SPI0_C2: SPISWAI Position               */
#define SPI_C2_BIDIROE_MASK                      (0x01UL << SPI_C2_BIDIROE_SHIFT)                    /*!< SPI0_C2: BIDIROE Mask                   */
#define SPI_C2_BIDIROE_SHIFT                     3                                                   /*!< SPI0_C2: BIDIROE Position               */
#define SPI_C2_MODFEN_MASK                       (0x01UL << SPI_C2_MODFEN_SHIFT)                     /*!< SPI0_C2: MODFEN Mask                    */
#define SPI_C2_MODFEN_SHIFT                      4                                                   /*!< SPI0_C2: MODFEN Position                */
#define SPI_C2_SPMIE_MASK                        (0x01UL << SPI_C2_SPMIE_SHIFT)                      /*!< SPI0_C2: SPMIE Mask                     */
#define SPI_C2_SPMIE_SHIFT                       7                                                   /*!< SPI0_C2: SPMIE Position                 */

/* ------- SPI0_BR                                  ------ */
#define SPI_BR_SPR_MASK                          (0x0FUL << SPI_BR_SPR_SHIFT)                        /*!< SPI0_BR: SPR Mask                       */
#define SPI_BR_SPR_SHIFT                         0                                                   /*!< SPI0_BR: SPR Position                   */
#define SPI_BR_SPR(x)                            (((x)<<SPI_BR_SPR_SHIFT)&SPI_BR_SPR_MASK)           /*!< SPI0_BR                                 */
#define SPI_BR_SPPR_MASK                         (0x07UL << SPI_BR_SPPR_SHIFT)                       /*!< SPI0_BR: SPPR Mask                      */
#define SPI_BR_SPPR_SHIFT                        4                                                   /*!< SPI0_BR: SPPR Position                  */
#define SPI_BR_SPPR(x)                           (((x)<<SPI_BR_SPPR_SHIFT)&SPI_BR_SPPR_MASK)         /*!< SPI0_BR                                 */

/* ------- SPI0_S                                   ------ */
#define SPI_S_MODF_MASK                          (0x01UL << SPI_S_MODF_SHIFT)                        /*!< SPI0_S: MODF Mask                       */
#define SPI_S_MODF_SHIFT                         4                                                   /*!< SPI0_S: MODF Position                   */
#define SPI_S_SPTEF_MASK                         (0x01UL << SPI_S_SPTEF_SHIFT)                       /*!< SPI0_S: SPTEF Mask                      */
#define SPI_S_SPTEF_SHIFT                        5                                                   /*!< SPI0_S: SPTEF Position                  */
#define SPI_S_SPMF_MASK                          (0x01UL << SPI_S_SPMF_SHIFT)                        /*!< SPI0_S: SPMF Mask                       */
#define SPI_S_SPMF_SHIFT                         6                                                   /*!< SPI0_S: SPMF Position                   */
#define SPI_S_SPRF_MASK                          (0x01UL << SPI_S_SPRF_SHIFT)                        /*!< SPI0_S: SPRF Mask                       */
#define SPI_S_SPRF_SHIFT                         7                                                   /*!< SPI0_S: SPRF Position                   */

/* ------- SPI0_D                                   ------ */
#define SPI_D_Bits_MASK                          (0xFFUL << SPI_D_Bits_SHIFT)                        /*!< SPI0_D: Bits Mask                       */
#define SPI_D_Bits_SHIFT                         0                                                   /*!< SPI0_D: Bits Position                   */
#define SPI_D_Bits(x)                            (((x)<<SPI_D_Bits_SHIFT)&SPI_D_Bits_MASK)           /*!< SPI0_D                                  */

/* ------- SPI0_M                                   ------ */
#define SPI_M_Bits_MASK                          (0xFFUL << SPI_M_Bits_SHIFT)                        /*!< SPI0_M: Bits Mask                       */
#define SPI_M_Bits_SHIFT                         0                                                   /*!< SPI0_M: Bits Position                   */
#define SPI_M_Bits(x)                            (((x)<<SPI_M_Bits_SHIFT)&SPI_M_Bits_MASK)           /*!< SPI0_M                                  */

/* -------------------------------------------------------------------------------- */
/* -----------     'SPI0' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define SPI0_C1                        (SPI0->C1)
#define SPI0_C2                        (SPI0->C2)
#define SPI0_BR                        (SPI0->BR)
#define SPI0_S                         (SPI0->S)
#define SPI0_D                         (SPI0->D)
#define SPI0_M                         (SPI0->M)

/* ================================================================================ */
/* ================           SPI1 (derived from SPI0)             ================ */
/* ================================================================================ */

/**
 * @brief Serial Peripheral Interface (SPI1)
 */
typedef SPI0_Type SPI1_Type;  /*!< SPI1 Structure                                              */


/* -------------------------------------------------------------------------------- */
/* -----------     'SPI1' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define SPI1_C1                        (SPI1->C1)
#define SPI1_C2                        (SPI1->C2)
#define SPI1_BR                        (SPI1->BR)
#define SPI1_S                         (SPI1->S)
#define SPI1_D                         (SPI1->D)
#define SPI1_M                         (SPI1->M)

/* ================================================================================ */
/* ================           UART0 (file:UART0_MKE)               ================ */
/* ================================================================================ */

/**
 * @brief Universal Asynchronous Receiver/Transmitter (UART)
 */
typedef struct {                                /*!<       UART0 Structure                                              */
   __IO uint8_t   BDH;                          /*!< 0000: UART Baud Rate Register: High                                */
   __IO uint8_t   BDL;                          /*!< 0001: UART Baud Rate Register: Low                                 */
   __IO uint8_t   C1;                           /*!< 0002: UART Control Register 1                                      */
   __IO uint8_t   C2;                           /*!< 0003: UART Control Register 2                                      */
   __I  uint8_t   S1;                           /*!< 0004: UART Status Register 1                                       */
   __IO uint8_t   S2;                           /*!< 0005: UART Status Register 2                                       */
   __IO uint8_t   C3;                           /*!< 0006: UART Control Register 3                                      */
   __IO uint8_t   D;                            /*!< 0007: UART Data Register                                           */
} UART0_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'UART0' Position & Mask macros                       ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- UART0_BDH                                ------ */
#define UART_BDH_SBR_MASK                        (0x1FUL << UART_BDH_SBR_SHIFT)                      /*!< UART0_BDH: SBR Mask                     */
#define UART_BDH_SBR_SHIFT                       0                                                   /*!< UART0_BDH: SBR Position                 */
#define UART_BDH_SBR(x)                          (((x)<<UART_BDH_SBR_SHIFT)&UART_BDH_SBR_MASK)       /*!< UART0_BDH                               */
#define UART_BDH_SBNS_MASK                       (0x01UL << UART_BDH_SBNS_SHIFT)                     /*!< UART0_BDH: SBNS Mask                    */
#define UART_BDH_SBNS_SHIFT                      5                                                   /*!< UART0_BDH: SBNS Position                */
#define UART_BDH_RXEDGIE_MASK                    (0x01UL << UART_BDH_RXEDGIE_SHIFT)                  /*!< UART0_BDH: RXEDGIE Mask                 */
#define UART_BDH_RXEDGIE_SHIFT                   6                                                   /*!< UART0_BDH: RXEDGIE Position             */
#define UART_BDH_LBKDIE_MASK                     (0x01UL << UART_BDH_LBKDIE_SHIFT)                   /*!< UART0_BDH: LBKDIE Mask                  */
#define UART_BDH_LBKDIE_SHIFT                    7                                                   /*!< UART0_BDH: LBKDIE Position              */

/* ------- UART0_BDL                                ------ */
#define UART_BDL_SBR_MASK                        (0xFFUL << UART_BDL_SBR_SHIFT)                      /*!< UART0_BDL: SBR Mask                     */
#define UART_BDL_SBR_SHIFT                       0                                                   /*!< UART0_BDL: SBR Position                 */
#define UART_BDL_SBR(x)                          (((x)<<UART_BDL_SBR_SHIFT)&UART_BDL_SBR_MASK)       /*!< UART0_BDL                               */

/* ------- UART0_C1                                 ------ */
#define UART_C1_PT_MASK                          (0x01UL << UART_C1_PT_SHIFT)                        /*!< UART0_C1: PT Mask                       */
#define UART_C1_PT_SHIFT                         0                                                   /*!< UART0_C1: PT Position                   */
#define UART_C1_PE_MASK                          (0x01UL << UART_C1_PE_SHIFT)                        /*!< UART0_C1: PE Mask                       */
#define UART_C1_PE_SHIFT                         1                                                   /*!< UART0_C1: PE Position                   */
#define UART_C1_ILT_MASK                         (0x01UL << UART_C1_ILT_SHIFT)                       /*!< UART0_C1: ILT Mask                      */
#define UART_C1_ILT_SHIFT                        2                                                   /*!< UART0_C1: ILT Position                  */
#define UART_C1_WAKE_MASK                        (0x01UL << UART_C1_WAKE_SHIFT)                      /*!< UART0_C1: WAKE Mask                     */
#define UART_C1_WAKE_SHIFT                       3                                                   /*!< UART0_C1: WAKE Position                 */
#define UART_C1_M_MASK                           (0x01UL << UART_C1_M_SHIFT)                         /*!< UART0_C1: M Mask                        */
#define UART_C1_M_SHIFT                          4                                                   /*!< UART0_C1: M Position                    */
#define UART_C1_RSRC_MASK                        (0x01UL << UART_C1_RSRC_SHIFT)                      /*!< UART0_C1: RSRC Mask                     */
#define UART_C1_RSRC_SHIFT                       5                                                   /*!< UART0_C1: RSRC Position                 */
#define UART_C1_UARTSWAI_MASK                    (0x01UL << UART_C1_UARTSWAI_SHIFT)                  /*!< UART0_C1: UARTSWAI Mask                 */
#define UART_C1_UARTSWAI_SHIFT                   6                                                   /*!< UART0_C1: UARTSWAI Position             */
#define UART_C1_LOOPS_MASK                       (0x01UL << UART_C1_LOOPS_SHIFT)                     /*!< UART0_C1: LOOPS Mask                    */
#define UART_C1_LOOPS_SHIFT                      7                                                   /*!< UART0_C1: LOOPS Position                */

/* ------- UART0_C2                                 ------ */
#define UART_C2_SBK_MASK                         (0x01UL << UART_C2_SBK_SHIFT)                       /*!< UART0_C2: SBK Mask                      */
#define UART_C2_SBK_SHIFT                        0                                                   /*!< UART0_C2: SBK Position                  */
#define UART_C2_RWU_MASK                         (0x01UL << UART_C2_RWU_SHIFT)                       /*!< UART0_C2: RWU Mask                      */
#define UART_C2_RWU_SHIFT                        1                                                   /*!< UART0_C2: RWU Position                  */
#define UART_C2_RE_MASK                          (0x01UL << UART_C2_RE_SHIFT)                        /*!< UART0_C2: RE Mask                       */
#define UART_C2_RE_SHIFT                         2                                                   /*!< UART0_C2: RE Position                   */
#define UART_C2_TE_MASK                          (0x01UL << UART_C2_TE_SHIFT)                        /*!< UART0_C2: TE Mask                       */
#define UART_C2_TE_SHIFT                         3                                                   /*!< UART0_C2: TE Position                   */
#define UART_C2_ILIE_MASK                        (0x01UL << UART_C2_ILIE_SHIFT)                      /*!< UART0_C2: ILIE Mask                     */
#define UART_C2_ILIE_SHIFT                       4                                                   /*!< UART0_C2: ILIE Position                 */
#define UART_C2_RIE_MASK                         (0x01UL << UART_C2_RIE_SHIFT)                       /*!< UART0_C2: RIE Mask                      */
#define UART_C2_RIE_SHIFT                        5                                                   /*!< UART0_C2: RIE Position                  */
#define UART_C2_TCIE_MASK                        (0x01UL << UART_C2_TCIE_SHIFT)                      /*!< UART0_C2: TCIE Mask                     */
#define UART_C2_TCIE_SHIFT                       6                                                   /*!< UART0_C2: TCIE Position                 */
#define UART_C2_TIE_MASK                         (0x01UL << UART_C2_TIE_SHIFT)                       /*!< UART0_C2: TIE Mask                      */
#define UART_C2_TIE_SHIFT                        7                                                   /*!< UART0_C2: TIE Position                  */

/* ------- UART0_S1                                 ------ */
#define UART_S1_PF_MASK                          (0x01UL << UART_S1_PF_SHIFT)                        /*!< UART0_S1: PF Mask                       */
#define UART_S1_PF_SHIFT                         0                                                   /*!< UART0_S1: PF Position                   */
#define UART_S1_FE_MASK                          (0x01UL << UART_S1_FE_SHIFT)                        /*!< UART0_S1: FE Mask                       */
#define UART_S1_FE_SHIFT                         1                                                   /*!< UART0_S1: FE Position                   */
#define UART_S1_NF_MASK                          (0x01UL << UART_S1_NF_SHIFT)                        /*!< UART0_S1: NF Mask                       */
#define UART_S1_NF_SHIFT                         2                                                   /*!< UART0_S1: NF Position                   */
#define UART_S1_OR_MASK                          (0x01UL << UART_S1_OR_SHIFT)                        /*!< UART0_S1: OR Mask                       */
#define UART_S1_OR_SHIFT                         3                                                   /*!< UART0_S1: OR Position                   */
#define UART_S1_IDLE_MASK                        (0x01UL << UART_S1_IDLE_SHIFT)                      /*!< UART0_S1: IDLE Mask                     */
#define UART_S1_IDLE_SHIFT                       4                                                   /*!< UART0_S1: IDLE Position                 */
#define UART_S1_RDRF_MASK                        (0x01UL << UART_S1_RDRF_SHIFT)                      /*!< UART0_S1: RDRF Mask                     */
#define UART_S1_RDRF_SHIFT                       5                                                   /*!< UART0_S1: RDRF Position                 */
#define UART_S1_TC_MASK                          (0x01UL << UART_S1_TC_SHIFT)                        /*!< UART0_S1: TC Mask                       */
#define UART_S1_TC_SHIFT                         6                                                   /*!< UART0_S1: TC Position                   */
#define UART_S1_TDRE_MASK                        (0x01UL << UART_S1_TDRE_SHIFT)                      /*!< UART0_S1: TDRE Mask                     */
#define UART_S1_TDRE_SHIFT                       7                                                   /*!< UART0_S1: TDRE Position                 */

/* ------- UART0_S2                                 ------ */
#define UART_S2_RAF_MASK                         (0x01UL << UART_S2_RAF_SHIFT)                       /*!< UART0_S2: RAF Mask                      */
#define UART_S2_RAF_SHIFT                        0                                                   /*!< UART0_S2: RAF Position                  */
#define UART_S2_LBKDE_MASK                       (0x01UL << UART_S2_LBKDE_SHIFT)                     /*!< UART0_S2: LBKDE Mask                    */
#define UART_S2_LBKDE_SHIFT                      1                                                   /*!< UART0_S2: LBKDE Position                */
#define UART_S2_BRK13_MASK                       (0x01UL << UART_S2_BRK13_SHIFT)                     /*!< UART0_S2: BRK13 Mask                    */
#define UART_S2_BRK13_SHIFT                      2                                                   /*!< UART0_S2: BRK13 Position                */
#define UART_S2_RWUID_MASK                       (0x01UL << UART_S2_RWUID_SHIFT)                     /*!< UART0_S2: RWUID Mask                    */
#define UART_S2_RWUID_SHIFT                      3                                                   /*!< UART0_S2: RWUID Position                */
#define UART_S2_RXINV_MASK                       (0x01UL << UART_S2_RXINV_SHIFT)                     /*!< UART0_S2: RXINV Mask                    */
#define UART_S2_RXINV_SHIFT                      4                                                   /*!< UART0_S2: RXINV Position                */
#define UART_S2_RXEDGIF_MASK                     (0x01UL << UART_S2_RXEDGIF_SHIFT)                   /*!< UART0_S2: RXEDGIF Mask                  */
#define UART_S2_RXEDGIF_SHIFT                    6                                                   /*!< UART0_S2: RXEDGIF Position              */
#define UART_S2_LBKDIF_MASK                      (0x01UL << UART_S2_LBKDIF_SHIFT)                    /*!< UART0_S2: LBKDIF Mask                   */
#define UART_S2_LBKDIF_SHIFT                     7                                                   /*!< UART0_S2: LBKDIF Position               */

/* ------- UART0_C3                                 ------ */
#define UART_C3_PEIE_MASK                        (0x01UL << UART_C3_PEIE_SHIFT)                      /*!< UART0_C3: PEIE Mask                     */
#define UART_C3_PEIE_SHIFT                       0                                                   /*!< UART0_C3: PEIE Position                 */
#define UART_C3_FEIE_MASK                        (0x01UL << UART_C3_FEIE_SHIFT)                      /*!< UART0_C3: FEIE Mask                     */
#define UART_C3_FEIE_SHIFT                       1                                                   /*!< UART0_C3: FEIE Position                 */
#define UART_C3_NEIE_MASK                        (0x01UL << UART_C3_NEIE_SHIFT)                      /*!< UART0_C3: NEIE Mask                     */
#define UART_C3_NEIE_SHIFT                       2                                                   /*!< UART0_C3: NEIE Position                 */
#define UART_C3_ORIE_MASK                        (0x01UL << UART_C3_ORIE_SHIFT)                      /*!< UART0_C3: ORIE Mask                     */
#define UART_C3_ORIE_SHIFT                       3                                                   /*!< UART0_C3: ORIE Position                 */
#define UART_C3_TXINV_MASK                       (0x01UL << UART_C3_TXINV_SHIFT)                     /*!< UART0_C3: TXINV Mask                    */
#define UART_C3_TXINV_SHIFT                      4                                                   /*!< UART0_C3: TXINV Position                */
#define UART_C3_TXDIR_MASK                       (0x01UL << UART_C3_TXDIR_SHIFT)                     /*!< UART0_C3: TXDIR Mask                    */
#define UART_C3_TXDIR_SHIFT                      5                                                   /*!< UART0_C3: TXDIR Position                */
#define UART_C3_T8_MASK                          (0x01UL << UART_C3_T8_SHIFT)                        /*!< UART0_C3: T8 Mask                       */
#define UART_C3_T8_SHIFT                         6                                                   /*!< UART0_C3: T8 Position                   */
#define UART_C3_R8_MASK                          (0x01UL << UART_C3_R8_SHIFT)                        /*!< UART0_C3: R8 Mask                       */
#define UART_C3_R8_SHIFT                         7                                                   /*!< UART0_C3: R8 Position                   */

/* ------- UART0_D                                  ------ */
#define UART_D_DATA_MASK                         (0xFFUL << UART_D_DATA_SHIFT)                       /*!< UART0_D: DATA Mask                      */
#define UART_D_DATA_SHIFT                        0                                                   /*!< UART0_D: DATA Position                  */
#define UART_D_DATA(x)                           (((x)<<UART_D_DATA_SHIFT)&UART_D_DATA_MASK)         /*!< UART0_D                                 */

/* -------------------------------------------------------------------------------- */
/* -----------     'UART0' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define UART0_BDH                      (UART0->BDH)
#define UART0_BDL                      (UART0->BDL)
#define UART0_C1                       (UART0->C1)
#define UART0_C2                       (UART0->C2)
#define UART0_S1                       (UART0->S1)
#define UART0_S2                       (UART0->S2)
#define UART0_C3                       (UART0->C3)
#define UART0_D                        (UART0->D)

/* ================================================================================ */
/* ================           UART1 (derived from UART0)           ================ */
/* ================================================================================ */

/**
 * @brief Universal Asynchronous Receiver/Transmitter (UART) (UART1)
 */
typedef UART0_Type UART1_Type;  /*!< UART1 Structure                                             */


/* -------------------------------------------------------------------------------- */
/* -----------     'UART1' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define UART1_BDH                      (UART1->BDH)
#define UART1_BDL                      (UART1->BDL)
#define UART1_C1                       (UART1->C1)
#define UART1_C2                       (UART1->C2)
#define UART1_S1                       (UART1->S1)
#define UART1_S2                       (UART1->S2)
#define UART1_C3                       (UART1->C3)
#define UART1_D                        (UART1->D)

/* ================================================================================ */
/* ================           UART2 (derived from UART0)           ================ */
/* ================================================================================ */

/**
 * @brief Universal Asynchronous Receiver/Transmitter (UART) (UART2)
 */
typedef UART0_Type UART2_Type;  /*!< UART2 Structure                                             */


/* -------------------------------------------------------------------------------- */
/* -----------     'UART2' Register Access macros                       ----------- */
/* -------------------------------------------------------------------------------- */

#define UART2_BDH                      (UART2->BDH)
#define UART2_BDL                      (UART2->BDL)
#define UART2_C1                       (UART2->C1)
#define UART2_C2                       (UART2->C2)
#define UART2_S1                       (UART2->S1)
#define UART2_S2                       (UART2->S2)
#define UART2_C3                       (UART2->C3)
#define UART2_D                        (UART2->D)

/* ================================================================================ */
/* ================           WDOG (file:WDOG_MKE)                 ================ */
/* ================================================================================ */

/**
 * @brief Watchdog timer (WDOG)
 */
typedef struct {                                /*!<       WDOG Structure                                               */
   __IO uint8_t   CS1;                          /*!< 0000: Watchdog Control and Status Register 1                       */
   __IO uint8_t   CS2;                          /*!< 0001: Watchdog Control and Status Register 2                       */
   union {                                      /*!< 0000: (size=0002)                                                  */
      __IO uint16_t  CNT;                       /*!< 0002: Watchdog Counter Register: (Note: CNTL:CNTH)                 */
      struct {                                  /*!< 0000: (size=0002)                                                  */
         __IO uint8_t   CNTH;                   /*!< 0002: Watchdog Counter Register: High (see CNT for description)    */
         __IO uint8_t   CNTL;                   /*!< 0003: Watchdog Counter Register: Low (see CNT for description)     */
      };
   };
   union {                                      /*!< 0000: (size=0002)                                                  */
      __IO uint16_t  TOVAL;                     /*!< 0004: Watchdog Timeout Value Register: (Note TOVALL:TOVALH)        */
      struct {                                  /*!< 0000: (size=0002)                                                  */
         __IO uint8_t   TOVALH;                 /*!< 0004: Watchdog Timeout Value Register: High (see TOVAL for description) */
         __IO uint8_t   TOVALL;                 /*!< 0005: Watchdog Timeout Value Register: Low (see TOVAL for description) */
      };
   };
   union {                                      /*!< 0000: (size=0002)                                                  */
      __IO uint16_t  WIN;                       /*!< 0006: Watchdog Window Register:(Note WINL:WINH)                    */
      struct {                                  /*!< 0000: (size=0002)                                                  */
         __IO uint8_t   WINH;                   /*!< 0006: Watchdog Window Register: High (see WIN for description)     */
         __IO uint8_t   WINL;                   /*!< 0007: Watchdog Window Register: Low (see WIN for description)      */
      };
   };
} WDOG_Type;


/* -------------------------------------------------------------------------------- */
/* -----------     'WDOG' Position & Mask macros                        ----------- */
/* -------------------------------------------------------------------------------- */


/* ------- WDOG_CS1                                 ------ */
#define WDOG_CS1_STOP_MASK                       (0x01UL << WDOG_CS1_STOP_SHIFT)                     /*!< WDOG_CS1: STOP Mask                     */
#define WDOG_CS1_STOP_SHIFT                      0                                                   /*!< WDOG_CS1: STOP Position                 */
#define WDOG_CS1_WAIT_MASK                       (0x01UL << WDOG_CS1_WAIT_SHIFT)                     /*!< WDOG_CS1: WAIT Mask                     */
#define WDOG_CS1_WAIT_SHIFT                      1                                                   /*!< WDOG_CS1: WAIT Position                 */
#define WDOG_CS1_DBG_MASK                        (0x01UL << WDOG_CS1_DBG_SHIFT)                      /*!< WDOG_CS1: DBG Mask                      */
#define WDOG_CS1_DBG_SHIFT                       2                                                   /*!< WDOG_CS1: DBG Position                  */
#define WDOG_CS1_TST_MASK                        (0x03UL << WDOG_CS1_TST_SHIFT)                      /*!< WDOG_CS1: TST Mask                      */
#define WDOG_CS1_TST_SHIFT                       3                                                   /*!< WDOG_CS1: TST Position                  */
#define WDOG_CS1_TST(x)                          (((x)<<WDOG_CS1_TST_SHIFT)&WDOG_CS1_TST_MASK)       /*!< WDOG_CS1                                */
#define WDOG_CS1_UPDATE_MASK                     (0x01UL << WDOG_CS1_UPDATE_SHIFT)                   /*!< WDOG_CS1: UPDATE Mask                   */
#define WDOG_CS1_UPDATE_SHIFT                    5                                                   /*!< WDOG_CS1: UPDATE Position               */
#define WDOG_CS1_INT_MASK                        (0x01UL << WDOG_CS1_INT_SHIFT)                      /*!< WDOG_CS1: INT Mask                      */
#define WDOG_CS1_INT_SHIFT                       6                                                   /*!< WDOG_CS1: INT Position                  */
#define WDOG_CS1_EN_MASK                         (0x01UL << WDOG_CS1_EN_SHIFT)                       /*!< WDOG_CS1: EN Mask                       */
#define WDOG_CS1_EN_SHIFT                        7                                                   /*!< WDOG_CS1: EN Position                   */

/* ------- WDOG_CS2                                 ------ */
#define WDOG_CS2_CLK_MASK                        (0x03UL << WDOG_CS2_CLK_SHIFT)                      /*!< WDOG_CS2: CLK Mask                      */
#define WDOG_CS2_CLK_SHIFT                       0                                                   /*!< WDOG_CS2: CLK Position                  */
#define WDOG_CS2_CLK(x)                          (((x)<<WDOG_CS2_CLK_SHIFT)&WDOG_CS2_CLK_MASK)       /*!< WDOG_CS2                                */
#define WDOG_CS2_PRES_MASK                       (0x01UL << WDOG_CS2_PRES_SHIFT)                     /*!< WDOG_CS2: PRES Mask                     */
#define WDOG_CS2_PRES_SHIFT                      4                                                   /*!< WDOG_CS2: PRES Position                 */
#define WDOG_CS2_FLG_MASK                        (0x01UL << WDOG_CS2_FLG_SHIFT)                      /*!< WDOG_CS2: FLG Mask                      */
#define WDOG_CS2_FLG_SHIFT                       6                                                   /*!< WDOG_CS2: FLG Position                  */
#define WDOG_CS2_WIN_MASK                        (0x01UL << WDOG_CS2_WIN_SHIFT)                      /*!< WDOG_CS2: WIN Mask                      */
#define WDOG_CS2_WIN_SHIFT                       7                                                   /*!< WDOG_CS2: WIN Position                  */

/* ------- WDOG_CNT                                 ------ */

/* ------- WDOG_CNTH                                ------ */

/* ------- WDOG_CNTL                                ------ */

/* ------- WDOG_TOVAL                               ------ */

/* ------- WDOG_TOVALH                              ------ */

/* ------- WDOG_TOVALL                              ------ */

/* ------- WDOG_WIN                                 ------ */

/* ------- WDOG_WINH                                ------ */

/* ------- WDOG_WINL                                ------ */

/* -------------------------------------------------------------------------------- */
/* -----------     'WDOG' Register Access macros                        ----------- */
/* -------------------------------------------------------------------------------- */

#define WDOG_CS1                       (WDOG->CS1)
#define WDOG_CS2                       (WDOG->CS2)
#define WDOG_CNT                       (WDOG->CNT)
#define WDOG_CNTH                      (WDOG->CNTH)
#define WDOG_CNTL                      (WDOG->CNTL)
#define WDOG_TOVAL                     (WDOG->TOVAL)
#define WDOG_TOVALH                    (WDOG->TOVALH)
#define WDOG_TOVALL                    (WDOG->TOVALL)
#define WDOG_WIN                       (WDOG->WIN)
#define WDOG_WINH                      (WDOG->WINH)
#define WDOG_WINL                      (WDOG->WINL)
/* --------------------  End of section using anonymous unions  ------------------- */
#if defined(__CC_ARM)
  #pragma pop
#elif defined(__ICCARM__)
  /* leave anonymous unions enabled */
#elif defined(__GNUC__)
  /* anonymous unions are enabled by default */
#elif defined(__TMS470__)
  /* anonymous unions are enabled by default */
#elif defined(__TASKING__)
  #pragma warning restore
#else
  #warning Not supported compiler type
#endif

/* ================================================================================ */
/* ================              Peripheral memory map             ================ */
/* ================================================================================ */

#define ACMP0_BASE_PTR                 0x40073000UL
#define ACMP1_BASE_PTR                 0x40074000UL
#define ADC_BASE_PTR                   0x4003B000UL
#define BP_BASE_PTR                    0xE0002000UL
#define CRC_BASE_PTR                   0x40032000UL
#define FGPIOA_BASE_PTR                0xF8000000UL
#define FGPIOB_BASE_PTR                0xF8000040UL
#define FTM0_BASE_PTR                  0x40038000UL
#define FTM1_BASE_PTR                  0x40039000UL
#define FTM2_BASE_PTR                  0x4003A000UL
#define FTMRH_BASE_PTR                 0x40020000UL
#define GPIOA_BASE_PTR                 0x400FF000UL
#define GPIOB_BASE_PTR                 0x400FF040UL
#define I2C0_BASE_PTR                  0x40066000UL
#define ICS_BASE_PTR                   0x40064000UL
#define IRQ_BASE_PTR                   0x40031000UL
#define KBI0_BASE_PTR                  0x40079000UL
#define KBI1_BASE_PTR                  0x4007A000UL
#define MCM_BASE_PTR                   0xF0003000UL
#define NV_BASE_PTR                    0x00000400UL
#define OSC_BASE_PTR                   0x40065000UL
#define PIT_BASE_PTR                   0x40037000UL
#define PMC_BASE_PTR                   0x4007D000UL
#define PORT_BASE_PTR                  0x40049000UL
#define RTC_BASE_PTR                   0x4003D000UL
#define SIM_BASE_PTR                   0x40048000UL
#define SPI0_BASE_PTR                  0x40076000UL
#define SPI1_BASE_PTR                  0x40077000UL
#define UART0_BASE_PTR                 0x4006A000UL
#define UART1_BASE_PTR                 0x4006B000UL
#define UART2_BASE_PTR                 0x4006C000UL
#define WDOG_BASE_PTR                  0x40052000UL

/* ================================================================================ */
/* ================             Peripheral declarations            ================ */
/* ================================================================================ */

#define ACMP0                          ((volatile ACMP0_Type  *) ACMP0_BASE_PTR)
#define ACMP1                          ((volatile ACMP1_Type  *) ACMP1_BASE_PTR)
#define ADC                            ((volatile ADC_Type    *) ADC_BASE_PTR)
#define BP                             ((volatile BP_Type     *) BP_BASE_PTR)
#define CRC                            ((volatile CRC_Type    *) CRC_BASE_PTR)
#define FGPIOA                         ((volatile FGPIOA_Type *) FGPIOA_BASE_PTR)
#define FGPIOB                         ((volatile FGPIOB_Type *) FGPIOB_BASE_PTR)
#define FTM0                           ((volatile FTM0_Type   *) FTM0_BASE_PTR)
#define FTM1                           ((volatile FTM1_Type   *) FTM1_BASE_PTR)
#define FTM2                           ((volatile FTM2_Type   *) FTM2_BASE_PTR)
#define FTMRH                          ((volatile FTMRH_Type  *) FTMRH_BASE_PTR)
#define GPIOA                          ((volatile GPIOA_Type  *) GPIOA_BASE_PTR)
#define GPIOB                          ((volatile GPIOB_Type  *) GPIOB_BASE_PTR)
#define I2C0                           ((volatile I2C0_Type   *) I2C0_BASE_PTR)
#define ICS                            ((volatile ICS_Type    *) ICS_BASE_PTR)
#define IRQ                            ((volatile IRQ_Type    *) IRQ_BASE_PTR)
#define KBI0                           ((volatile KBI0_Type   *) KBI0_BASE_PTR)
#define KBI1                           ((volatile KBI1_Type   *) KBI1_BASE_PTR)
#define MCM                            ((volatile MCM_Type    *) MCM_BASE_PTR)
#define NV                             ((volatile NV_Type     *) NV_BASE_PTR)
#define OSC                            ((volatile OSC_Type    *) OSC_BASE_PTR)
#define PIT                            ((volatile PIT_Type    *) PIT_BASE_PTR)
#define PMC                            ((volatile PMC_Type    *) PMC_BASE_PTR)
#define PORT                           ((volatile PORT_Type   *) PORT_BASE_PTR)
#define RTC                            ((volatile RTC_Type    *) RTC_BASE_PTR)
#define SIM                            ((volatile SIM_Type    *) SIM_BASE_PTR)
#define SPI0                           ((volatile SPI0_Type   *) SPI0_BASE_PTR)
#define SPI1                           ((volatile SPI1_Type   *) SPI1_BASE_PTR)
#define UART0                          ((volatile UART0_Type  *) UART0_BASE_PTR)
#define UART1                          ((volatile UART1_Type  *) UART1_BASE_PTR)
#define UART2                          ((volatile UART2_Type  *) UART2_BASE_PTR)
#define WDOG                           ((volatile WDOG_Type   *) WDOG_BASE_PTR)

#ifdef __cplusplus
}
#endif


#endif  /* MCU_MKE02Z2 */

