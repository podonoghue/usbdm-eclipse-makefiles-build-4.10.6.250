/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include "derivative.h"
#include "leds.h"
#include "uart.h"

int main () {

   led_initialise();
   greenLedOn();

   printf("\n\r"
         "==============================\n\r"
         "       Hello World\n\r"
         "==============================\n\r");

   int i = 0;
   for(;;) {
      printf("i = %d\n\r", i++);
      greenLedToggle();
   }
   return 0;
}
