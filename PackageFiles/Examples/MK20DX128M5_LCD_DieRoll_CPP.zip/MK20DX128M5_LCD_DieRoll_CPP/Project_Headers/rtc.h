/*
 * rtc.h
 *
 *  Created on: 25/10/2013
 *      Author: podonoghue
 */

#ifndef RTC_H_
#define RTC_H_

#ifdef __cplusplus
extern "C" {
#endif

void enableRTCSecondInterrupt(void);
void initialiseRTC(void);

#ifdef __cplusplus
}
#endif

#endif /* RTC_H_ */
