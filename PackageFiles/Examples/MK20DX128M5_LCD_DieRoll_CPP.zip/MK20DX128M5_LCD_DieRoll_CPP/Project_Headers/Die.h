/*
 * Die.h
 *
 *  Created on: 13/07/2014
 *      Author: podonoghue
 */

#ifndef DIE_H_
#define DIE_H_

#include "LCD.h"

class Die {
private:
   LCD      *lcd;
   unsigned  dieRoll;
   static const int BACKGROUND_COLOUR = BLACK;

   void drawFilledCircle(int centre_x, int centre_y, int radius, int colour);
   void drawDieBackground(void);
   void drawDieDots(int roll);

public:
   Die (LCD *lcd) : lcd(lcd), dieRoll(1) {
      lcd->clear(BACKGROUND_COLOUR);
      drawDieBackground();
   }
   void rollOnce(void);

};

#endif /* DIE_H_ */
