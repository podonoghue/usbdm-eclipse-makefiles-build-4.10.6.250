/*
 * Die.cpp
 *
 *  Created on: 13/07/2014
 *      Author: podonoghue
 */

#include "Die.h"

void Die::drawFilledCircle(int centre_x, int centre_y, int radius, int colour) {

   int radius_squared = radius*radius;
   int x, y;
   for (x = -radius; x <= radius; x++) {
      for (y = -radius; y <= radius; y++) {
         if ((x*x+y*y) <= radius_squared) {
            lcd->drawPixel(centre_x+x,centre_y+y,colour);
         }
      }
   }
}
#define ORIGIN_X     66
#define ORIGIN_Y     66
#define DOT_RADIUS   10
#define DOT_SPACING  32
#define DIE_WIDTH    100

#define DIE_COLOUR        WHITE
#define DOT_COLOUR        BLACK
#define BACKGROUND_COLOUR BLACK

#define DIE_CORNER_RADIUS 10

void Die::drawDieBackground(void) {
   lcd->drawRect(ORIGIN_X-(DIE_WIDTH/2-DIE_CORNER_RADIUS), ORIGIN_Y-(DIE_WIDTH/2),
                ORIGIN_X+(DIE_WIDTH/2-DIE_CORNER_RADIUS), ORIGIN_Y+(DIE_WIDTH/2), DIE_COLOUR, DIE_COLOUR);
   lcd->drawRect(ORIGIN_X-(DIE_WIDTH/2), ORIGIN_Y-(DIE_WIDTH/2-DIE_CORNER_RADIUS),
                ORIGIN_X+(DIE_WIDTH/2), ORIGIN_Y+(DIE_WIDTH/2-DIE_CORNER_RADIUS), DIE_COLOUR, DIE_COLOUR);
   drawFilledCircle(ORIGIN_X-(DIE_WIDTH/2-DIE_CORNER_RADIUS), ORIGIN_Y-(DIE_WIDTH/2-DIE_CORNER_RADIUS), DIE_CORNER_RADIUS, DIE_COLOUR);
   drawFilledCircle(ORIGIN_X+(DIE_WIDTH/2-DIE_CORNER_RADIUS), ORIGIN_Y-(DIE_WIDTH/2-DIE_CORNER_RADIUS), DIE_CORNER_RADIUS, DIE_COLOUR);
   drawFilledCircle(ORIGIN_X-(DIE_WIDTH/2-DIE_CORNER_RADIUS), ORIGIN_Y+(DIE_WIDTH/2-DIE_CORNER_RADIUS), DIE_CORNER_RADIUS, DIE_COLOUR);
   drawFilledCircle(ORIGIN_X+(DIE_WIDTH/2-DIE_CORNER_RADIUS), ORIGIN_Y+(DIE_WIDTH/2-DIE_CORNER_RADIUS), DIE_CORNER_RADIUS, DIE_COLOUR);
}

void Die::drawDieDots(int roll) {
   enum masks { A = 1<<0, B = 1<<2, C = 1<<3, D = 1<<4};
   static const int patterns[] = { 0, D, C, A|D, A|B, A|B|D, A|B|C, 0};
   int rollMask = patterns[roll&0x07];
   int aColour, bColour, cColour, dColour;

   aColour = ((rollMask&A)!= 0)?DOT_COLOUR:DIE_COLOUR;
   bColour = ((rollMask&B)!= 0)?DOT_COLOUR:DIE_COLOUR;
   cColour = ((rollMask&C)!= 0)?DOT_COLOUR:DIE_COLOUR;
   dColour = ((rollMask&D)!= 0)?DOT_COLOUR:DIE_COLOUR;

   // D - centre
   drawFilledCircle(ORIGIN_X,             ORIGIN_Y,              DOT_RADIUS, dColour);
   // C - horizontal
   drawFilledCircle(ORIGIN_X-DOT_SPACING, ORIGIN_Y,              DOT_RADIUS, cColour);
   drawFilledCircle(ORIGIN_X+DOT_SPACING, ORIGIN_Y,              DOT_RADIUS, cColour);
   // B - diagonal
   drawFilledCircle(ORIGIN_X-DOT_SPACING, ORIGIN_Y+DOT_SPACING,  DOT_RADIUS, bColour);
   drawFilledCircle(ORIGIN_X+DOT_SPACING, ORIGIN_Y-DOT_SPACING,  DOT_RADIUS, bColour);
   // A - diagonal
   drawFilledCircle(ORIGIN_X-DOT_SPACING, ORIGIN_Y-DOT_SPACING,  DOT_RADIUS, aColour);
   drawFilledCircle(ORIGIN_X+DOT_SPACING, ORIGIN_Y+DOT_SPACING,  DOT_RADIUS, aColour);
}

void Die::rollOnce(void) {
   dieRoll++;
   if (dieRoll>6) {
      dieRoll = 1;
   }
   drawDieDots(dieRoll);
}


