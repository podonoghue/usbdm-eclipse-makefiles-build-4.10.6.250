/*
 * pwm.c
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */
#include "derivative.h"
#include "stddef.h"
#include "utilities.h"
#include "clock.h"
#include "tpm1.h"

#ifndef TPM1_USES_NAKED_HANDLERS

/*! Set the callback for the TPM channel
 *
 *  @param channel   - PTM channel to initialise
 */
void TPM1::setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval) {

   channelInformation[channel].callback = callback;
   channelInformation[channel].interval = interval;

   tpmBase->CONTROLS[channel].CnSC |= TPM_CnSC_CHIE_MASK;

   NVIC_EnableIrq(interruptNumber);
}
#endif

TPM1::FtmChannelInformation TPM1::channelInformation[] = {{NULL,0}};

extern "C"
void TPM1_IRQHandler(void) {
   // This method is better for the usual case of a single interrupt at a time
   int channel = 0;
   int status  = TPM1_STATUS;
   if (status & 0xF0) {
      channel = 4;
      status  &= 0xF0;
   }
   if (status & 0xCC) {
      channel += 2;
      status  &= 0xCC;
   }
   if (status & 0xAA) {
      channel++;
   }
   // Clear flag
   TPM1_CnSC(channel) |= TPM_CnSC_CHF_MASK;
   if (TPM1::channelInformation[channel].interval != 0) {
      // Set interval
      TPM1_CnV(channel) += TPM1::channelInformation[channel].interval;
   }
   if (TPM1::channelInformation[channel].callback != NULL) {
      // Do callback
      TPM1::channelInformation[channel].callback();
   }
}

