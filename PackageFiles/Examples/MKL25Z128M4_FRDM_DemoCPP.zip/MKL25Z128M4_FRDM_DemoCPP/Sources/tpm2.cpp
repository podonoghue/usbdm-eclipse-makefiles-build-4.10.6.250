/*
 * pwm.c
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */
#include "derivative.h"
#include "stddef.h"
#include "utilities.h"
#include "clock.h"
#include "tpm2.h"

#ifndef TPM2_USES_NAKED_HANDLERS

/*! Set the callback for the TPM channel
 *
 *  @param channel   - PTM channel to initialise
 */
void TPM2::setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval) {

   channelInformation[channel].callback = callback;
   channelInformation[channel].interval = interval;

   tpmBase->CONTROLS[channel].CnSC |= TPM_CnSC_CHIE_MASK;

   NVIC_EnableIrq(interruptNumber);
}
#endif

TPM2::FtmChannelInformation TPM2::channelInformation[] = {{NULL,0}};

extern "C"
void TPM2_IRQHandler(void) {
   // This method is better for the usual case of a single interrupt at a time
   int channel = 0;
   int status  = TPM2_STATUS;
   if (status & 0xF0) {
      channel = 4;
      status  &= 0xF0;
   }
   if (status & 0xCC) {
      channel += 2;
      status  &= 0xCC;
   }
   if (status & 0xAA) {
      channel++;
   }
   // Clear flag
   TPM2_CnSC(channel) |= TPM_CnSC_CHF_MASK;
   if (TPM2::channelInformation[channel].interval != 0) {
      // Set interval
      TPM2_CnV(channel) += TPM2::channelInformation[channel].interval;
   }
   if (TPM2::channelInformation[channel].callback != NULL) {
      // Do callback
      TPM2::channelInformation[channel].callback();
   }
}

