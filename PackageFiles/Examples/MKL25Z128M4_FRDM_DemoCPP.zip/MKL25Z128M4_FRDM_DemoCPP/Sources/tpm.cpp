/*
 * pwm.c
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */
#include "derivative.h"
#include "stddef.h"
#include "utilities.h"
#include "clock.h"
#include "tpm.h"

TPM::TPM(TPM0_Type *tpmBase, IRQn_Type interruptNumber, uint32_t clockMask) :
      tpmBase(tpmBase),
      interruptNumber(interruptNumber)
   {
      // Enable clock to FTM0
      SIM_SCGC6  |= clockMask;
   }

void TPM::initialise(int period, uint8_t mode) {
   // Common registers
   tpmBase->SC      = TPM_SC_CMOD(0); // Disable FTM so register changes are immediate
   tpmBase->CNT     = 0;
   if ((mode&TPM_SC_CPWMS_MASK) != 0) {
      // Centre aligned PWM with CPWMS not selected
      tpmBase->MOD     = period/2;
      tpmBase->SC      = mode;
   }
   else {
      // Left aligned PWM without CPWMS selected
      tpmBase->MOD     = period-1;
      tpmBase->SC      = mode;
   }
}

/*! Initialises TPM channel for PWM/Input capture/Output compare
 *
 *  @param channel   - FTM0 channel to initialise
 *  @param mode      - Mode for the channel
 */
void TPM::initialiseChannel(int channel, Ftm_Mode mode) {
   tpmBase->CONTROLS[channel].CnV  = 0;
   tpmBase->CONTROLS[channel].CnSC = mode;
}

/*!
 *  Sets the duty cycle of the PWM waveform on a given channel
 *
 *  @param channel   - FTM0 channel to use
 *  @param dutyCycle - Duty cycle in percentage (0-100)
 *
 */
void TPM::setDutyCycle(int channel, int dutyCycle) {
   if (tpmBase->SC&TPM_SC_CPWMS_MASK) {
      tpmBase->CONTROLS[channel].CnV  = (dutyCycle*TPM0_MOD)/100;
   }
   else {
      tpmBase->CONTROLS[channel].CnV  = (dutyCycle*(TPM0_MOD+1))/100;
   }
}

/*!
 *  Disables a FTM channel or entire FTM
 *
 *  @param channel   - FTM0 channel to disable, -1 disable entire FTM
 *
 */
void TPM::finaliseChannel(int channel) {
   if (channel<0) {
      tpmBase->SC = TPM_SC_CMOD(0);
      NVIC_DisableIRQ(interruptNumber);
   }
   else {
      // Clear channel register
      tpmBase->CONTROLS[channel].CnSC = 0;
   }
}
