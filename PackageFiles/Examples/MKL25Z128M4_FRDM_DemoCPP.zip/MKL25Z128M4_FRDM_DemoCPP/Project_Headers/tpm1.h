/*
 * tpm0.h
 *
 *  Created on: 23/11/2013
 *      Author: podonoghue
 */

#ifndef TPM1_H_
#define TPM1_H_

#include "tpm.h"

/*
 * TPM Clock sources
 */
#define _TPM1_CLOCK0 (0) // Disabled
#define _TPM1_CLOCK1 SYSTEM_TPM_CLOCK
#define _TPM1_CLOCK2 SYSTEM_PERIPHERAL_CLOCK
#define _TPM1_CLOCK3 (0) // External TPM_CLKINx clock - not defined

#define _TPM1_CLOCK_FREQUENCY_BASE  _TPM1_CLOCK2

// Choice of prescale value (FTM_SC.PS)
#define _TPM1_PRESCALE_VALUE    (7)
#define _TPM1_PRESCALE          (1<<_TPM1_PRESCALE_VALUE)
#define TPM1_CLOCK_FREQUENCY    (_TPM1_CLOCK_FREQUENCY_BASE/_TPM1_PRESCALE)

//! Macro to convert milliseconds to TPM ticks
#define TPM1_MILLISECONDS_TO_TICKS(ms)    (((ms)*TPM1_CLOCK_FREQUENCY)/1000)

#if (_TPM1_CLOCK_FREQUENCY_BASE == _TPM1_CLOCK0)
#define TPM1_SC_CMOD_VALUE (0)
#elif (_TPM1_CLOCK_FREQUENCY_BASE == _TPM1_CLOCK1)
#define TPM1_SC_CMOD_VALUE (1)
#elif (_TPM1_CLOCK_FREQUENCY_BASE == _TPM1_CLOCK2)
#define TPM1_SC_CMOD_VALUE (2)
#elif (_TPM1_CLOCK_FREQUENCY_BASE == _TPM1_CLOCK3)
#define TPM1_SC_CMOD_VALUE (3)
#else
#error "Check _TPM1_CLOCK_FREQUENCY_BASE value in pwm.h"
#endif

// Number of PTM Channels
#define PTM1_CHANNEL_COUNT (2)

extern "C" {
   void TPM1_IRQHandler(void);
}

class TPM_1 : public TPM {

public:
   /*!
    *  Constructor
    */
   TPM_1() : TPM((TPM0_Type*)TPM1_BASE_PTR, TPM1_IRQn, SIM_SCGC6_TPM1_MASK) {
   }

   /*! Initialises TPM for PWM
    *
    *  @param period    - PWM Period in ticks (use PWM0_MILLISECOND() macro)
    *  @param Pwm_Mode  - Centre align all waveforms from this PWM
    *
    * Configures:
    *   - Enables TPM clock
    *   - Sets TPM CNTIN & MOD values
    *   - Enables TPM
    */
   void initialiseAsPWM(int period /* ticks */, Pwm_Mode mode) {
      TPM::initialise(period, TPM_SC_CMOD(TPM1_SC_CMOD_VALUE)|TPM_SC_PS(_TPM1_PRESCALE_VALUE)|mode);
   }

   /*! Initialises TPM for Input capture/Output compare
    *
    * Configures:
    *   - Enables TPM clock
    *   - Sets FTM0 CNTIN & MOD values
    *   - Enables TPM
    */
   void initialise(void) {
      TPM::initialise(0xFFFF, tpm_leftAlign);
   }

#ifndef TPM1_USES_NAKED_HANDLERS

   friend void TPM1_IRQHandler(void);

private:
   static FtmChannelInformation channelInformation[PTM1_CHANNEL_COUNT];

   /*! Set callback for FTM channel
    *
    *  @param channel   - FTM0 channel to set callback for
    */
public:
   void setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval);

#endif

};

#endif /* TPM1_H_ */
