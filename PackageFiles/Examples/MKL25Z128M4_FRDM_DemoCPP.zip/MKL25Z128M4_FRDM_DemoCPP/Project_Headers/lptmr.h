/*
 * lptmr.h
 *
 *  Created on: 12/11/2013
 *      Author: podonoghue
 */

#ifndef LPTMR_H_
#define LPTMR_H_

#include "clock.h"
#include "clock_private.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SYSTEM_LPTMR0_CLOCK            (SYSTEM_BUS_CLOCK)
#define _LPTRM_PRESCALE_MASK_VALUE     (4)
#define _LPTRM_PRESCALE                (1<<(_LPTRM_PRESCALE_MASK_VALUE+1))
#define LPTMR_CLOCK_FREQUENCY          (SYSTEM_LPTMR0_CLOCK/_LPTRM_PRESCALE)

//! Macro to convert milliseconds to LPTMR ticks
#define LPTMR_MILLISECOND_TO_TICKS(ms) (((ms)*LPTMR_CLOCK_FREQUENCY)/1000)

#if ((LPTMR_CLOCK_FREQUENCY/1000000) > 0)
// Only usable with a fast clock
//! Macro to convert microseconds to LPTMR ticks
#define LPTMR_MICROSECOND_TO_TICKS(us) (((us)*LPTMR_CLOCK_FREQUENCY)/1000000)
#endif

void lptmr_initialise(uint16_t interval /* ticks */);
void lptmr_finalise(void);

#ifndef LPTMR_USES_NAKED_HANDLERS
   typedef void (*LPTMRCallbackFunction)(void);
   LPTMRCallbackFunction lptmr_setCallbackFunction(LPTMRCallbackFunction callback);
#endif

#ifdef __cplusplus
}
#endif

#endif /* LPTMR_H_ */
