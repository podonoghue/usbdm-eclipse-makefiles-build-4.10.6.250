/*
 * tpm.h
 *
 *  Created on: 23/11/2013
 *      Author: podonoghue
 */

#ifndef TPM_H_
#define TPM_H_

#include "derivative.h"

typedef enum  {
   tpm_inputCaptureRisingEdge  = TPM_CnSC_ELSA_MASK,
   tpm_inputCaptureFallingEdge = TPM_CnSC_ELSB_MASK,
   tpm_inputCaptureEitherEdge  = TPM_CnSC_ELSB_MASK|TPM_CnSC_ELSA_MASK,
   tpm_outputCompare           = TPM_CnSC_MSA_MASK,
   tpm_outputCompareToggle     = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSA_MASK,
   tpm_outputCompareClear      = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSB_MASK,
   tpm_outputCompareSet        = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSB_MASK|TPM_CnSC_ELSA_MASK,
   tpm_pwmHighTruePulses       = TPM_CnSC_MSB_MASK|TPM_CnSC_ELSB_MASK,
   tpm_pwmLowTruePulses        = TPM_CnSC_MSB_MASK|TPM_CnSC_ELSA_MASK,
} Ftm_Mode;

typedef enum {
   tpm_leftAlign   = 0,
   tpm_centreAlign = TPM_SC_CPWMS_MASK,
} Pwm_Mode;

typedef void (*FTMCallbackFunction)(void);

class TPM {

protected:

   struct FtmChannelInformation {
      FTMCallbackFunction callback;
      uint16_t            interval;
   };

   TPM0_Type       *tpmBase;
   IRQn_Type        interruptNumber;

   TPM(TPM0_Type *tpmBase, IRQn_Type interruptNumber, uint32_t clockMask);
   void initialise(int period, uint8_t mode);

public:
   void initialiseChannel(int channel, Ftm_Mode mode);
   void setDutyCycle(int channel, int dutyCycle);
   void finaliseChannel(int channel);
};
#endif /* TPM_H_ */
