/*
 * i2c.h
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */

#ifndef I2C_H_
#define I2C_H_

#ifdef __cplusplus
extern "C" {
#endif

void i2c_initialise(uint8_t myAddress, uint32_t bps);
void i2c_transmit(uint8_t address, const uint8_t data[], int size);
void i2c_waitWhileBusy(void);
void i2c_receive(uint8_t address, uint8_t data[], int size);

#ifdef __cplusplus
}
#endif

#endif /* I2C_H_ */
