/*
 * tpm0.h
 *
 *  Created on: 23/11/2013
 *      Author: podonoghue
 */

#ifndef TPM0_H_
#define TPM0_H_

#include "tpm.h"

/*
 * TPM Clock sources
 */
#define _TPM0_CLOCK0 (0) // Disabled
#define _TPM0_CLOCK1 SYSTEM_TPM_CLOCK
#define _TPM0_CLOCK2 SYSTEM_PERIPHERAL_CLOCK
#define _TPM0_CLOCK3 (0) // External TPM_CLKINx clock - not defined

#define _TPM0_CLOCK_FREQUENCY_BASE  _TPM0_CLOCK2

// Choice of prescale value (FTM_SC.PS)
#define _TPM0_PRESCALE_VALUE    (7)
#define _TPM0_PRESCALE          (1<<_TPM0_PRESCALE_VALUE)
#define TPM0_CLOCK_FREQUENCY    (_TPM0_CLOCK_FREQUENCY_BASE/_TPM0_PRESCALE)

//! Macro to convert milliseconds to TPM ticks
#define TPM0_MILLISECONDS_TO_TICKS(ms)    (((ms)*TPM0_CLOCK_FREQUENCY)/1000)

#if (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK0)
#define TPM0_SC_CMOD_VALUE (0)
#elif (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK1)
#define TPM0_SC_CMOD_VALUE (1)
#elif (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK2)
#define TPM0_SC_CMOD_VALUE (2)
#elif (_TPM0_CLOCK_FREQUENCY_BASE == _TPM0_CLOCK3)
#define TPM0_SC_CMOD_VALUE (3)
#else
#error "Check _TPM0_CLOCK_FREQUENCY_BASE value in pwm.h"
#endif

// Number of PTM Channels
#define PTM0_CHANNEL_COUNT (6)

extern "C" {
   void TPM0_IRQHandler(void);
}

class TPM_0 : public TPM {

public:
   /*!
    *  Constructor
    */
   TPM_0() : TPM((TPM0_Type*)TPM0_BASE_PTR, TPM0_IRQn, SIM_SCGC6_TPM0_MASK) {
   }

   /*! Initialises TPM for PWM
    *
    *  @param period    - PWM Period in ticks (use PWM0_MILLISECOND() macro)
    *  @param Pwm_Mode  - Centre align all waveforms from this PWM
    *
    * Configures:
    *   - Enables TPM clock
    *   - Sets TPM CNTIN & MOD values
    *   - Enables TPM
    */
   void initialiseAsPWM(int period /* ticks */, Pwm_Mode mode) {
      TPM::initialise(period, TPM_SC_CMOD(TPM0_SC_CMOD_VALUE)|TPM_SC_PS(_TPM0_PRESCALE_VALUE)|mode);
   }

   /*! Initialises TPM for Input capture/Output compare
    *
    * Configures:
    *   - Enables TPM clock
    *   - Sets FTM0 CNTIN & MOD values
    *   - Enables TPM
    */
   void initialise(void) {
      TPM::initialise(0xFFFF, tpm_leftAlign);
   }

#ifndef TPM0_USES_NAKED_HANDLERS

   friend void TPM0_IRQHandler(void);

private:
   static FtmChannelInformation channelInformation[PTM0_CHANNEL_COUNT];

   /*! Set callback for FTM channel
    *
    *  @param channel   - FTM0 channel to set callback for
    */
public:
   void setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval);

#endif

};

#endif /* TPM0_H_ */
