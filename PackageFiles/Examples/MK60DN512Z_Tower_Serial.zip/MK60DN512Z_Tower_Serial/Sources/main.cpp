/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include "derivative.h"
#include "leds.h"
#include "uart.h"

void delay(void) {
   volatile unsigned long i;
   for (i=400000; i>0; i--) {
	   asm("nop");
   }
}

int main(void) {
   led_initialise();
   greenLedOn();

   uart_initialise(19200);

   printf("\n\r"
         "==============================\n\r"
         "       Hello World\n\r"
         "==============================\n\r");

   int i = 0;
   for(;;) {
      printf("i = %d\n\r", i++);
      greenLedToggle();
   }
   for(;;) {
      redLedToggle();
      delay();
      redLedToggle();
      delay();
      orangeLedToggle();
      delay();
      orangeLedToggle();
      delay();
      greenLedToggle();
      delay();
      greenLedToggle();
      delay();
      blueLedToggle();
      delay();
      blueLedToggle();
      delay();
   }
}
