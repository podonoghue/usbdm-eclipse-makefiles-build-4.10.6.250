/*
 * uart.cpp
 *
 *  Created on: 14/04/2013
 *      Author: pgo
 */

#include <derivative.h>
#include "clock.h"
#include "uart.h"
#include "Freedom.h"
#include "utilities.h"

#define UART_TX_PIN_MASK      (1<<UART_TX_PIN_NUM)
#define UART_TX_PIN_PCR       PCR(UART_TX_PIN_PORT,UART_TX_PIN_NUM)
//#define UART_TX_PIN_PDOR      PDOR(UART_TX_PIN_PORT)
//#define UART_TX_PIN_PSOR      PSOR(UART_TX_PIN_PORT)  // Data set
//#define UART_TX_PIN_PCOR      PCOR(UART_TX_PIN_PORT)  // Data clear
//#define UART_TX_PIN_PTOR      PTOR(UART_TX_PIN_PORT)  // Data toggle
//#define UART_TX_PIN_PDIR      PDIR(UART_TX_PIN_PORT)  // Data input
//#define UART_TX_PIN_PDDR      PDDR(UART_TX_PIN_PORT)  // Data direction

#define UART_RX_PIN_MASK      (1<<UART_RX_PIN_NUM)
#define UART_RX_PIN_PCR       PCR(UART_RX_PIN_PORT,UART_RX_PIN_NUM)
//#define UART_RX_PIN_PDOR      PDOR(UART_RX_PIN_PORT)
//#define UART_RX_PIN_PSOR      PSOR(UART_RX_PIN_PORT)  // Data set
//#define UART_RX_PIN_PCOR      PCOR(UART_RX_PIN_PORT)  // Data clear
//#define UART_RX_PIN_PTOR      PTOR(UART_RX_PIN_PORT)  // Data toggle
//#define UART_RX_PIN_PDIR      PDIR(UART_RX_PIN_PORT)  // Data input
//#define UART_RX_PIN_PDDR      PDDR(UART_RX_PIN_PORT)  // Data direction

//#define SIM_SCGC_UARTnm(clock_num,uart_num)    CONCAT5_(SIM_SCGC,clock_num,_UART,uart_num,_MASK)
//#define SIM_SCGCn(clock_num)                   CONCAT2_(SIM_SCGC,clock_num)
//#define SIM_SOPTn()
//
//#define UART_CLOCK_NUM       1
//
//#define SIM_SCGC_UART_MASK   SIM_SCGC_UARTnm(UART_CLOCK_NUM, UART_NUM)
//#define SIM_SCGC             SIM_SCGCn(UART_CLOCK_NUM)
//#define SIM_SOPT

void Uart5Init(int baudrate) {
   uint16_t ubd;

   // Enable clock to UART
   SIM_SCGC1 |= SIM_SCGC1_UART5_MASK;

   SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK;
   PCR(UART_TX_PIN_PORT, UART_TX_PIN_NUM) = PORT_PCR_MUX(UART_TX_PIN_FN);
   PCR(UART_RX_PIN_PORT, UART_RX_PIN_NUM) = PORT_PCR_MUX(UART_RX_PIN_FN);

   // Set Tx & Rx Pin function
   UART_TX_PIN_PCR = PORT_PCR_MUX(UART_TX_PIN_FN) | PORT_PCR_DSE_MASK;
   UART_RX_PIN_PCR = PORT_PCR_MUX(UART_RX_PIN_FN);

//   // Set Tx & Rx pins in use
//   SIM_SOPT5 &= ~(SIM_SOPT5_UART0RXSRC_MASK|SIM_SOPT5_UART0TXSRC_MASK);

   // Disable UART before changing registers
   UART5_C2 &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK);

   // Calculate baud settings
   ubd = (uint16_t)(SystemBusClock/(baudrate * 16));

   // Set Baud rate register
   UART5_BDH = (UART5_BDH&~UART_BDH_SBR_MASK) | UART_BDH_SBR((ubd>>8));
   UART5_BDL = UART_BDL_SBR(ubd);

#ifdef UART_C4_BRFA_MASK
   // Determine fractional divider to get closer to the baud rate
   uint16_t brfa;
   brfa     = (uint8_t)(((SystemCoreClock*32000)/(baudrate * 16)) - (ubd * 32));
   UART5_C4 = (UART5_C4&~UART_C4_BRFA_MASK) | UART_C4_BRFA(brfa);

#endif
   UART5_C1 = 0;

   // Enable UART Tx & Rx
   UART5_C2 = UART_C2_TE_MASK|UART_C2_RE_MASK;
}

void Uart5TxChar(int ch) {
   while ((UART5_S1 & UART_S1_TDRE_MASK) == 0) {
      // Wait for Tx buffer empty
   }
   UART5_D = ch;
}

int Uart5RxChar(void) {
   while ((UART0_S1 & UART_S1_RDRF_MASK) == 0) {
      // Wait for Rx buffer full
   }
   return UART5_D;
};

void uart_initialise(int baudRate) {
   Uart5Init(baudRate);
}

void uart_txChar(int ch) {
   Uart5TxChar(ch);
}

int uart_rxChar(void) {
   return Uart5RxChar();
}
