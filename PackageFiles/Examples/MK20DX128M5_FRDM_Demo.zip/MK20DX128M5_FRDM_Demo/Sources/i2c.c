/*
 * i2c.c
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */
#include <stdbool.h>
#include <stdio.h>
#include "derivative.h"
#include "utilities.h"
#include "Freedom.h"
#include "clock.h"
#include "i2c.h"

#define I2C_F_MULT_VALUE    (1)
#define I2C_F_ICR_VALUE     (0x6) // SCL diver = 34, See table 44-28 in RM

#if (I2C_F_MULT_VALUE>2)
#error "I2C_F_MULT_VALUE is too large"
#endif
#if (I2C_F_ICR_VALUE>=(1<<6))
#error "I2C_F_ICR_VALUE is too large"
#endif

#define I2C_BAUD_RATE SYSTEM_BUS_CLOCK/((1<<I2C_F_MULT_VALUE)*34)

enum {i2c_idle, i2c_txAddr, i2c_rxAddr, i2c_txData, i2c_rxData } i2cMode;
uint8_t *dataPtr;
int      dataBytesRemaining;

void I2C0_IRQHandler(void);

/*
 * Initialise the I2C interface
 *
 * @param slaveAddress - not used as slave interface is not handled.
 *
 */
void i2c_initialise(uint8_t slaveAddress) {

   // Configure I2C pins
   SIM_SCGC5 |= I2C_SCL_CLOCK_MASK|I2C_SDA_CLOCK_MASK;
   PCR(I2C_SCL_PORT,I2C_SCL_PIN_NUM) = PORT_PCR_MUX(I2C_SCL_FN);
   PCR(I2C_SDA_PORT,I2C_SDA_PIN_NUM) = PORT_PCR_MUX(I2C_SDA_FN);

   // Enable clock to I2C interface
   SIM_SCGC4 |=SIM_SCGC4_I2C0_MASK;

   // Enable I2C peripheral
   I2C0_C1 = I2C_C1_IICEN_MASK;

   // Set baud rate
   I2C0_F  = I2C_F_MULT(I2C_F_MULT_VALUE)|I2C_F_ICR(I2C_F_ICR_VALUE);

   // Default options
   I2C0_C2 = 0;//I2C_C2_AD(address>>8);
   I2C0_A1 = slaveAddress&~1;

   NVIC_EnableIRQ(I2C0_IRQn);
}

typedef enum {
   i2c_polled    = 0,
   i2c_interrupt = I2C_C1_IICIE_MASK,
} i2c_Mode;

/*!
 * Start TxRx sequence
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
static void i2c_startTxRx(uint8_t address, uint8_t data[], int size, i2c_Mode mode) {

   // Set up transmit or receive data
   dataPtr            = data;
   dataBytesRemaining = size;

   // Configure for Tx of address
   I2C0_C1 = I2C_C1_IICEN_MASK|mode|I2C_C1_TX_MASK;
   I2C0_C1 = I2C_C1_IICEN_MASK|mode|I2C_C1_TX_MASK|I2C_C1_MST_MASK;
   // Tx address (starts interrupt process)
   I2C0_D  = I2C_D_DATA(address);
}

/*!
 * Start Tx sequence
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_startTransmit(uint8_t address, uint8_t data[], int size, i2c_Mode mode) {
   // Sending address byte of data transmission
   i2cMode = i2c_txAddr;
   i2c_startTxRx(address, data, size, mode);
}

/*!
 * Start Rx sequence
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_startReceive(uint8_t address, uint8_t data[], int size, i2c_Mode mode) {
   // Sending address byte of data transmission
   i2cMode = i2c_rxAddr;
   i2c_startTxRx(address|1, data, size, mode);
}

/*
 * Wait for current sequence to complete
 */
void i2c_waitWhileBusy(void) {
   while (i2cMode != i2c_idle) {
      I2C0_IRQHandler();
   }
}

/*!
 * Transmit data to slave and wait for completion
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_transmit(uint8_t address, uint8_t data[], int size) {
   i2c_startTransmit(address, data, size, i2c_polled);
   i2c_waitWhileBusy();
}

/*!
 * Receive data from slave and wait for completion
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_receive(uint8_t address, uint8_t data[], int size) {
   i2c_startReceive(address, data, size, i2c_polled);
   i2c_waitWhileBusy();
}

/*
 * I2C state-machine based interrupt handler
 */
void I2C0_IRQHandler(void) {
   if ((I2C0_S & I2C_S_IICIF_MASK) == 0) {
      return;
   }
   // Clear interrupt flag
   I2C0_S = I2C_S_IICIF_MASK;

   switch (i2cMode) {
      case i2c_txAddr:
         // Just sent address byte at start of Tx data
      case i2c_txData:
         // Just sent data byte
         if ((dataBytesRemaining-- == 0) || ((I2C0_S&I2C_S_RXAK_MASK) != 0)) {
            // Complete or failed
            i2cMode = i2c_idle;
            // Generate stop signal
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_IICIE_MASK|I2C_C1_TXAK_MASK;
            return;
         }
         else {
            // Transmit next byte
            i2cMode = i2c_txData;
            I2C0_D = *dataPtr++;
         }
         break;
      case i2c_rxAddr:
         // Just sent address byte at start of Rx data
         i2cMode = i2c_rxData;
         if (dataBytesRemaining == 1) {
            // Receiving a single byte
            // Switch to Rx mode (don't acknowledge last/single byte)
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_IICIE_MASK|I2C_C1_MST_MASK|I2C_C1_TXAK_MASK;
         }
         else {
            // Switch to Rx mode
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_IICIE_MASK|I2C_C1_MST_MASK;
         }
         // Dummy read of data to start Rx of 1st data byte
         (void)I2C0_D;
         break;
      case i2c_rxData:
         // Just received a data byte
         if (--dataBytesRemaining == 0) {
            // Received last byte - complete
            i2cMode = i2c_idle;
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_IICIE_MASK;
         }
         else if (dataBytesRemaining == 1) {
            // Received 2nd last byte (don't acknowledge the last byte to follow)
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_IICIE_MASK|I2C_C1_MST_MASK|I2C_C1_TXAK_MASK;
         }
         // Save receive data
         *dataPtr++ = I2C0_D;
         break;
      default:
         i2cMode = i2c_idle;
         break;
   }
}

