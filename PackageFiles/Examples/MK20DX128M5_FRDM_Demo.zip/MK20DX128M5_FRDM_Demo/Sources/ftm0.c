/*
 * pwm.c
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */
#include "stddef.h"
#include "utilities.h"
#include "clock.h"
#include "ftm0.h"

#if (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK0)
#define FTM_SC_CLKS_VALUE (0)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK1)
#define FTM_SC_CLKS_VALUE (1)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK2)
#define FTM_SC_CLKS_VALUE (2)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK3)
#define FTM_SC_CLKS_VALUE (3)
#else
#error "Check _FTM0_CLOCK_FREQUENCY_BASE value in pwm.h"
#endif

/*! Initialises FTM0 for PWM
 *
 *  @param period  - PWM Period in ticks (use PWM0_MILLISECOND() macro)
 *  @param mode    - Left- or centre-align all waveforms from this PWM
 *
 * Configures:
 *   - Enables FTM0 clock
 *   - Sets FTM0 CNTIN & MOD values
 *   - Enables FTM0
 */
void ftm0_initialiseAsPWM(int period /* ticks */, Pwm_Mode mode) {

   // Enable clock to FTM0
   SIM_SCGC6  |= SIM_SCGC6_FTM0_MASK;

   // Common registers
   FTM0_SC      = FTM_SC_CLKS(0); // Disable FTM so register changes are immediate
   FTM0_CNTIN   = 0;
   FTM0_CNT     = 0;
   if (mode == ftm_centreAlign) {
      FTM0_MOD     = period/2;
      // Centre aligned PWM with CPWMS not selected
      FTM0_SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE)|FTM_SC_CPWMS_MASK;
   }
   else {
      FTM0_MOD     = period-1;
      // Left aligned PWM without CPWMS selected
      FTM0_SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE);
   }
}

/*! Initialises FTM0 for Input capture/Output compare
 *
 * Configures:
 *   - Enables FTM0 clock
 *   - Sets FTM0 CNTIN & MOD values
 *   - Enables FTM0
 *
 *  Assumes Left-aligned PWM
 */
void ftm0_initialise(void) {
   ftm0_initialiseAsPWM(0xFFFF, ftm_leftAlign);
}

/*! Initialises FTM0 for Input capture/Output compare
 *
 *  @param channel   - FTM0 channel to initialise
 *  @param mode      - Mode for the channel
 */
void ftm0_initialiseChannel(int channel, Ftm_Mode mode) {
   FTM0_CnV(channel)  = 0;
   FTM0_CnSC(channel) = mode;
}

/*!
 *  Sets the duty cycle of the PWM waveform
 *
 *  @param channel   - FTM0 channel to use
 *  @param dutyCycle - duty cycle in percentage (0-100)
 *
 */
void ftm0_setDutyCycle(int channel, int dutyCycle) {
   if (FTM0_SC&FTM_SC_CPWMS_MASK) {
      FTM0_CnV(channel)  = (dutyCycle*FTM0_MOD)/100;
   }
   else {
      FTM0_CnV(channel)  = (dutyCycle*(FTM0_MOD+1))/100;
   }
}

/*!
 *  Disables a FTM channel or entire FTM
 *
 *  @param channel   - FTM0 channel to disable, -1 disable entire FTM
 *
 */
void ftm0_finaliseChannel(int channel) {
   if (channel<0) {
      FTM0_SC = FTM_SC_CLKS(0);
      NVIC_DisableIrq(INT_FTM0);
   }
   else {
      // Clear channel register
      FTM0_CnSC(channel) = 0;
   }
}

#ifndef FTM_USES_NAKED_HANDLERS

typedef struct {
   FTMCallbackFunction callback;
   uint16_t            interval;
} FtmChannelInformation;

static FtmChannelInformation ftmChannelInformation[8] = {{NULL}};

/*! Initialises FTM0 for Input capture/Output compare
 *
 *  @param channel   - FTM0 channel to initialise
 */
FTMCallbackFunction ftm0_setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval) {

   FTMCallbackFunction temp = ftmChannelInformation[channel].callback;
   ftmChannelInformation[channel].callback = callback;
   ftmChannelInformation[channel].interval = interval;
   FTM0_CnSC(channel) |= FTM_CnSC_CHIE_MASK;
   NVIC_EnableIrq(INT_FTM0);
   return temp;
}

void FTM0_IRQHandler(void) {
   // This method is better for the usual case of a single interrupt at a time
   int channel = 0;
   if (FTM0_STATUS & 0xF0) {
      channel = 4;
   }
   if (FTM0_STATUS & 0xCC) {
      channel += 2;
   }
   if (FTM0_STATUS & 0xAA) {
      channel++;
   }
   // Clear flag
   FTM0_CnSC(channel) &= ~FTM_CnSC_CHF_MASK;
   if (ftmChannelInformation[channel].interval != 0) {
      // Set interval
      FTM0_CnV(channel) += ftmChannelInformation[channel].interval;
   }
   if (ftmChannelInformation[channel].callback != NULL) {
      // Do callback
      ftmChannelInformation[channel].callback();
   }
}
#endif
