/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include <stdbool.h>
#include <sys/time.h>
#include <time.h>
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "pit.h"
#include "lptmr.h"
#include "rtc.h"
#include "ftm0.h"

// LPTMR ==============================================================

#define LPTMR_INTERVAL LPTMR_MILLISECOND_TO_TICKS(10)

#if (LPTMR_INTERVAL>65536)
#error "LPTMR Value is too large"
#endif

void blueLedToggleEnable(void) {
   static bool oddEven = true;

   if (oddEven) {
      blueLedEnable();
   }
   else {
      blueLedDisable();
   }
   oddEven = !oddEven;
}

// RTC ==============================================================

void clockTick(void) {
   time_t currentTime;
   struct tm *timeInfo;

   currentTime = time(NULL);
   timeInfo = localtime(&currentTime);
   printf("\'Tick\' - %s", asctime(timeInfo));
}

void clockAlarm(void) {
   // Set next alarm for 10 seconds from last alarm
   uint32_t theTime   = rtc_getTime() + 5;
   uint32_t alarmTime = rtc_getAlarmTime() + 10;
   if (theTime>alarmTime) {
      alarmTime = theTime;
   }
   rtc_setAlarmTime(alarmTime);
   time_t currentTime;
   struct tm *timeInfo;

   currentTime = time(NULL);
   timeInfo = localtime(&currentTime);
   printf("\'**** ALARM ****\' - %s", asctime(timeInfo));

}

static unsigned tick = 0;

void rtcCallback(void) {
   tick++;
}

// PWM0 ==============================================================

#define PWM0_PERIOD (FTM0_MILLISECONDS_TO_TICKS(100))

#if (PWM0_PERIOD<200)
#error "PWM0_PERIOD is too small (resolution < 1%)"
#endif
#if (PWM0_PERIOD>65535)
#error "PWM0_PERIOD is too large"
#endif

// PTC1(Fn4) = FTM0_CH0 = PWM0_CH0
#define FTM0_CH0_PORT         C
#define FTM0_CH0_PIN_NUM      1
#define FTM0_CH0_FN           4
#define FTM0_CH0_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTC2(Fn4) = FTM0_CH1 = PWM0_CH1
#define FTM0_CH1_PORT         C
#define FTM0_CH1_PIN_NUM      2
#define FTM0_CH1_FN           4
#define FTM0_CH1_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTC4(Fn4) = FTM0_CH3 = PWM0_CH3
#define FTM0_CH3_PORT         C
#define FTM0_CH3_PIN_NUM      4
#define FTM0_CH3_FN           4
#define FTM0_CH3_CLOCK_MASK   SIM_SCGC5_PORTC_MASK

// PTE20(Fn3) = FTM1_CH0 = PWM1_CH0
#define FTM1_CH0_PORT         E
#define FTM1_CH0_PIN_NUM      20
#define FTM1_CH0_FN           3
#define FTM1_CH0_CLOCK_MASK   SIM_SCGC5_PORTE_MASK

// PTE22(Fn3) = FTM2_CH0 = PWM2_CH0
#define FTM2_CH0_PORT         E
#define FTM2_CH0_PIN_NUM      22
#define FTM2_CH0_FN           3
#define FTM2_CH0_CLOCK_MASK   SIM_SCGC5_PORTE_MASK

void configureFTMPins(void) {
   SIM_SCGC5 |= FTM0_CH0_CLOCK_MASK|FTM0_CH1_CLOCK_MASK|FTM0_CH3_CLOCK_MASK|FTM1_CH0_CLOCK_MASK|FTM2_CH0_CLOCK_MASK;
//   PCR(FTM0_CH0_PORT,FTM0_CH0_PIN_NUM) = PORT_PCR_MUX(FTM0_CH0_FN);
   PCR(FTM0_CH1_PORT,FTM0_CH1_PIN_NUM) = PORT_PCR_MUX(FTM0_CH1_FN);
   PCR(FTM0_CH3_PORT,FTM0_CH3_PIN_NUM) = PORT_PCR_MUX(FTM0_CH3_FN);
//   PCR(FTM1_CH0_PORT,FTM1_CH0_PIN_NUM) = PORT_PCR_MUX(FTM1_CH0_FN);
//   PCR(FTM2_CH0_PORT,FTM2_CH0_PIN_NUM) = PORT_PCR_MUX(FTM2_CH0_FN);
}

// Configures the CLOCKOUT pin
void configureClockOutPin(void) {
   // PTC3(Fn5) = CLKOUT
   SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   PORTC_PCR3 = PORT_PCR_MUX(5);

   //    CLKOUT = CLKOUTSEL(4) = MCGIRCLK
   SIM_SOPT2 = (SIM_SOPT2&~SIM_SOPT2_CLKOUTSEL_MASK)|SIM_SOPT2_CLKOUTSEL(4);
}

// Configures the CLOCKOUT pin
void configureRTCClockInPin(void) {
   // PTC1(Fn1) = RTC_CLKIN
   SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   PORTC_PCR1 = PORT_PCR_MUX(1);
}

// PIT ==============================================================

//#define PIT_PERIOD (PIT_MICROSECOND_TO_TICKS(100))
#define PIT_PERIOD (PIT_MILLISECOND_TO_TICKS(100))

//==================================================================
#if 1
int main(void) {
   // Release pin isolation
   //PMC_REGSC |= PMC_REGSC_ACKISO_MASK;

   printf("\n"
         "==========================\n"
         "Starting\n"
         "==========================\n");

   __enable_interrupt();

   led_initialise();

   // PTC.3(Fn5) = CLKOUT
   //SIM_SCGC5 |= SIM_SCGC5_PORTC_MASK;
   //PORTC_PCR3 = PORT_PCR_MUX(5);
   // CLKOUT = CLKOUTSEL(4) = MCGIRCLK
   //SIM_SOPT2 = (SIM_SOPT2&~SIM_SOPT2_CLKOUTSEL_MASK)|SIM_SOPT2_CLKOUTSEL(4);

   configureFTMPins();
   ftm0_initialiseAsPWM(PWM0_PERIOD, ftm_centreAlign);
   ftm0_initialiseChannel(1, ftm_pwmLowTruePulses);
   ftm0_initialiseChannel(3, ftm_pwmHighTruePulses);

   pit_setCallbackFunction(0, blueLedToggle);
   pit_initialise(0, PIT_PERIOD);

   lptmr_setCallbackFunction(blueLedToggleEnable);
   lptmr_initialise(LPTMR_INTERVAL);

   // For KL25 output Slow IRC on PTC3 (~ 32 Khz)
   configureClockOutPin();
   // For KL25 input RTC_CLKIN on PTC1
   configureRTCClockInPin();
   rtc_setAlarmCallback(clockAlarm, rtc_getTime()+10);
   rtc_setSecondsCallback(rtcCallback);

   for(;;) {
      __wait_for_interrupt();
      unsigned lastTick;
      if (tick != lastTick) {
         // Executed @ 1Hz
         clockTick();
         int dutyCycle = tick%101;
         ftm0_setDutyCycle(1, dutyCycle);
         ftm0_setDutyCycle(3, dutyCycle);
         printf("Duty Cycle = %d\n", dutyCycle);
      }
      lastTick = tick;
   }
}
#else

#define FTM0_CH0_PERIOD FTM0_MILLISECONDS_TO_TICKS(1)
#if FTM0_CH0_PERIOD > 65535
#error "FTM0_CH0_PERIOD is too large"
#endif

#define FTM0_CH1_PERIOD FTM0_MILLISECONDS_TO_TICKS(20)
#if FTM0_CH1_PERIOD > 65535
#error "FTM0_CH1_PERIOD is too large"
#endif

#define PIT_CH0_PERIOD PIT_MILLISECOND_TO_TICKS(10)
#define PIT_CH1_PERIOD PIT_MILLISECOND_TO_TICKS(200)

int main(void) {
   printf("\n"
         "==========================\n"
         "Starting\n"
         "==========================\n");

   __enable_interrupt();

   led_initialise();

#if 0
   /*
    * This test configures two FTM channels to toggle their respective pins in hardware.
    * In addition the callbacks are used to pulse modulate the Blue LED.
    */
   printf("FTM Base Clock = %lu, FTM clock = %lu Hz, interval = %lu\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);
   configureFTMPins();
   ftm0_initialise();
   ftm0_initialiseChannel(0,ftm_outputCompareToggle);
   ftm0_setCallbackFunction(0,blueLedToggle,FTM0_CH0_PERIOD);
   ftm0_initialiseChannel(1,ftm_outputCompareToggle);
   ftm0_setCallbackFunction(1,blueLedToggleEnable,FTM0_CH1_PERIOD);
#elif 0
   /*
    * This test configures two FTM channels as PWM with fixed duty-cycle.
    * One channel is inverted.
    * Channels are centre-aligned.
    */
   printf("FTM Base Clock = %lu, FTM clock = %lu Hz, interval = %lu\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);
   configureFTMPins();
   ftm0_initialiseAsPWM(PWM0_PERIOD, ftm_centreAlign);
   ftm0_initialiseChannel(0, ftm_pwmHighTruePulses);
   ftm0_setDutyCycle(0, 50);
   ftm0_initialiseChannel(1, ftm_pwmLowTruePulses);
   ftm0_setDutyCycle(1, 25);
#elif 0
   /*
    * This test configures the Low Power Timer (LPTMR) for a fixed period.
    * A callback is used to modulate the Blue LED.
    */
   printf("LPTMR clock = %lu Hz, interval = %lu\n", LPTMR_CLOCK_FREQUENCY, LPTMR_INTERVAL);
   lptmr_setCallbackFunction(blueLedToggle);
   lptmr_initialise(LPTMR_INTERVAL);
#elif 0
   /*
    * This test configures two PIT channels
    * Callbacks are used to pulse modulate the Blue LED.
    */
   printf("PIT clock = %lu Hz, Ch0 Period = %lu, Ch1 Period = %lu\n", PIT_CLOCK_FREQUENCY, PIT_CH0_PERIOD, PIT_CH1_PERIOD);
   pit_setCallbackFunction(0, blueLedToggle);
   pit_initialise(0, PIT_CH0_PERIOD);
   pit_setCallbackFunction(1, blueLedToggleEnable);
   pit_initialise(1, PIT_CH1_PERIOD);
#else
   /*
    * This test does the following:
    *  The RTC 1 second callback is used to toggle the Blue LED.
    *
    *  The RTC functionality is integrated with the C "time" functions.
    *  The current time is reported every second.
    *
    *  An Alarm is reset for every 10 seconds.
    *  The RTC alarm callback reports the current time ~ alarm time.
    *
    *  NOTE: Since the time has not been set correctly this will be erroneous.
    *  NOTE: On KL25 it is necessary to connect PTC3 -> PTC1 to provide a suitable RTC clock
    *
    *  Commented out:
    *  Continuously report the RTC counter values.
    *
    *  On a KL25 the RTC clock is not configured correctly (the 1KHz LOP is used rather than a 32kHz clock) so
    *  the times are scaled accordingly (~x32).
    */
   printf("ERCLK32K clock = %lu\n", SYSTEM_ERCLK32K_CLOCK);
   printf("MCGIRCLK clock = %lu\n", SYSTEM_MCGIRCLK_CLOCK);

   // For KL25 output Slow IRC on PTC3 (~ 32 Khz)
   configureClockOutPin();
   // For KL25 input RTC_CLKIN on PTC1
   configureRTCClockInPin();
   rtc_setSecondsCallback(blueLedToggle);
   rtc_setAlarmCallback(clockAlarm, rtc_getTime()+10);
   for(;;) {
      unsigned lastTick;
      unsigned currentTick = RTC_TSR;
      if (currentTick != lastTick) {
         // Executed @ 1Hz
         clockTick();
         lastTick = currentTick;
      }
//      printf("RTC_TCR:RTC_TPR = %lu:%lu \n", RTC_TSR, RTC_TPR);
   }
#endif

   for(;;) {
      __wait_for_interrupt();
   }
}
#endif
