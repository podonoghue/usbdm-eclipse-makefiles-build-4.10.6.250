/*
 * clock.c
 *
 *  Created on: 04/03/2012
 *      Author: podonoghue
 */
#include "derivative.h" /* include peripheral declarations */
#include "clock.h"
#include "utilities.h"

/*
 * Device clock parameters
 */

// SYSTEM_ERCLK32K_CLOCK ==============================

// Select ERCLK32K clock source 0,1,2,3 -> OSC32KCLK,-,RTC_CLKIN,LPO_CLOCK
#if (SYSTEM_ERCLK32K_CLOCK == _ERCLK32K_CLOCK0)
#define SIM_SOPT1_OSC32KSEL_VALUE (0)
#elif (SYSTEM_ERCLK32K_CLOCK == _ERCLK32K_CLOCK2)
#define SIM_SOPT1_OSC32KSEL_VALUE (2)
#elif (SYSTEM_ERCLK32K_CLOCK == _ERCLK32K_CLOCK3)
#define SIM_SOPT1_OSC32KSEL_VALUE (3)
#else
#error "Fix SYSTEM_ERCLK32K_CLOCK definition in Clock.h"
#endif

// SYSTEM_MCGIRCLK_CLOCK ==============================

// Select SYSTEM_MCGIRCLK_CLOCK source 0,MCG_C2_IRCS_MASK -> Slow,Fast IRC
#if (SYSTEM_MCGIRCLK_CLOCK == _MCGIRCLK_CLOCK0)
#define MCG_C2_IRCS_VALUE 0
#elif (SYSTEM_MCGIRCLK_CLOCK == _MCGIRCLK_CLOCK1)
#define MCG_C2_IRCS_VALUE MCG_C2_IRCS_MASK
#else
#error  "Fix SYSTEM_MCGIRCLK_CLOCK value in Clock.h"
#endif

// SYSTEM_OSCERCLK_CLOCK ==============================

// Make SYSTEM_OSCERCLK_CLOCK available to system if used
#if (SYSTEM_OSCERCLK_CLOCK == 0)
#define OSC_CR_ERCLKEN_VALUE (0)
#else
#define OSC_CR_ERCLKEN_VALUE OSC_CR_ERCLKEN_MASK
#endif

// _MCGFLLCLK_CLOCK  ==============================

#define MCG_C2_RANGE0_VALUE (1) // 0,1,2 -> low, high, very-high range XTAL
#define MCG_C1_FRDIV_VALUE  (3) // Divider for External Reference Clock
#define MCS_C7_OSCSEL_VALUE (0) // MCG OSC Clock Select 0,1 -> OSCCLK, 32 kHz RTC

#if (MCS_C7_OSCSEL_VALUE == 0)
#define ERC_CLOCK    SYSTEM_OSCCLK              // External reference clock
#elif (MCS_C7_OSCSEL_VALUE == 0)
#define ERC_CLOCK    SYSTEM_SLOW_IRC_CLOCK      // Slow internal reference clock (nom 32K)
#else
#error "Check MCS_C7_OSCSEL_VALUE in clock.c"
#endif

#if (MCG_C2_RANGE0_VALUE == 0) || (MCS_C7_OSCSEL_VALUE!=0)
#define ERC_AFTER_FRDIV_CLOCK (ERC_CLOCK/(1<<MCG_C1_FRDIV_VALUE))
#else
#define ERC_AFTER_FRDIV_CLOCK (ERC_CLOCK/(1<<(MCG_C1_FRDIV_VALUE+5)))
#endif

#if (ERC_AFTER_FRDIV_CLOCK > 39062) || (ERC_AFTER_FRDIV_CLOCK < 31250)
#error "External reference clock must be in range 31.25 kHz to 39.0625 kHz"
#endif

#if (_ERC_AFTER_FRDIV_CLOCK != ERC_AFTER_FRDIV_CLOCK)
#error "Check ERC_AFTER_FRDIV_CLOCK value in clock.h"
#endif

// SYSTEM_MCGFFCLK_CLOCK  ==============================

#if (SYSTEM_MCGFFCLK_CLOCK == _MCGFFCLK0)
#define MCG_C1_IREFS_VALUE (0)
#elif (SYSTEM_MCGFFCLK_CLOCK == _MCGFFCLK1)
#define MCG_C1_IREFS_VALUE (1)
#else
#error "Check SYSTEM_MCGFFCLK_CLOCK in clock.h"
#endif

// MCGFLLCLK_CLOCK  ==============================

#define MCG_C4_DMX32(x)    (((x)<<MCG_C4_DMX32_SHIFT)&MCG_C4_DMX32_MASK)

// Select FLL bandwidth - 0,1 -> narrow,wide frequency range
#define MCG_C4_DMX32_VALUE (0)

// Select FLL Frequency Range - 0,1,2,3 -> low,mid,mid-high,high
#define MCG_C4_DRST_DRS_VALUE (0)

#if (MCG_C4_DMX32_VALUE == 0)
#define MCG_FLLCLOCK (640*(MCG_C4_DRST_DRS_VALUE+1)*SYSTEM_MCGFFCLK_CLOCK)
#elif (MCG_C4_DMX32_VALUE == 1)
#define MCG_FLLCLOCK (732*(MCG_C4_DRST_DRS_VALUE+1)*SYSTEM_MCGFFCLK_CLOCK)
#else
#error "Check MCG_C4_DMX32_VALUE in clock.c"
#endif

// MCGPLLCLK_CLOCK  ==============================

// Select PLL External Reference Divider - 0-24 -> 1-25
// Selects the amount to divide down the external reference clock for the PLL.
// The resulting frequency must be in the range of 2 MHz to 4 MHz.
#define MCG_C5_PRDIV0_VALUE (1)

#define PLL_INPUT_DIVIDER (MCG_C5_PRDIV0_VALUE+1)
#if ((ERC_CLOCK/PLL_INPUT_DIVIDER) < 2000000) || ((ERC_CLOCK/PLL_INPUT_DIVIDER) > 4000000)
#error "Check MCG_C5_PRDIV0_VALUE in clock.c"
#endif

// Select the amount to divide the VCO output of the PLL - 0-31 -> 24-55
// This determine the multiplication factor of the PLL
#define MCG_C6_VDIV0_VALUE (0)
#define PLL_FACTOR (MCG_C6_VDIV0_VALUE+24)

#define MCGPLLCLK_CLOCK ((ERC_CLOCK/PLL_INPUT_DIVIDER)*PLL_FACTOR)

#if (MCGPLLCLK_CLOCK > 96000000)
#error "Check MCG_C5_PRDIV0_VALUE, MCG_C6_VDIV0_VALUE in clock.c"
#endif

// SYSTEM_PERIPHERAL_CLOCK  ==============================

#define SYSTEM_PERIPHERAL_CLOCK0 MCG_FLLCLOCK

#if defined(MCU_MK20D5)
#define SYSTEM_PERIPHERAL_CLOCK1 MCGPLLCLK_CLOCK
#elif defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
#define SYSTEM_PERIPHERAL_CLOCK1 (MCGPLLCLK_CLOCK/2)
#endif

#if (_SYSTEM_PERIPHERAL_CLOCK0 != SYSTEM_PERIPHERAL_CLOCK0)
#error "Check _SYSTEM_PERIPHERAL_CLOCK0 in clock.h"
#endif
#if (_SYSTEM_PERIPHERAL_CLOCK1 != SYSTEM_PERIPHERAL_CLOCK1)
#error "Check _SYSTEM_PERIPHERAL_CLOCK1 in clock.h"
#endif

// Select Peripheral clock - MCGFLLCLK or MCGPLLCLK(/2 on KL)
#if (SYSTEM_PERIPHERAL_CLOCK == _SYSTEM_PERIPHERAL_CLOCK0)
#define SIM_SOPT2_PLLFLLSEL_MASK_VALUE 0
#elif (SYSTEM_PERIPHERAL_CLOCK == _SYSTEM_PERIPHERAL_CLOCK1)
#define SIM_SOPT2_PLLFLLSEL_MASK_VALUE SIM_SOPT2_PLLFLLSEL_MASK
#else
#error  "Fix SYSTEM_PERIPHERAL_CLOCK value in Clock.h"
#endif

// SYSTEM_UART0_CLOCK  ==============================

#if defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
// Select UART0 Clock source
#if (SYSTEM_UART0_CLOCK == _UART0_CLOCK_OFF)
#define SIM_SOPT2_UART0SRC_VALUE (0)
#elif (SYSTEM_UART0_CLOCK == _UART0_CLOCK1)
#define SIM_SOPT2_UART0SRC_VALUE (1)
#elif (SYSTEM_UART0_CLOCK == _UART0_CLOCK2)
#define SIM_SOPT2_UART0SRC_VALUE (2)
#elif (SYSTEM_UART0_CLOCK == _UART0_CLOCK3)
#define SIM_SOPT2_UART0SRC_VALUE (3)
#else
#error  "Fix SYSTEM_UART0_CLOCK value in Clock.h"
#endif


// SYSTEM_TPM_CLOCK  ==============================

// Select TPM Clock source
#if (SYSTEM_TPM_CLOCK == _SYSTEM_TPM_CLOCK_OFF)
#define SIM_SOPT2_TPMSRC_VALUE (0)
#elif (SYSTEM_TPM_CLOCK == _SYSTEM_TPM_CLOCK1)
#define SIM_SOPT2_TPMSRC_VALUE (1)
#elif (SYSTEM_TPM_CLOCK == _SYSTEM_TPM_CLOCK2)
#define SIM_SOPT2_TPMSRC_VALUE (2)
#elif (SYSTEM_TPM_CLOCK == _SYSTEM_TPM_CLOCK3)
#define SIM_SOPT2_TPMSRC_VALUE (3)
#else
#error  "Fix SYSTEM_TPM_CLOCK value in Clock.h"
#endif
#endif

/*! Sets up the clock for USB operation (out of RESET)
 *!
 *! MCGOUTCLK = 48MHz
 *! core/platform/system clock = PLL (48MHz),
 *! bus clock = PLL/2 (24MHz),
 *! flash clock = PLL/2 (24MHz)
 *!
 *! Assumes 8 MHz external crystal
 *!
 *! Modes: FEI [FLL engaged internal] ->
 *!        FBE [FLL bypassed external] ->
 *!        PBE [PLL bypassed external] ->
 *!        PEE [PLL engaged external]
 *!
 *! Refer 24.5.3.1 of KL25 Family reference
 */
void clock_initialise(void) {

   // XTAL/EXTAL Pins
   SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;
   PORTA_PCR18 = PORT_PCR_MUX(0);
   PORTA_PCR19 = PORT_PCR_MUX(0);

   // Out of reset MCG is in FEI mode
   // Configure the Crystal Oscillator
   OSC0_CR = OSC_CR_ERCLKEN_VALUE|OSC_CR_SC8P_MASK; //ToDo Check caps, OSC_CR_SC16P_MASK;

   // Fast Internal Clock divider
   MCG_SC = MCG_SC_FCRDIV(MCG_SC_FCRDIV_VALUE);

   // 1. Switch from FEI (FLL engaged internal) to FBE (FLL bypassed external)


   // Out of reset MCG is in FEI mode
   // =============================================================
   // 1 a) Set up crystal or external clock source
   MCG_C2 =                         // oscillator in low power mode (w/o Rf)
            MCG_C2_EREFS0_MASK                  | // because crystal is being used
            MCG_C2_RANGE0(MCG_C2_RANGE0_VALUE)  | // 4 or 8 MHz is in high freq range
            MCG_C2_IRCS_VALUE;                    // IRCS=0/1 -> MCGIRCLK = Slow/fast internal clock

   // 1 b) Select clock mode
   MCG_C1 =  MCG_C1_CLKS(2)                    | // CLKS = 2     -> External reference clock
             MCG_C1_FRDIV(MCG_C1_FRDIV_VALUE)  | // FRDIV = 3    -> 8MHz/256 = 31.25 kHz
             MCG_C1_IRCLKEN_MASK               | // IRCLKEN = 1  -> MCGIRCLK active
             MCG_C1_IREFSTEN_MASK              | // IREFSTEN = 1 -> Internal reference enabled in STOP mode
             MCG_C1_IREFS_VALUE;                 // IREFS 0,1 -> External,Slow IRC

   // FLL Factors
   MCG_C4 = (MCG_C4&~(MCG_C4_DMX32_MASK|MCG_C4_DRST_DRS_MASK))|MCG_C4_DMX32(MCG_C4_DMX32_VALUE)|MCG_C4_DRST_DRS(MCG_C4_DRST_DRS_VALUE);

   // 1 c) Wait for crystal to start up
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_OSCINIT0_MASK) == 0);

   // 1 d) Wait for mode change
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_IREFST_MASK) != 0);

   // 1 e) Wait for MCGOUT indicating that the external reference to be fed to MCGOUT
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_CLKST_MASK) != MCG_S_CLKST(2));

   // 2. Configure PLL Reference Frequency
   // =============================================================
   // 2 a) Set PRDIV for correct range
   MCG_C5 =  MCG_C5_PLLCLKEN0_MASK |
             MCG_C5_PRDIV0(MCG_C5_PRDIV0_VALUE);    // PRDIV=1, PLL Ref Freq. = 8MHz/2 => 4 MHz

   MCG_C6 = 0;

   // 3. FBE => PBE
   // =============================================================
   // 3 a) (BLPE - not done)
   // 3 b) PBE (/BLPE - not done)
   MCG_C6 = MCG_C6_PLLS_MASK|MCG_C6_VDIV0(MCG_C6_VDIV0_VALUE); // 4MHz x 24 = 96MHz
   // 3 c) PBE (BLPE only -  not done)
   // 3 d) Wait until PLLS clock source changes to the PLL
   do {
      __asm__("nop");
   } while((MCG_S & MCG_S_PLLST_MASK) == 0);

   // 3 e)  Wait for PLL to acquired lock
   do {
      __asm__("nop");
   } while((MCG_S & MCG_S_LOCK0_MASK) == 0);

   // Set up the SIM clock dividers BEFORE switching to the PLL to ensure the
   // system clock speeds are in spec.
#if defined(MCU_MK20D5)
   // core/platform/system clock = PLL/2 (48MHz), bus clock = PLL/2 (48MHz), flash clock = PLL/4 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV2(1) | SIM_CLKDIV1_OUTDIV4(3);
#elif defined(MCU_MK20D7)
   // core/platform/system clock = PLL/2 (48MHz), bus clock = PLL/2 (48MHz), flash clock = PLL/4 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV2(1) | SIM_CLKDIV1_OUTDIV4(3);
#elif defined(MCU_MK40DZ10)
   // core/platform/system clock = PLL/2 (48MHz), bus clock = PLL/2 (48MHz), flash clock = PLL/4 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV2(1) | SIM_CLKDIV1_OUTDIV4(3);
#elif defined(MCU_MK60D10)
   // core/platform/system clock = PLL/2 (48MHz), bus clock = PLL/2 (48MHz), flash clock = PLL/4 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV2(1) | SIM_CLKDIV1_OUTDIV4(3);
#elif defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
   // core/platform/system clock = PLL/2 (48MHz), bus clock/flash clock = PLL/2/2 (24MHz)
   SIM_CLKDIV1 = SIM_CLKDIV1_OUTDIV1(1) | SIM_CLKDIV1_OUTDIV4(1);
#else
   #error "CPU not set"
#endif

   __asm__("nop");
   __asm__("nop");
   __asm__("nop");

   // 4. PBE -> PEE mode:
   // =============================================================
   // 4 a) Select clock mode
   MCG_C1 = MCG_C1_CLKS(0)                   | // CLKS  = 0    -> FLL or PLL is selected
            MCG_C1_FRDIV(MCG_C1_FRDIV_VALUE) | // FRDIV = 3    -> 8MHz/256 = 31.25 kHz
            MCG_C1_IRCLKEN_MASK              | // IRCLKEN = 1  -> MCGIRCLK active
            MCG_C1_IREFSTEN_MASK             | // IREFSTEN = 1 -> Internal reference enabled in STOP mode
            MCG_C1_IREFS_VALUE;                // IREFS 0,1 -> External,Slow IRC

   // 4 b)  Wait for clock stable
   do {
      __asm__("nop");
   } while ((MCG_S & MCG_S_CLKST_MASK) != (MCG_S_CLKST(3)));

   // Now MCGOUTCLK=MCGPLLCLK=[(8 MHz / 2) * 24] = 96 MHz

   // Basic clock selection
#if defined(MCU_MK20D5)
   // Peripheral clock choice (incl. USB), USBCLK = MCGCLK
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK | // PLL rather than FLL for peripheral clock
                SIM_SOPT2_USBSRC_MASK;     // MCGPLLCLK/2 Source as USB clock (48MHz req.)
   SIM_SOPT1 = (SIM_SOPT1&~SIM_SOPT1_OSC32KSEL_MASK)|SIM_SOPT1_OSC32KSEL(SIM_SOPT1_OSC32KSEL_VALUE); // ERCLK32K source
#elif defined(MCU_MK20D7)
   // Peripheral clock choice (incl. USB), USBCLK = MCGCLK
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK | // PLL rather than FLL for peripheral clock
                SIM_SOPT2_USBSRC_MASK;     // MCGPLLCLK/2 Source as USB clock (48MHz req.)
#elif defined(MCU_MK40DZ10)
   // Peripheral clock choice (incl. USB), USBCLK = MCGCLK
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK | // PLL rather than FLL for peripheral clock
                SIM_SOPT2_USBSRC_MASK;     // MCGPLLCLK/2 Source as USB clock (48MHz req.)
#elif defined(MCU_MK60D10)
   // Peripheral clock choice (incl. USB), USBCLK = MCGCLK
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK | // PLL rather than FLL for peripheral clock
                SIM_SOPT2_USBSRC_MASK;     // MCGPLLCLK/2 Source as USB clock (48MHz req.)
#elif defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
   SIM_SOPT2 = SIM_SOPT2_UART0SRC(SIM_SOPT2_UART0SRC_VALUE)     | // UART0 clock - 0,1,2,3 -> Disabled, (MCGFLLCLK, MCGPLLCLK/2),  OSCERCLK, MCGIRCLK
               SIM_SOPT2_TPMSRC(SIM_SOPT2_TPMSRC_VALUE)         | // TPM clock - 0,1,2,3 -> Disabled, (MCGFLLCLK, MCGPLLCLK/2),  OSCERCLK, MCGIRCLK
               SIM_SOPT2_PLLFLLSEL_MASK_VALUE                   | // Peripheral clock - 0,1 -> MCGFLLCLK,MCGPLLCLK/2
               SIM_SOPT2_USBSRC_MASK;                             // MCGPLLCLK/2 Source as USB clock (48MHz req.)
   SIM_SOPT1 = (SIM_SOPT1&~SIM_SOPT1_OSC32KSEL_MASK)|SIM_SOPT1_OSC32KSEL(SIM_SOPT1_OSC32KSEL_VALUE); // ERCLK32K clock - 0,1,2,3 -> OSC32KCLK, - , RTC_CLKIN, LPO (1kHz)
#elif defined(MCU_MKL05Z4) || defined(MCU_MKL02Z4)
   SIM_SOPT2 = SIM_SOPT2_UART0SRC(1)        | // MCGPLLCLK/2 as UART0 clock
               SIM_SOPT2_TPMSRC(1)          | // MCGPLLCLK/2 as TPM clock
               SIM_SOPT2_CLKOUTSEL(0)       | // PLL rather than FLL for peripheral clock
               SIM_SOPT2_RTCCLKOUTSEL_MASK;   // MCGPLLCLK/2 Source as USB clock (48MHz req.)
#else
   #error "CPU not set"
#endif
}
