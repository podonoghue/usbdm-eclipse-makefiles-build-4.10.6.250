/*
 * clock.h
 *
 *  Created on: Nov 6, 2012
 *      Author: podonoghue
 */

#ifndef CLOCK_H_
#define CLOCK_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * ERCLK32 sources
 */
#define _ERCLK32K_CLOCK0 (SYSTEM_OSC32KCLK_CLOCK)

#if defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
#define _ERCLK32K_CLOCK2 (SYSTEM_RTC_CLKIN_CLOCK)
#else
#define _ERCLK32K_CLOCK2 (SYSTEM_RTC_OSC_CLOCK)
#endif

#define _ERCLK32K_CLOCK3 (SYSTEM_LPO_CLOCK)

/*
 * MCGIRCLK sources
 */
// Fast Internal Reference Clock (Fast IRC) frequency (before prescaler)
#define SYSTEM_FAST_IRC_CLOCK_BASE (4000000UL) // Hz

// Slow Internal Reference Clock (Slow IRC) frequency
#define SYSTEM_SLOW_IRC_CLOCK      (32769UL) // Hz (nominal)

// Select Prescaler for Fast IRC
#define MCG_SC_FCRDIV_VALUE   (0)
#define SYSTEM_FAST_IRC_CLOCK (SYSTEM_FAST_IRC_CLOCK_BASE/(1<<MCG_SC_FCRDIV_VALUE))

#define _MCGIRCLK_CLOCK0 (SYSTEM_SLOW_IRC_CLOCK)
#define _MCGIRCLK_CLOCK1 (SYSTEM_FAST_IRC_CLOCK)

#if defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
/*
 * UART0 Clock sources
 */
#define _UART0_CLOCK_OFF (0)  // Disabled
#define _UART0_CLOCK1 (SYSTEM_PERIPHERAL_CLOCK)
#define _UART0_CLOCK2 (SYSTEM_OSCERCLK_CLOCK)
#define _UART0_CLOCK3 (SYSTEM_MCGIRCLK_CLOCK)

/*
 *  TPM Clock sources
 */
#define _SYSTEM_TPM_CLOCK_OFF (0)  // Disabled
#define _SYSTEM_TPM_CLOCK1    (SYSTEM_PERIPHERAL_CLOCK)
#define _SYSTEM_TPM_CLOCK2    (SYSTEM_OSCERCLK_CLOCK)
#define _SYSTEM_TPM_CLOCK3    (SYSTEM_MCGIRCLK_CLOCK)
#endif

/*
 *
 */
static const uint32_t SystemCoreClock = 48000000UL; // Hz
static const uint32_t SystemBusClock  = 48000000UL; // Hz

// These values may depend on the clock configuration
#define SYSTEM_CORE_CLOCK                  (48000000UL) // Hz
#define SYSTEM_BUS_CLOCK                   (48000000UL) // Hz
#define SYSTEM_OSCCLK                      (8000000UL)  // Hz External crystal or clock
#define SYSTEM_OSCERCLK_CLOCK           (SYSTEM_OSCCLK) // Hz Gated SYSTEM_OSCCLK (set to 0 to disable)
#define SYSTEM_LPO_CLOCK                       (1000UL) // Hz (nominal)
#define SYSTEM_OSC32KCLK_CLOCK                    (0UL) // Hz From system oscillator (low xtal)
#define SYSTEM_RTC_OSC_CLOCK                  (32768UL) // Hz 32.768 kHz oscillator
#define SYSTEM_RTC_CLKIN_CLOCK                    (1UL) // Hz External RTC (not available)

// Refer above for available choices
#define SYSTEM_MCGIRCLK_CLOCK         _MCGIRCLK_CLOCK0
#define SYSTEM_ERCLK32K_CLOCK         _ERCLK32K_CLOCK2

#if defined(MCU_MKL25Z4) || defined(MCU_MKL26Z4) || defined(MCU_MKL46Z4)
#define SYSTEM_UART0_CLOCK               _UART0_CLOCK2
#define SYSTEM_TPM_CLOCK            _SYSTEM_TPM_CLOCK1
#define SYSTEM_UART1_CLOCK            SYSTEM_BUS_CLOCK
#define SYSTEM_UART2_CLOCK            SYSTEM_BUS_CLOCK
#endif

#define _ERC_AFTER_FRDIV_CLOCK     (SYSTEM_OSCERCLK_CLOCK/(1<<8)) // See ERC_AFTER_FRDIV_CLOCK derivation in clock.c

#define _MCGFFCLK0                  _ERC_AFTER_FRDIV_CLOCK
#define _MCGFFCLK1                  SYSTEM_SLOW_IRC_CLOCK

#define SYSTEM_MCGFFCLK_CLOCK      _MCGFFCLK0  // This clock is not available outside MCG on MKL family

#if defined(MCU_MK20D5)
#define SYSTEM_UART0_CLOCK          SYSTEM_CORE_CLOCK
#define SYSTEM_UART1_CLOCK          SYSTEM_CORE_CLOCK
#define SYSTEM_UART2_CLOCK           SYSTEM_BUS_CLOCK
#define SYSTEM_UART2_CLOCK           SYSTEM_BUS_CLOCK
#endif

#define _SYSTEM_PERIPHERAL_CLOCK0    (20000000UL) // (640*SYSTEM_SLOW_IRC_CLOCK) or (20000000UL) // Hz See SYSTEM_PERIPHERAL_CLOCK0 derivation in clock.c
#define _SYSTEM_PERIPHERAL_CLOCK1    (96000000UL) // Hz See SYSTEM_PERIPHERAL_CLOCK1 derivation in clock.c

#define SYSTEM_PERIPHERAL_CLOCK      _SYSTEM_PERIPHERAL_CLOCK1 // Hz

void clock_initialise(void);

#ifdef __cplusplus
}
#endif

#endif /* CLOCK_H_ */
