/*
 * pit.h
 *
 *  Created on: 12/11/2013
 *      Author: podonoghue
 */

#ifndef PIT_H_
#define PIT_H_

#include "clock.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PIT_CLOCK_FREQUENCY           SYSTEM_BUS_CLOCK

#if ((PIT_CLOCK_FREQUENCY/1000000) > 0)
   //! Macro to convert microseconds to PIT ticks
// Only usable with a fast clock
   #define PIT_MICROSECOND_TO_TICKS(us) (((us)*PIT_CLOCK_FREQUENCY)/1000000)
   //! Macro to convert milliseconds to PIT ticks
   #define PIT_MILLISECOND_TO_TICKS(ms)  ((ms)*(PIT_CLOCK_FREQUENCY/1000))
#else
   //! Macro to convert milliseconds to PIT ticks
   #define PIT_MILLISECOND_TO_TICKS(ms)  (((ms)*PIT_CLOCK_FREQUENCY)/1000)
#endif

void pit_initialise(int channel, uint32_t interval /* ticks */);
void pit_finalise(int channel);

#ifndef PIT_USES_NAKED_HANDLERS
   typedef void (*PITCallbackFunction)(void);
   PITCallbackFunction pit_setCallbackFunction(int channel, PITCallbackFunction callback);
#endif

#ifdef __cplusplus
}
#endif

#endif /* PIT_H_ */
