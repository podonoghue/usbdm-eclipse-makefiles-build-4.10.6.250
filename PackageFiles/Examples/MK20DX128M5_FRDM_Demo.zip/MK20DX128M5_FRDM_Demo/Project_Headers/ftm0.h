/*
 * pwm.h
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */

#ifndef FTM0_H_
#define FTM0_H_

#include "clock.h"
#include "derivative.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * FTM Clock sources
 */
#define _FTM0_CLOCK0 (0) // Disabled
#define _FTM0_CLOCK1 SYSTEM_CORE_CLOCK
#define _FTM0_CLOCK2 SYSTEM_MCGFFCLK_CLOCK
#define _FTM0_CLOCK3 (0) // External FTM_CLKINx clock - not defined

#define _FTM0_CLOCK_FREQUENCY_BASE  _FTM0_CLOCK1

// Choice of prescale value (FTM0_SC.PS)
#define _FTM0_PRESCALE_VALUE    (7)
#define _FTM0_PRESCALE          (1<<_FTM0_PRESCALE_VALUE)
#define FTM0_CLOCK_FREQUENCY    (_FTM0_CLOCK_FREQUENCY_BASE/_FTM0_PRESCALE)

//! Macro to convert milliseconds to FTM0 ticks
#define FTM0_MILLISECONDS_TO_TICKS(ms)    (((ms)*FTM0_CLOCK_FREQUENCY)/1000)

typedef enum  {
   ftm_inputCaptureRisingEdge  = FTM_CnSC_ELSA_MASK,
   ftm_inputCaptureFallingEdge = FTM_CnSC_ELSB_MASK,
   ftm_inputCaptureEitherEdge  = FTM_CnSC_ELSB_MASK|FTM_CnSC_ELSA_MASK,
   ftm_outputCompare           = FTM_CnSC_MSA_MASK,
   ftm_outputCompareToggle     = FTM_CnSC_MSA_MASK|FTM_CnSC_ELSA_MASK,
   ftm_outputCompareClear      = FTM_CnSC_MSA_MASK|FTM_CnSC_ELSB_MASK,
   ftm_outputCompareSet        = FTM_CnSC_MSA_MASK|FTM_CnSC_ELSB_MASK|FTM_CnSC_ELSA_MASK,
   ftm_pwmHighTruePulses       = FTM_CnSC_MSB_MASK|FTM_CnSC_ELSB_MASK,
   ftm_pwmLowTruePulses        = FTM_CnSC_MSB_MASK|FTM_CnSC_ELSA_MASK,
} Ftm_Mode;

typedef enum {
   ftm_leftAlign   = 0,
   ftm_centreAlign = FTM_SC_CPWMS_MASK,
} Pwm_Mode;

void ftm0_initialise(void);
void ftm0_initialiseAsPWM(int period /* ticks */, Pwm_Mode mode);
void ftm0_setDutyCycle(int channel, int dutyCycle);

void ftm0_initialiseChannel(int channel, Ftm_Mode mode);
void ftm0_finaliseChannel(int channel);

#ifndef FTM0_USES_NAKED_HANDLERS
   typedef void (*FTMCallbackFunction)(void);
   FTMCallbackFunction ftm0_setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval);
#endif

#ifdef __cplusplus
}
#endif

#endif /* FTM0_H_ */
