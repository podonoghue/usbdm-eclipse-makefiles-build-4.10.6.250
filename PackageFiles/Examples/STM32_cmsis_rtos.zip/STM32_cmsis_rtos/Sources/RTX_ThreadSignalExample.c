/*!
 * CMSIS Thread-Signal example
 *
 * This example demonstrates creating a thread and communication between that thread and the main thread using
 * signals.
 *
 * Target board OLIMEXIKO-STM32 (Maple) board
 *
 * Assumes LEDs on PA1 & PA5
 *
 */
#include "cmsis_os.h"
#include "derivative.h"

// Forward references
void threadFunction(void const *argument);    // prototypes for thread function

// Thread IDs
osThreadId mainFunctionId;
osThreadId threadFunctionId;

// Thread definition
osThreadDef(threadFunction, osPriorityNormal, 1, 0);

#define LEDA_MASK (1<<1)  //  PA1
#define LEDB_MASK (1<<5)  //  PA5

#define SIGNAL_MASK (1<<2) // Arbitrary signal mask used for communication

/*!
 * Function representing a different thread of execution
 *
 * @param argument pointer to arbitrary object passed from thread creation
 *
 */
void threadFunction(void const *argument) {
   (void) argument;
   for (;;) {

   // Set LED-A on
   GPIOA->BSRR = LEDA_MASK;

   // Signal to main thread
   osSignalSet(mainFunctionId, SIGNAL_MASK);

   // Pause for 1s
   osDelay(500);

   // Set LED_A off
   GPIOA->BRR = LEDA_MASK;

   // Pause for 1s
   osDelay(500);
   }
}

/*!
 * Main function - forms main threads
 *
 */
int main(void) {

   GPIO_InitTypeDef GPIO_InitStructure;

   // GPIOD Periph clock enable
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

   // Configure PA5 and PA1 in output push-pull mode
   GPIO_InitStructure.GPIO_Pin = LEDA_MASK | LEDB_MASK;
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
   GPIO_Init(GPIOA, &GPIO_InitStructure);

   // Get main thread ID
   mainFunctionId = osThreadGetId();

   // Create thread
   threadFunctionId = osThreadCreate(osThread(threadFunction), NULL);
   if (threadFunctionId == NULL) {
      __asm("bkpt");
   }
   for (;;) {
      // Wait for signal from thread
      osSignalWait(SIGNAL_MASK, osWaitForever);

      // Set LED-A on
      GPIOA->BSRR = LEDB_MASK;

      // Pause for 1s
      osDelay(100);

      // Set LED_B off
      GPIOA->BRR = LEDB_MASK;
   }
}

